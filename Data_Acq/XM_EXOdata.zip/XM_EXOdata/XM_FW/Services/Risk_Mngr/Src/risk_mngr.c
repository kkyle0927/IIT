/*
 * risk_mngr.c
 *
 *  Created on: Aug 21, 2023
 *      Author: HyundoKim
 */


