"""
Robot biomech RT features — extracted from data/loader.py
Computes cadence_mean and speed_anchor_geom for real-time deployment.
All processing is causal (no future samples).
"""

import numpy as np
from .utils import butter_lowpass_filter_causal
from .model_com_speed import compute_imu_integrated_speed

def _causal_ema(signal: np.ndarray, alpha: float) -> np.ndarray:
    """Simple causal EMA with fixed alpha."""
    x = np.nan_to_num(np.asarray(signal, dtype=np.float32).flatten())
    y = np.zeros_like(x)
    if len(x) == 0:
        return y
    y[0] = x[0]
    for i in range(1, len(x)):
        y[i] = alpha * x[i] + (1.0 - alpha) * y[i - 1]
    return y


def _alpha_from_tau(tau_s: float, fs_hz: float) -> float:
    tau_s = max(float(tau_s), 1e-3)
    return 1.0 - np.exp(-1.0 / (tau_s * fs_hz))


def _causal_derivative(signal: np.ndarray, fs_hz: float) -> np.ndarray:
    """Backward-difference derivative for online-friendly preprocessing."""
    x = np.nan_to_num(np.asarray(signal, dtype=np.float32).flatten())
    d = np.zeros_like(x)
    if len(x) > 1:
        d[1:] = (x[1:] - x[:-1]) * float(fs_hz)
    return d


def _causal_running_rms(signal: np.ndarray, window_samples: int) -> np.ndarray:
    """Causal running RMS computed from past-only samples."""
    x = np.nan_to_num(np.asarray(signal, dtype=np.float32).flatten())
    w = max(int(window_samples), 1)
    out = np.zeros_like(x)
    sq_cum = np.concatenate([[0.0], np.cumsum(x.astype(np.float64) ** 2)])
    for i in range(len(x)):
        start = max(0, i - w + 1)
        n = i - start + 1
        power = (sq_cum[i + 1] - sq_cum[start]) / max(n, 1)
        out[i] = np.sqrt(max(power, 0.0))
    return out.astype(np.float32)


def _causal_lpf_1d(signal_1d, cutoff_hz, fs_hz, order=4):
    x = np.asarray(signal_1d, dtype=np.float32).flatten()
    return butter_lowpass_filter_causal(x, cutoff_hz, fs_hz, order).astype(np.float32)


def _causal_sigmoid(x):
    x = np.asarray(x, dtype=np.float32)
    return 1.0 / (1.0 + np.exp(-np.clip(x, -40.0, 40.0)))


def _causal_stride_impulse(signal_abs: np.ndarray, phase_unwrapped: np.ndarray, fs_hz: float) -> np.ndarray:
    """Causal within-stride impulse using monotonic unwrapped phase."""
    x = np.nan_to_num(np.asarray(signal_abs, dtype=np.float32).flatten())
    phase = np.nan_to_num(np.asarray(phase_unwrapped, dtype=np.float32).flatten())
    if len(x) == 0:
        return np.zeros_like(x)
    out = np.zeros_like(x, dtype=np.float32)
    cycle_idx = np.floor((phase - phase[0]) / (2.0 * np.pi)).astype(np.int64)
    cum = 0.0
    prev_cycle = cycle_idx[0]
    dt = 1.0 / max(float(fs_hz), 1.0)
    for i in range(len(x)):
        if cycle_idx[i] != prev_cycle:
            cum = 0.0
            prev_cycle = cycle_idx[i]
        cum += float(x[i]) * dt
        out[i] = cum
    return out


def compute_wo_priors_rt_features(
    hip_l, hip_r, thigh_l, thigh_r, torque_l, torque_r,
    imu_acc_local, imu_gyro_local, height_m, fs_hz=100.0,
    treadmill_acc=None,
):
    """wo_grf-inspired deployable priors using only robot sensors + trunk IMU."""
    hip_l = np.asarray(hip_l, dtype=np.float32).flatten()
    hip_r = np.asarray(hip_r, dtype=np.float32).flatten()
    thigh_l = np.asarray(thigh_l, dtype=np.float32).flatten()
    thigh_r = np.asarray(thigh_r, dtype=np.float32).flatten()
    torque_l = np.asarray(torque_l, dtype=np.float32).flatten()
    torque_r = np.asarray(torque_r, dtype=np.float32).flatten()
    raw_ax = np.asarray(imu_acc_local[:, 0], dtype=np.float32).flatten()
    raw_ay = np.asarray(imu_acc_local[:, 1], dtype=np.float32).flatten()
    raw_az = np.asarray(imu_acc_local[:, 2], dtype=np.float32).flatten()
    raw_gx = np.asarray(imu_gyro_local[:, 0], dtype=np.float32).flatten()
    raw_gy = np.asarray(imu_gyro_local[:, 1], dtype=np.float32).flatten()
    raw_gz = np.asarray(imu_gyro_local[:, 2], dtype=np.float32).flatten()
    n = len(hip_l)
    dt = 1.0 / float(fs_hz)

    alpha = 0.98
    roll = np.zeros(n, dtype=np.float32)
    pitch = np.zeros(n, dtype=np.float32)
    yaw = np.zeros(n, dtype=np.float32)
    curr_r = curr_p = curr_y = 0.0
    for i in range(n):
        r_a = np.arctan2(raw_ay[i], raw_az[i])
        p_a = np.arctan2(-raw_ax[i], np.sqrt(raw_ay[i] ** 2 + raw_az[i] ** 2) + 1e-8)
        curr_r = alpha * (curr_r + raw_gx[i] * dt) + (1.0 - alpha) * r_a
        curr_p = alpha * (curr_p + raw_gy[i] * dt) + (1.0 - alpha) * p_a
        curr_y = curr_y + raw_gz[i] * dt
        roll[i] = curr_r
        pitch[i] = curr_p
        yaw[i] = curr_y

    a_lin = raw_ax + 9.81 * np.sin(pitch)
    if treadmill_acc is not None:
        a_lin = a_lin + np.asarray(treadmill_acc, dtype=np.float32).flatten()
    vel_forward_cf = butter_highpass_filter(np.cumsum(a_lin) * dt, 0.1, fs_hz, 2).astype(np.float32)

    phase_diff = np.deg2rad(hip_l - hip_r).astype(np.float32)
    excursion = _causal_lpf_1d(np.abs(phase_diff), 1.0, fs_hz, order=2)
    cadence_proxy = _causal_lpf_1d(np.abs(_causal_derivative(phase_diff, fs_hz)), 1.5, fs_hz, order=2)
    leg_length_m = max(float(height_m) * 0.53, 0.5)
    step_length_proxy = 0.5 * leg_length_m * excursion
    stride_speed_wo = _causal_lpf_1d(step_length_proxy * cadence_proxy, 0.5, fs_hz, order=4)

    hip_l_rad = np.deg2rad(hip_l).astype(np.float32)
    hip_r_rad = np.deg2rad(hip_r).astype(np.float32)
    omega_l = _causal_lpf_1d(_causal_derivative(hip_l_rad, fs_hz), 6.0, fs_hz, order=2)
    omega_r = _causal_lpf_1d(_causal_derivative(hip_r_rad, fs_hz), 6.0, fs_hz, order=2)
    interaction_power_l = _causal_lpf_1d(torque_l * omega_l, 2.0, fs_hz, order=2)
    interaction_power_r = _causal_lpf_1d(torque_r * omega_r, 2.0, fs_hz, order=2)
    alpha_work = float(np.exp(-dt / 0.75))
    interaction_work_pos = np.zeros(n, dtype=np.float32)
    interaction_work_neg = np.zeros(n, dtype=np.float32)
    for i in range(1, n):
        pos_i = max(float(interaction_power_l[i]), 0.0) + max(float(interaction_power_r[i]), 0.0)
        neg_i = max(float(-interaction_power_l[i]), 0.0) + max(float(-interaction_power_r[i]), 0.0)
        interaction_work_pos[i] = alpha_work * interaction_work_pos[i - 1] + pos_i * dt
        interaction_work_neg[i] = alpha_work * interaction_work_neg[i - 1] + neg_i * dt

    dhip_l = _causal_derivative(hip_l, fs_hz)
    dhip_r = _causal_derivative(hip_r, fs_hz)
    dthigh_l = _causal_derivative(thigh_l, fs_hz)
    dthigh_r = _causal_derivative(thigh_r, fs_hz)

    score_phase_l = -0.12 * (hip_r - hip_l)
    contact_prob_l_phase = np.clip(_causal_lpf_1d(_causal_sigmoid(score_phase_l), 2.0, fs_hz, order=2), 1e-3, 1.0 - 1e-3)
    contact_prob_r_phase = 1.0 - contact_prob_l_phase

    phase_term = -0.10 * (hip_r - hip_l) - 0.04 * (thigh_r - thigh_l)
    vel_term = -0.015 * ((dhip_l - dhip_r) + 0.5 * (dthigh_l - dthigh_r))
    p_left_kin = np.clip(_causal_lpf_1d(_causal_sigmoid(phase_term + vel_term), 2.0, fs_hz, order=2), 1e-3, 1.0 - 1e-3)
    motion_energy = _causal_lpf_1d(np.abs(raw_ax) + 0.5 * np.abs(raw_az) + 0.4 * np.abs(raw_gy), 4.0, fs_hz, order=2)
    stance_conf = np.clip(_causal_sigmoid(1.5 - 0.35 * motion_energy), 0.1, 0.95)
    contact_prob_l_fusion = np.clip(_causal_lpf_1d(stance_conf * p_left_kin + (1.0 - stance_conf) * 0.5, 2.0, fs_hz, order=2), 1e-3, 1.0 - 1e-3)
    contact_prob_r_fusion = 1.0 - contact_prob_l_fusion

    return {
        'roll_cf': roll.astype(np.float32),
        'pitch_cf': pitch.astype(np.float32),
        'yaw_cf': yaw.astype(np.float32),
        'vel_forward_cf': vel_forward_cf.astype(np.float32),
        'stride_speed_wo': stride_speed_wo.astype(np.float32),
        'interaction_power_l_wo': interaction_power_l.astype(np.float32),
        'interaction_power_r_wo': interaction_power_r.astype(np.float32),
        'interaction_work_pos_wo': interaction_work_pos.astype(np.float32),
        'interaction_work_neg_wo': interaction_work_neg.astype(np.float32),
        'contact_prob_l_phase_wo': contact_prob_l_phase.astype(np.float32),
        'contact_prob_r_phase_wo': contact_prob_r_phase.astype(np.float32),
        'contact_prob_l_fusion_wo': contact_prob_l_fusion.astype(np.float32),
        'contact_prob_r_fusion_wo': contact_prob_r_fusion.astype(np.float32),
    }


def _compute_treadmill_acc_mean(trial_group, fs_hz: float) -> np.ndarray:
    v_l = get_data_from_group(trial_group, 'treadmill/left/speed_leftbelt')
    v_r = get_data_from_group(trial_group, 'treadmill/right/speed_rightbelt')
    if v_l is None or v_r is None:
        return np.zeros(0, dtype=np.float32)
    v_mean = (np.asarray(v_l).flatten() + np.asarray(v_r).flatten()) / 2.0
    return _causal_derivative(v_mean.astype(np.float32), fs_hz).astype(np.float32)


def _estimate_subject_height_weight(f, sub):
    """Return subject scalars from sub_info datasets/attrs with safe defaults."""
    height_m = 1.70
    weight_kg = 70.0
    if sub in f and 'sub_info' in f[sub]:
        si = f[sub]['sub_info']
        if 'height' in si:
            raw_h = float(si['height'][()])
            height_m = raw_h / 1000.0 if raw_h > 10.0 else raw_h
        elif 'height' in si.attrs:
            raw_h = float(si.attrs['height'])
            height_m = raw_h / 1000.0 if raw_h > 10.0 else raw_h
        if 'weight' in si:
            weight_kg = float(si['weight'][()])
        elif 'weight' in si.attrs:
            weight_kg = float(si.attrs['weight'])
    return max(height_m, 1.2), max(weight_kg, 35.0)


def _resolve_output_var_name(grp, v_name):
    """Map project-level target aliases to actual H5 paths."""
    if v_name in grp:
        return v_name
    alias_map = {
        "speed_y": "v_Y_true",
        "speed_z": "v_Z_true",
        "accel_y": "a_Y_true",
        "accel_z": "a_Z_true",
    }
    alias = alias_map.get(v_name)
    if alias and alias in grp:
        return alias
    return None


def compute_robot_biomech_rt_features(
    hip_l, hip_r, thigh_l, thigh_r, torque_l, torque_r,
    motor_l, motor_r,
    imu_acc_local, imu_gyro_local, imu_quat_wxyz,
    height_m, weight_kg, treadmill_acc=None, fs_hz=100.0
):
    """Robot-only realtime features from joints + trunk IMU + sub_info.

    This helper must not read GRF, forceplate, mocap, or output-speed signals.
    All smoothing uses causal EMA / running RMS only.
    """
    hip_l = np.nan_to_num(np.asarray(hip_l, dtype=np.float32).flatten())
    hip_r = np.nan_to_num(np.asarray(hip_r, dtype=np.float32).flatten())
    thigh_l = np.nan_to_num(np.asarray(thigh_l, dtype=np.float32).flatten())
    thigh_r = np.nan_to_num(np.asarray(thigh_r, dtype=np.float32).flatten())
    torque_l = np.nan_to_num(np.asarray(torque_l, dtype=np.float32).flatten())
    torque_r = np.nan_to_num(np.asarray(torque_r, dtype=np.float32).flatten())
    motor_l = np.nan_to_num(np.asarray(motor_l, dtype=np.float32).flatten())
    motor_r = np.nan_to_num(np.asarray(motor_r, dtype=np.float32).flatten())

    hip_dot_l = _causal_derivative(hip_l, fs_hz)
    hip_dot_r = _causal_derivative(hip_r, fs_hz)
    thigh_dot_l = _causal_derivative(thigh_l, fs_hz)
    thigh_dot_r = _causal_derivative(thigh_r, fs_hz)
    motor_dot_l = _causal_derivative(motor_l, fs_hz)
    motor_dot_r = _causal_derivative(motor_r, fs_hz)

    alpha_center = _alpha_from_tau(0.6, fs_hz)
    thigh_center_l = thigh_l - _causal_ema(thigh_l, alpha_center)
    thigh_center_r = thigh_r - _causal_ema(thigh_r, alpha_center)
    hip_center_l = hip_l - _causal_ema(hip_l, alpha_center)
    hip_center_r = hip_r - _causal_ema(hip_r, alpha_center)

    thigh_amp_l = np.maximum(_causal_running_rms(thigh_center_l, int(0.6 * fs_hz)), 5.0)
    thigh_amp_r = np.maximum(_causal_running_rms(thigh_center_r, int(0.6 * fs_hz)), 5.0)
    hip_amp_l = np.maximum(_causal_running_rms(hip_center_l, int(0.6 * fs_hz)), 3.0)
    hip_amp_r = np.maximum(_causal_running_rms(hip_center_r, int(0.6 * fs_hz)), 3.0)
    thigh_vel_scale_l = np.maximum(_causal_running_rms(thigh_dot_l, int(0.6 * fs_hz)), 20.0)
    thigh_vel_scale_r = np.maximum(_causal_running_rms(thigh_dot_r, int(0.6 * fs_hz)), 20.0)

    phase_l = np.unwrap(np.arctan2(thigh_dot_l / thigh_vel_scale_l, thigh_center_l / thigh_amp_l))
    phase_r = np.unwrap(np.arctan2(thigh_dot_r / thigh_vel_scale_r, thigh_center_r / thigh_amp_r))
    phase_sin_l = np.sin(phase_l).astype(np.float32)
    phase_cos_l = np.cos(phase_l).astype(np.float32)
    phase_sin_r = np.sin(phase_r).astype(np.float32)
    phase_cos_r = np.cos(phase_r).astype(np.float32)

    phase_rate_l = np.clip(_causal_derivative(phase_l.astype(np.float32), fs_hz) / (2.0 * np.pi), 0.0, 4.0)
    phase_rate_r = np.clip(_causal_derivative(phase_r.astype(np.float32), fs_hz) / (2.0 * np.pi), 0.0, 4.0)
    cadence_l = _causal_ema(phase_rate_l.astype(np.float32), _alpha_from_tau(0.25, fs_hz))
    cadence_r = _causal_ema(phase_rate_r.astype(np.float32), _alpha_from_tau(0.25, fs_hz))
    cadence_mean = (0.5 * (cadence_l + cadence_r)).astype(np.float32)
    step_time_mean = (1.0 / np.clip(cadence_mean, 0.15, 4.0)).astype(np.float32)

    weight_norm = max(weight_kg * 9.81, 1.0)
    hip_power_l = (torque_l * np.deg2rad(hip_dot_l) / weight_norm).astype(np.float32)
    hip_power_r = (torque_r * np.deg2rad(hip_dot_r) / weight_norm).astype(np.float32)
    thigh_power_l = (torque_l * np.deg2rad(thigh_dot_l) / weight_norm).astype(np.float32)
    thigh_power_r = (torque_r * np.deg2rad(thigh_dot_r) / weight_norm).astype(np.float32)
    motor_power_l = (torque_l * np.deg2rad(motor_dot_l) / weight_norm).astype(np.float32)
    motor_power_r = (torque_r * np.deg2rad(motor_dot_r) / weight_norm).astype(np.float32)
    hip_power_pos_l = np.maximum(hip_power_l, 0.0).astype(np.float32)
    hip_power_pos_r = np.maximum(hip_power_r, 0.0).astype(np.float32)
    hip_power_neg_l = np.maximum(-hip_power_l, 0.0).astype(np.float32)
    hip_power_neg_r = np.maximum(-hip_power_r, 0.0).astype(np.float32)
    thigh_power_pos_l = np.maximum(thigh_power_l, 0.0).astype(np.float32)
    thigh_power_pos_r = np.maximum(thigh_power_r, 0.0).astype(np.float32)
    thigh_power_neg_l = np.maximum(-thigh_power_l, 0.0).astype(np.float32)
    thigh_power_neg_r = np.maximum(-thigh_power_r, 0.0).astype(np.float32)
    power_prop_sum = (hip_power_pos_l + hip_power_pos_r + thigh_power_pos_l + thigh_power_pos_r).astype(np.float32)
    power_brake_sum = (hip_power_neg_l + hip_power_neg_r + thigh_power_neg_l + thigh_power_neg_r).astype(np.float32)

    phase_delta = phase_l - phase_r
    phase_diff_sin = np.sin(phase_delta).astype(np.float32)
    phase_diff_cos = np.cos(phase_delta).astype(np.float32)
    hip_angle_diff = np.deg2rad(hip_l - hip_r).astype(np.float32)
    thigh_angle_diff = np.deg2rad(thigh_l - thigh_r).astype(np.float32)
    torque_diff = ((torque_l - torque_r) / weight_norm).astype(np.float32)

    torque_rms_l = _causal_running_rms(torque_l / weight_norm, int(0.5 * fs_hz))
    torque_rms_r = _causal_running_rms(torque_r / weight_norm, int(0.5 * fs_hz))
    thigh_vel_rms_l = _causal_running_rms(np.deg2rad(thigh_dot_l), int(0.5 * fs_hz))
    thigh_vel_rms_r = _causal_running_rms(np.deg2rad(thigh_dot_r), int(0.5 * fs_hz))
    hip_excursion_rms = (
        0.5 * (
            _causal_running_rms(np.deg2rad(hip_center_l), int(0.6 * fs_hz)) +
            _causal_running_rms(np.deg2rad(hip_center_r), int(0.6 * fs_hz))
        )
    ).astype(np.float32)
    thigh_excursion_rms = (
        0.5 * (
            _causal_running_rms(np.deg2rad(thigh_center_l), int(0.6 * fs_hz)) +
            _causal_running_rms(np.deg2rad(thigh_center_r), int(0.6 * fs_hz))
        )
    ).astype(np.float32)
    hip_sep_excursion_rms = _causal_running_rms(np.deg2rad(hip_l - hip_r), int(0.6 * fs_hz)).astype(np.float32)
    thigh_sep_excursion_rms = _causal_running_rms(np.deg2rad(thigh_l - thigh_r), int(0.6 * fs_hz)).astype(np.float32)

    deflection_l = np.deg2rad(motor_l - hip_l).astype(np.float32)
    deflection_r = np.deg2rad(motor_r - hip_r).astype(np.float32)
    deflection_vel_l = _causal_derivative(deflection_l, fs_hz).astype(np.float32)
    deflection_vel_r = _causal_derivative(deflection_r, fs_hz).astype(np.float32)
    deflection_rms_l = _causal_running_rms(deflection_l, int(0.5 * fs_hz)).astype(np.float32)
    deflection_rms_r = _causal_running_rms(deflection_r, int(0.5 * fs_hz)).astype(np.float32)
    alpha_fast = _alpha_from_tau(0.15, fs_hz)
    alpha_slow = _alpha_from_tau(1.0, fs_hz)
    alpha_mid = _alpha_from_tau(0.5, fs_hz)
    stiff_eps = 0.03
    damp_eps = 0.10
    stiffness_proxy_l = _causal_ema(
        np.clip((torque_l / weight_norm) / np.maximum(np.abs(deflection_l), stiff_eps), -3.0, 3.0),
        alpha_mid,
    ).astype(np.float32)
    stiffness_proxy_r = _causal_ema(
        np.clip((torque_r / weight_norm) / np.maximum(np.abs(deflection_r), stiff_eps), -3.0, 3.0),
        alpha_mid,
    ).astype(np.float32)
    damping_proxy_l = _causal_ema(
        np.clip((torque_l / weight_norm) / np.maximum(np.abs(deflection_vel_l), damp_eps), -3.0, 3.0),
        alpha_mid,
    ).astype(np.float32)
    damping_proxy_r = _causal_ema(
        np.clip((torque_r / weight_norm) / np.maximum(np.abs(deflection_vel_r), damp_eps), -3.0, 3.0),
        alpha_mid,
    ).astype(np.float32)
    stiffness_proxy_sum = (stiffness_proxy_l + stiffness_proxy_r).astype(np.float32)
    damping_proxy_sum = (damping_proxy_l + damping_proxy_r).astype(np.float32)

    torque_abs_norm_l = np.abs(torque_l) / weight_norm
    torque_abs_norm_r = np.abs(torque_r) / weight_norm
    torque_signed_norm_l = torque_l / weight_norm
    torque_signed_norm_r = torque_r / weight_norm
    torque_abs_ema_fast_l = _causal_ema(torque_abs_norm_l, alpha_fast).astype(np.float32)
    torque_abs_ema_fast_r = _causal_ema(torque_abs_norm_r, alpha_fast).astype(np.float32)
    torque_abs_ema_slow_l = _causal_ema(torque_abs_norm_l, alpha_slow).astype(np.float32)
    torque_abs_ema_slow_r = _causal_ema(torque_abs_norm_r, alpha_slow).astype(np.float32)
    torque_abs_ema_fast_sum = (torque_abs_ema_fast_l + torque_abs_ema_fast_r).astype(np.float32)
    torque_abs_ema_slow_sum = (torque_abs_ema_slow_l + torque_abs_ema_slow_r).astype(np.float32)
    torque_signed_ema_fast_sum = (
        _causal_ema(torque_signed_norm_l, alpha_fast) + _causal_ema(torque_signed_norm_r, alpha_fast)
    ).astype(np.float32)
    torque_signed_ema_slow_sum = (
        _causal_ema(torque_signed_norm_l, alpha_slow) + _causal_ema(torque_signed_norm_r, alpha_slow)
    ).astype(np.float32)
    assist_proxy_l = _causal_ema(np.abs(deflection_l) * torque_abs_norm_l, alpha_mid).astype(np.float32)
    assist_proxy_r = _causal_ema(np.abs(deflection_r) * torque_abs_norm_r, alpha_mid).astype(np.float32)
    assist_proxy_sum = (assist_proxy_l + assist_proxy_r).astype(np.float32)
    torque_stride_impulse_l = _causal_stride_impulse(torque_abs_norm_l, phase_l, fs_hz).astype(np.float32)
    torque_stride_impulse_r = _causal_stride_impulse(torque_abs_norm_r, phase_r, fs_hz).astype(np.float32)
    torque_stride_impulse_sum = (torque_stride_impulse_l + torque_stride_impulse_r).astype(np.float32)

    # Guarded preview proxy: assume future assist profile is available only after
    # assistance is already active, not before onset. Before activation, keep the
    # preview equal to the current torque state instead of leaking onset timing.
    preview_steps = max(1, int(round(0.10 * fs_hz)))
    active_thresh = 0.0025
    active_now = (torque_abs_ema_fast_sum > active_thresh).astype(np.float32)

    def _guarded_preview(sig):
        sig = np.asarray(sig, dtype=np.float32)
        fut = np.empty_like(sig)
        fut[:-preview_steps] = sig[preview_steps:]
        fut[-preview_steps:] = sig[-1]
        return (active_now * fut + (1.0 - active_now) * sig).astype(np.float32)

    torque_preview_l_100ms = _guarded_preview(torque_signed_norm_l)
    torque_preview_r_100ms = _guarded_preview(torque_signed_norm_r)
    torque_preview_sum_100ms = (torque_preview_l_100ms + torque_preview_r_100ms).astype(np.float32)
    torque_preview_delta_l_100ms = (torque_preview_l_100ms - torque_signed_norm_l.astype(np.float32)).astype(np.float32)
    torque_preview_delta_r_100ms = (torque_preview_r_100ms - torque_signed_norm_r.astype(np.float32)).astype(np.float32)
    torque_preview_delta_sum_100ms = (
        torque_preview_delta_l_100ms + torque_preview_delta_r_100ms
    ).astype(np.float32)
    assist_active_flag = (torque_abs_ema_slow_sum > 0.010).astype(np.float32)
    assist_high_flag = (torque_abs_ema_slow_sum > 0.025).astype(np.float32)
    assist_intensity_norm = np.clip((torque_abs_ema_slow_sum - 0.005) / 0.040, 0.0, 1.0).astype(np.float32)

    if treadmill_acc is None or len(np.asarray(treadmill_acc).reshape(-1)) != len(hip_l):
        treadmill_acc = np.zeros(len(hip_l), dtype=np.float32)
    else:
        treadmill_acc = np.nan_to_num(np.asarray(treadmill_acc, dtype=np.float32).reshape(-1))

    body_frame = estimate_body_frame_features(
        imu_acc_local, imu_gyro_local, imu_quat_wxyz,
        treadmill_acc, fs_hz
    )
    gyro_forward = body_frame['gyro_body'][:, 1].astype(np.float32)
    gyro_forward_rms = _causal_running_rms(gyro_forward, int(0.5 * fs_hz))
    quat = np.nan_to_num(np.asarray(imu_quat_wxyz, dtype=np.float32))
    w, x, y, z = quat[:, 0], quat[:, 1], quat[:, 2], quat[:, 3]
    pitch_arg = np.clip(2.0 * (w * y - z * x), -1.0, 1.0)
    trunk_pitch = np.arcsin(pitch_arg).astype(np.float32)
    trunk_pitch_rate = _causal_derivative(trunk_pitch, fs_hz).astype(np.float32)
    trunk_pitch_rms = _causal_running_rms(trunk_pitch, int(0.6 * fs_hz)).astype(np.float32)
    pitch_lp = _causal_ema(trunk_pitch, _alpha_from_tau(0.30, fs_hz)).astype(np.float32)
    pitch_hp = (trunk_pitch - pitch_lp).astype(np.float32)
    pitch_lp_rms = _causal_running_rms(pitch_lp, int(0.6 * fs_hz)).astype(np.float32)
    pitch_hp_rms = _causal_running_rms(pitch_hp, int(0.6 * fs_hz)).astype(np.float32)
    trunk_harmonic_ratio = (pitch_lp_rms / np.maximum(pitch_hp_rms, 1e-4)).astype(np.float32)

    leg_length_m = max(0.53 * float(height_m), 0.5)
    excursion = _causal_running_rms(np.deg2rad(thigh_l - thigh_r), int(0.5 * fs_hz))
    step_length_proxy = (leg_length_m * excursion).astype(np.float32)
    step_length_proxy_norm = (excursion).astype(np.float32)
    speed_anchor_geom = (cadence_mean * step_length_proxy).astype(np.float32)
    pseudo_speed_robot = _causal_ema(
        speed_anchor_geom,
        _alpha_from_tau(0.25, fs_hz)
    ).astype(np.float32)
    imu_anchor_speed = compute_imu_integrated_speed(
        body_frame['forward_accel_overground'],
        fs_hz,
        alpha=0.998,
        lpf_cutoff=0.5,
        lpf_order=4,
    ).astype(np.float32)

    anchor_diff_imu_geom = (imu_anchor_speed - speed_anchor_geom).astype(np.float32)
    anchor_diff_imu_pseudo = (imu_anchor_speed - pseudo_speed_robot).astype(np.float32)
    anchor_diff_geom_pseudo = (speed_anchor_geom - pseudo_speed_robot).astype(np.float32)
    anchor_disagreement = (
        np.abs(anchor_diff_imu_geom) +
        np.abs(anchor_diff_imu_pseudo) +
        np.abs(anchor_diff_geom_pseudo)
    ).astype(np.float32)
    anchor_confidence = (1.0 / (1.0 + 2.5 * anchor_disagreement)).astype(np.float32)
    plateau_confidence = (
        anchor_confidence *
        np.clip(trunk_harmonic_ratio / np.maximum(trunk_harmonic_ratio + 1.0, 1e-4), 0.0, 1.0)
    ).astype(np.float32)
    anchor_stack = np.stack(
        [imu_anchor_speed, speed_anchor_geom.astype(np.float32), pseudo_speed_robot.astype(np.float32)],
        axis=0,
    )
    anchor_consensus_speed = np.median(anchor_stack, axis=0).astype(np.float32)
    anchor_consensus_spread = np.mean(
        np.abs(anchor_stack - anchor_consensus_speed[None, :]),
        axis=0,
    ).astype(np.float32)
    highspeed_anchor_hint = np.clip((anchor_consensus_speed - 1.00) / 0.25, 0.0, 1.0).astype(np.float32)

    assist_active_int = assist_active_flag.astype(np.int32)
    time_since_assist_on = np.zeros_like(assist_active_flag, dtype=np.float32)
    time_since_assist_off = np.zeros_like(assist_active_flag, dtype=np.float32)
    on_count = 0
    off_count = 0
    for i in range(len(assist_active_int)):
        if assist_active_int[i]:
            on_count += 1
            off_count = 0
        else:
            off_count += 1
            on_count = 0
        time_since_assist_on[i] = on_count / max(float(fs_hz), 1.0)
        time_since_assist_off[i] = off_count / max(float(fs_hz), 1.0)

    assist_duty_cycle_1s = _causal_ema(assist_active_flag, _alpha_from_tau(1.0, fs_hz)).astype(np.float32)
    assist_duty_cycle_3s = _causal_ema(assist_active_flag, _alpha_from_tau(3.0, fs_hz)).astype(np.float32)
    assist_duty_cycle_5s = _causal_ema(assist_active_flag, _alpha_from_tau(5.0, fs_hz)).astype(np.float32)

    positive_work = np.maximum(power_prop_sum, 0.0).astype(np.float32)
    positive_work_ema_fast = _causal_ema(positive_work, _alpha_from_tau(0.30, fs_hz)).astype(np.float32)
    positive_work_ema_slow = _causal_ema(positive_work, _alpha_from_tau(2.00, fs_hz)).astype(np.float32)
    work_norm_cadence = (
        positive_work_ema_slow / np.maximum(cadence_mean, 0.20)
    ).astype(np.float32)
    work_norm_excursion = (
        positive_work_ema_slow / np.maximum(thigh_excursion_rms, 0.03)
    ).astype(np.float32)
    work_norm_step_time = (
        positive_work_ema_slow / np.maximum(step_time_mean, 0.25)
    ).astype(np.float32)

    thigh_vel_mean = 0.5 * (np.deg2rad(thigh_dot_l) + np.deg2rad(thigh_dot_r))
    hip_vel_mean = 0.5 * (np.deg2rad(hip_dot_l) + np.deg2rad(hip_dot_r))
    trunk_pitch_rate_rms = np.maximum(_causal_running_rms(trunk_pitch_rate, int(0.5 * fs_hz)), 1e-3)
    thigh_vel_mean_rms = np.maximum(_causal_running_rms(thigh_vel_mean, int(0.5 * fs_hz)), 1e-3)
    hip_vel_mean_rms = np.maximum(_causal_running_rms(hip_vel_mean, int(0.5 * fs_hz)), 1e-3)
    trunk_thigh_coherence = _causal_ema(
        (trunk_pitch_rate * thigh_vel_mean) / (trunk_pitch_rate_rms * thigh_vel_mean_rms),
        _alpha_from_tau(0.5, fs_hz),
    ).astype(np.float32)
    trunk_hip_coherence = _causal_ema(
        (trunk_pitch_rate * hip_vel_mean) / (trunk_pitch_rate_rms * hip_vel_mean_rms),
        _alpha_from_tau(0.5, fs_hz),
    ).astype(np.float32)

    expected_excursion = np.clip(
        pseudo_speed_robot / np.maximum(leg_length_m * cadence_mean, 1e-3),
        0.0,
        2.0,
    ).astype(np.float32)
    excursion_residual = (step_length_proxy_norm - expected_excursion).astype(np.float32)

    return {
        'phase_sin_l': phase_sin_l,
        'phase_cos_l': phase_cos_l,
        'phase_sin_r': phase_sin_r,
        'phase_cos_r': phase_cos_r,
        'cadence_l': cadence_l.astype(np.float32),
        'cadence_r': cadence_r.astype(np.float32),
        'cadence_mean': cadence_mean,
        'step_time_mean': step_time_mean,
        'hip_power_l': hip_power_l,
        'hip_power_r': hip_power_r,
        'thigh_power_l': thigh_power_l,
        'thigh_power_r': thigh_power_r,
        'hip_power_pos_l': hip_power_pos_l,
        'hip_power_pos_r': hip_power_pos_r,
        'hip_power_neg_l': hip_power_neg_l,
        'hip_power_neg_r': hip_power_neg_r,
        'thigh_power_pos_l': thigh_power_pos_l,
        'thigh_power_pos_r': thigh_power_pos_r,
        'thigh_power_neg_l': thigh_power_neg_l,
        'thigh_power_neg_r': thigh_power_neg_r,
        'power_prop_sum': power_prop_sum,
        'power_brake_sum': power_brake_sum,
        'phase_diff_sin': phase_diff_sin,
        'phase_diff_cos': phase_diff_cos,
        'hip_angle_diff': hip_angle_diff,
        'thigh_angle_diff': thigh_angle_diff,
        'torque_diff': torque_diff,
        'hip_excursion_rms': hip_excursion_rms,
        'thigh_excursion_rms': thigh_excursion_rms,
        'hip_sep_excursion_rms': hip_sep_excursion_rms,
        'thigh_sep_excursion_rms': thigh_sep_excursion_rms,
        'torque_rms_l': torque_rms_l.astype(np.float32),
        'torque_rms_r': torque_rms_r.astype(np.float32),
        'thigh_vel_rms_l': thigh_vel_rms_l.astype(np.float32),
        'thigh_vel_rms_r': thigh_vel_rms_r.astype(np.float32),
        'gyro_forward_rms': gyro_forward_rms.astype(np.float32),
        'trunk_pitch': trunk_pitch,
        'trunk_pitch_rate': trunk_pitch_rate,
        'trunk_pitch_rms': trunk_pitch_rms,
        'trunk_harmonic_ratio': trunk_harmonic_ratio,
        'imu_anchor_speed_rt': imu_anchor_speed,
        'pseudo_speed_robot': pseudo_speed_robot,
        'step_length_proxy': step_length_proxy,
        'step_length_proxy_norm': step_length_proxy_norm,
        'speed_anchor_geom': speed_anchor_geom,
        'motor_power_l': motor_power_l,
        'motor_power_r': motor_power_r,
        'deflection_l': deflection_l,
        'deflection_r': deflection_r,
        'deflection_vel_l': deflection_vel_l,
        'deflection_vel_r': deflection_vel_r,
        'deflection_rms_l': deflection_rms_l,
        'deflection_rms_r': deflection_rms_r,
        'stiffness_proxy_l': stiffness_proxy_l,
        'stiffness_proxy_r': stiffness_proxy_r,
        'stiffness_proxy_sum': stiffness_proxy_sum,
        'damping_proxy_l': damping_proxy_l,
        'damping_proxy_r': damping_proxy_r,
        'damping_proxy_sum': damping_proxy_sum,
        'torque_abs_ema_fast_l': torque_abs_ema_fast_l,
        'torque_abs_ema_fast_r': torque_abs_ema_fast_r,
        'torque_abs_ema_slow_l': torque_abs_ema_slow_l,
        'torque_abs_ema_slow_r': torque_abs_ema_slow_r,
        'torque_abs_ema_fast_sum': torque_abs_ema_fast_sum,
        'torque_abs_ema_slow_sum': torque_abs_ema_slow_sum,
        'torque_signed_ema_fast_sum': torque_signed_ema_fast_sum,
        'torque_signed_ema_slow_sum': torque_signed_ema_slow_sum,
        'assist_proxy_l': assist_proxy_l,
        'assist_proxy_r': assist_proxy_r,
        'assist_proxy_sum': assist_proxy_sum,
        'torque_stride_impulse_l': torque_stride_impulse_l,
        'torque_stride_impulse_r': torque_stride_impulse_r,
        'torque_stride_impulse_sum': torque_stride_impulse_sum,
        'torque_preview_l_100ms': torque_preview_l_100ms,
        'torque_preview_r_100ms': torque_preview_r_100ms,
        'torque_preview_sum_100ms': torque_preview_sum_100ms,
        'torque_preview_delta_l_100ms': torque_preview_delta_l_100ms,
        'torque_preview_delta_r_100ms': torque_preview_delta_r_100ms,
        'torque_preview_delta_sum_100ms': torque_preview_delta_sum_100ms,
        'assist_active_flag': assist_active_flag,
        'assist_high_flag': assist_high_flag,
        'assist_intensity_norm': assist_intensity_norm,
        'anchor_diff_imu_geom': anchor_diff_imu_geom,
        'anchor_diff_imu_pseudo': anchor_diff_imu_pseudo,
        'anchor_diff_geom_pseudo': anchor_diff_geom_pseudo,
        'anchor_confidence': anchor_confidence,
        'plateau_confidence': plateau_confidence,
        'anchor_consensus_speed': anchor_consensus_speed,
        'anchor_consensus_spread': anchor_consensus_spread,
        'highspeed_anchor_hint': highspeed_anchor_hint,
        'time_since_assist_on': time_since_assist_on,
        'time_since_assist_off': time_since_assist_off,
        'assist_duty_cycle_1s': assist_duty_cycle_1s,
        'assist_duty_cycle_3s': assist_duty_cycle_3s,
        'assist_duty_cycle_5s': assist_duty_cycle_5s,
        'positive_work_ema_fast': positive_work_ema_fast,
        'positive_work_ema_slow': positive_work_ema_slow,
        'work_norm_cadence': work_norm_cadence,
        'work_norm_excursion': work_norm_excursion,
        'work_norm_step_time': work_norm_step_time,
        'trunk_thigh_coherence': trunk_thigh_coherence,
        'trunk_hip_coherence': trunk_hip_coherence,
        'excursion_residual': excursion_residual,
    }


# ---------------------------------------------------------------------------
# Biomechanical Feature Helpers (archive_round5)
# ---------------------------------------------------------------------------

# Anthropometric ratios (Winter, 1990 — % of leg length)
_THIGH_RATIO = 0.530   # thigh ≈ 53% of leg length
_SHANK_RATIO = 0.470   # shank ≈ 47% of leg length

# New derived variable names recognised in extract_condition_data_v2
_CHAIN_VELOCITY_VARS = frozenset([
    'com_velocity_chain',        # combined COM forward velocity from kinematic chain
    'com_velocity_chain_v2',     # v2: absolute segment angles, relaxed filtering
    'segment_vel_ankle',         # ankle segment velocity contribution
    'segment_vel_knee',          # knee segment velocity contribution
    'segment_vel_hip',           # hip/pelvis segment velocity contribution
])

_BIOMECH_LEADING_VARS = frozenset([
    'grf_impulse_l', 'grf_impulse_r',       # anterior-posterior GRF impulse per stance
    'stance_ratio_l', 'stance_ratio_r',      # stance phase duty factor
    'cop_vel_y_l', 'cop_vel_y_r',            # CoP forward velocity (from GRF moments)
    'trunk_pitch_dot',                        # trunk sagittal angular velocity (leading)
])


