# Extracted from data/loader.py — _linvel and _arc feature computation
1320-                            valid_trial = False; break
1321-
1322:                    # 2b. Leg-length normalized features: _linvel and _arc
1323-                    if col_data is None and not gpath.startswith('derived') and v_name.endswith('_linvel'):
1324-                        # hip_angle_linvel = hip_angle_dot × leg_length (m/s)
1325-                        base_name = v_name[:-7]  # strip '_linvel'
1326-                        if base_name in grp and _trial_leg_length is not None:
1327-                            base_data = np.asarray(grp[base_name][:], dtype=np.float32).flatten()
1328-                            d1 = _causal_derivative(base_data, fs)
1329-                            _derived_cutoff = 30.0
1330-                            if input_lpf_per_group is not None and 'velocities' in input_lpf_per_group:
1331-                                _derived_cutoff = input_lpf_per_group['velocities']
1332-                            d1 = _causal_lpf_1d(d1, _derived_cutoff, fs, order=4)
1333-                            col_data = (np.deg2rad(d1) * _trial_leg_length).astype(np.float32)
1334-                        elif base_name not in grp:
1335-                            print(f"[WARN] Base data {base_name} not found for {v_name}")
1336-                            valid_trial = False; break
1337-
