# LinvelA14 — Speed Estimation Model for Jetson Orin NX Deployment

## Model Summary

| Item | Value |
|------|-------|
| Architecture | TCN_GRU_Head (single encoder) |
| Parameters | 14,453 (55 KB) |
| Input | 14 channels @ 100 Hz |
| Output | 1 channel (forward speed, m/s) |
| Window | 300 samples (3.0 s) |
| Receptive Field | 121 samples (1.21 s) |
| Inference Latency | ~1.5 ms (server GPU) |
| Best Fold MAE | 0.0412 m/s (Test-m2_S004) |
| 3-Fold Avg MAE | 0.0569 m/s |

## Input Features (14 channels, order matters)

| Ch | Source | Feature | Unit | Computation |
|----|--------|---------|------|-------------|
| 0 | body_frame_imu | accel_right | m/s² | quat-based body frame projection (stationary heading) |
| 1 | body_frame_imu | accel_forward | m/s² | " |
| 2 | body_frame_imu | accel_up | m/s² | " |
| 3 | body_frame_imu | gyro_right | rad/s | " |
| 4 | body_frame_imu | gyro_forward | rad/s | " |
| 5 | body_frame_imu | gyro_up | rad/s | " |
| 6 | body_frame_imu | forward_accel_overground | m/s² | body forward accel + treadmill accel |
| 7 | imu_integrated_speed | imu_integrated_speed | m/s | leaky integral of ch6 (α=0.998) + causal LPF 0.5Hz |
| 8 | robot/left | hip_angle | deg | raw from exoskeleton encoder |
| 9 | robot/left | hip_angle_linvel | m/s | causal_deriv(hip_angle) × leg_length_mean, LPF 30Hz, deg→rad |
| 10 | robot/right | hip_angle | deg | raw from exoskeleton encoder |
| 11 | robot/right | hip_angle_linvel | m/s | causal_deriv(hip_angle) × leg_length_mean, LPF 30Hz, deg→rad |
| 12 | robot_biomech_rt | cadence_mean | steps/s | causal bilateral cadence estimator |
| 13 | robot_biomech_rt | speed_anchor_geom | m/s | cadence × step_length_proxy |

### hip_angle_linvel Computation

```python
# 1. Causal backward difference derivative
hip_dot = (hip_angle[i] - hip_angle[i-1]) * fs  # fs = 100 Hz

# 2. Causal LPF at 30 Hz
hip_dot_filtered = causal_butterworth_lpf(hip_dot, cutoff=30.0, fs=100, order=4)

# 3. Convert deg/s → rad/s, multiply by leg length
hip_linvel = deg2rad(hip_dot_filtered) * leg_length_mean  # leg_length_mean in meters
```

`leg_length_mean` is computed once per subject: `0.5 * (leg_length_left + leg_length_right)` from anthropometric measurement, or approximated as `0.53 * height_m`.

## Preprocessing Pipeline (all causal / real-time)

```
Raw back_imu (accel_xyz, gyro_xyz, quat_wxyz)
    │
    ▼
Body Frame Transform (body_frame.py)
  - Quaternion sign canonicalization
  - Gravity removal
  - Stationary heading estimation (causal sliding-window PCA)
  - Body frame projection → accel_right/forward/up, gyro_right/forward/up
  - + treadmill accel fusion → forward_accel_overground
    │
    ▼
Leaky Integrator (model_com_speed.py)
  - v[i] = 0.998 * v[i-1] + forward_accel_overground[i] * dt
  - Causal LPF 0.5 Hz → imu_integrated_speed
    │
    ▼
Robot Joint Processing
  - hip_angle: raw encoder reading
  - hip_angle_linvel: backward_diff → causal_LPF(30Hz) → deg2rad → × leg_length
    │
    ▼
Biomech Features (from loader.py / robot_biomech_rt)
  - cadence_mean: causal bilateral step timing
  - speed_anchor_geom: cadence × step_length_proxy
    │
    ▼
Normalization
  - x_norm = (x - mean) / scale
  - mean, scale from scaler.npz (14 values each)
    │
    ▼
Model Input: (1, 300, 14)  →  TCN_GRU_Head  →  speed (m/s)
```

## Model Architecture

```
Input (batch, 300, 14)
    │
InstanceNorm1d(14)
    │
TCN Encoder (4 layers, kernel=5, causal dilated convolution)
  Layer 0 (dilation=1):  Conv1d→BN→ReLU→Conv1d→BN→ReLU + residual skip
  Layer 1 (dilation=2):  Conv1d→BN→ReLU→Conv1d→BN→ReLU + residual skip
  Layer 2 (dilation=4):  Conv1d→BN→ReLU→Conv1d→BN→ReLU + residual skip
  Layer 3 (dilation=8):  Conv1d→BN→ReLU→Conv1d→BN→ReLU + residual skip
  Channels: [12, 12, 24, 24]
    │
GRU (1 layer, input=24, hidden=12)
  → last timestep hidden state
    │
Linear(12 → 1)
    │
Output: predicted speed (m/s)
```

## Runtime Memory (Jetson Orin NX)

| Component | FP32 | FP16 |
|-----------|------|------|
| Model weights | 55 KB | 28 KB |
| TCN causal buffers | ~14 KB | ~7 KB |
| GRU hidden state | 48 B | 24 B |
| Input buffer (300×14) | 16.4 KB | 8.2 KB |
| **Total** | **~86 KB** | **~43 KB** |

## Files

```
linvelA14_deploy/
├── model.pt              # Best fold (S004) trained weights
├── scaler.npz            # Input normalization (mean, scale: shape=(14,))
├── config.yaml           # Full training config
├── metrics.json          # Performance metrics
├── README.md             # This file
├── src/
│   ├── models.py         # TCN_GRU_Head model definition (PyTorch)
│   ├── body_frame.py     # IMU body frame transform
│   ├── model_com_speed.py # Leaky integrator for imu_integrated_speed
│   ├── utils.py          # Butterworth filter utilities
│   └── linvel_computation_from_loader.py  # _linvel feature extraction
└── all_folds/            # All 3 fold results (model.pt, scaler.npz, metrics)
    ├── ..._Test-m2_S001_seed42/  (MAE=0.0532)
    ├── ..._Test-m2_S004_seed42/  (MAE=0.0412, best)
    └── ..._Test-m2_S008_seed42/  (MAE=0.0763)
```

## Notes

- All preprocessing is **causal** (no future samples used) — real-time safe
- The model predicts speed at `y_delay=5` samples (50 ms) ahead
- `scaler.npz` contains per-channel mean/scale computed from training set (excluding test subject)
- For deployment, each fold's scaler is trained without that subject — choose the fold/scaler appropriate for your use case, or average across folds
- Full 8-fold LOSO results will be available after training completes
