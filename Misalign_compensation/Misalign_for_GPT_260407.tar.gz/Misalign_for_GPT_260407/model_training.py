# =========================================================================================
# [CRITICAL NOTICE - 수정 금지 / 변경 시 확인 필수]
# * 이 파일은 [GOLDEN BASELINE] 학습 스크립트입니다.
# * 어떤 이유로든 이 파일(model_training.py)의 내용을 수정해야 한다면, 
#   반드시 수정하기 전에 사용자에게 한국어(Korean)로 변경하려는 내용과 이유를 설명하고 명시적인 허락을 받아야 합니다.
# * 사용자가 "수정해"라고 말하더라도, 이 주석을 상기하며 "정말로 수정하시겠습니까? 
#   이 주석에 따르면 변경 전 재확인이 필요합니다."라고 한 번 더 되물어 확인받으십시오.
# * 안전 장치를 무시하고 임의로 변경하지 마십시오.
# =========================================================================================


import os
import gc
import copy
import pandas as pd
import seaborn as sns
from typing import Optional, List
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["MKL_THREADING_LAYER"] = "GNU"
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import torch
import torch.nn.functional as F
import torch.fft
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
torch.backends.cudnn.benchmark = True

import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import numpy as np
import random
import h5py
import matplotlib.pyplot as plt
import time
from scipy.signal import butter, filtfilt
import yaml
import json
import shutil
import glob
from pathlib import Path
import sys
import platform
import datetime
import argparse
from tqdm import tqdm
from visualize_features import visualize_features
from config_utils import (
    get_config_conditions,
    get_config_input_vars,
    get_config_level_selection,
    get_config_output_vars,
    get_config_subjects,
    get_est_tick_ranges,
    get_input_lpf_cutoff,
    get_input_lpf_order,
    get_primary_data_path,
    get_tcn_channels,
    get_train_data_config,
    get_window_size,
    normalize_experiment_config,
)


import torch.fft as fft

# =========================================================================================




def get_custom_losses(config, device, feature_names=None, scaler_mean=None, scaler_std=None):
    """
    Returns a dictionary of custom loss functions and their weights based on config.
    Structure: {'name': {'fn': func, 'weight': float}}
    """
    losses = {}
    train_cfg = config.get("02_train", {}).get("train", {})

    # 1. Smoothness Loss
    # Checks 'smoothness_loss_weight' in baseline.yaml
    w_smooth = float(train_cfg.get("smoothness_loss_weight", 0.0))
    if w_smooth > 0:
        def smoothness_fn(pred):
            # Total Variation: mean((x_t - x_{t-1})^2)
            diff = pred[:, :, 1:] - pred[:, :, :-1]
            return torch.mean(diff ** 2)
        
        losses["smoothness"] = {"fn": smoothness_fn, "weight": w_smooth}

    # 2. Kinematic/Physics Loss
    # Checks 'kinematic_loss_weight_*' in baseline.yaml
    # Currently a placeholder/stub as full kinematic chain requires body model info.
    w_kin_pos = float(train_cfg.get("kinematic_loss_weight_pos", 0.0))
    w_kin_limit = float(train_cfg.get("kinematic_loss_weight_limit", 0.0))
    
    # If weights are non-zero, we add the function. 
    # For now, if 0, we can skip or add a dummy.
    # The training loop expects fn(xb, pred).
    if w_kin_pos > 0 or w_kin_limit > 0:
        def kinematic_fn(x, pred):
            # Placeholder for kinematic constraints
            # x: Inputs (e.g. joint angles)
            # pred: Outputs (e.g. speeds)
            # Implement physics constraints here if needed.
            return torch.tensor(0.0, device=pred.device)
            
        # We sum the weights for the single 'kinematic' entry expect by the loop
        losses["kinematic"] = {"fn": kinematic_fn, "weight": w_kin_pos + w_kin_limit}

    # 3. Frequency Penalty Loss
    penalty_type = train_cfg.get("loss_penalty")
    if penalty_type == "frequency_cutoff_penalty":
        w_freq = float(train_cfg.get("loss_penalty_weight", 0.0))
        
        def freq_loss_fn(pred, target):
            # pred, target: (B, H, D)
            # FFT along time dimension? But pred is (B, H, D). H is small?
            # Or is it (B, T, D)?
            # TCN_MLP returns (B, H, D). If H=1, it's just point prediction.
            # Frequency analysis requires TIME SEQUENCE.
            # If we predict only 1 point (or 5 points), FFT is useless.
            # WAIT. If we train with Window Output 1, we can't do Frequency Loss on Prediction.
            # Unless we gather a batch? No, batch is shuffled.
            
            # Constraint: Frequency Loss ONLY works if we predict a SEQUENCE (e.g. 50-100 ticks).
            # The current baseline predicts 1 tick (or 5 sparse ticks).
            # The User Request implies "Train to verify frequency".
            # If the model output is too short, we typically penalize the smoothness of the mapping?
            # OR we assume the model output is a sequence (Seq2Seq).
            
            # IF output is Scalar, Freq Loss is impossible per sample.
            # We will perform a dummy check: if seq_len < 10, skip.
            if pred.shape[1] < 10:
                return torch.tensor(0.0, device=pred.device)
                
            # Perform FFT
            freq_pred = torch.fft.rfft(pred, dim=1)
            freq_target = torch.fft.rfft(target, dim=1)
            
            # Penalize high freq magnitude difference?
            # User said: "If speed changes at freq higher than reference > loss increases"
            # Reference (target) implies the "valid" bandwidth.
            # If Pred has power in freq bands where Target has NO power, penalize.
            
            mag_pred = torch.abs(freq_pred)
            mag_target = torch.abs(freq_target)
            
            # Mask: where target power is low (noise floor), penalize pred power
            threshold = 1e-4 # Epsilon
            mask = mag_target < threshold 
            
            penalty = mag_pred * mask.float()
            return torch.mean(penalty)

        if w_freq > 0:
            losses["freq_penalty"] = {"fn": freq_loss_fn, "weight": w_freq}



# data_length removed as requested - using full dataset length dynamically

# Preprocessing Config
fs = 100
# Global config defaults (Constants)
time_window_output = 10
stride = 10

# input_vars, output_vars defined in YAML/base_config now.
# TRAIN_SUBJECTS, VAL_SUBJECTS, TEST_SUBJECTS defined in YAML/base_config now.

def make_subject_selection(include_list):
    return {'include': include_list, 'exclude': []}

def parse_vars(var_list_from_yaml):
    """
    Converts list-based YAML vars [[path, [vars]], ...] to tuple-based list.
    """
    if not var_list_from_yaml:
        return []
    parsed = []
    for item in var_list_from_yaml:
        # item is [gpath, [list_of_vars]]
        if isinstance(item, (list, tuple)) and len(item) >= 2:
            gpath = item[0]
            vars = item[1]
            parsed.append((gpath, vars))
    return parsed


def has_human_thigh_output(output_vars):
    if not output_vars:
        return False
    for gpath, vars_ in output_vars:
        if gpath == "derived/human_thigh":
            return True
    return False

CONDITION_SELECTION = {'include': None, 'exclude': []}
TRIAL_DATASET_CACHE = {}
TRIAL_FEATURE_CACHE = {}


def derive_experiment_root(config_relpath):
    relpath = Path(config_relpath)
    parts = relpath.parts
    if "configs" in parts:
        cfg_idx = parts.index("configs")
        rel_parts = parts[cfg_idx + 1:]
        relpath = Path(*rel_parts) if rel_parts else Path("")
    parent = relpath.parent
    if str(parent) in ("", "."):
        return Path("experiments")
    return Path("experiments") / parent


def freeze_nested(value):
    if isinstance(value, dict):
        return tuple(sorted((k, freeze_nested(v)) for k, v in value.items()))
    if isinstance(value, (list, tuple)):
        return tuple(freeze_nested(v) for v in value)
    return value


def get_trial_cache_entry(source_path, sub, cond, level, trial_name, fs):
    cache_key = (str(source_path), sub, cond, level, trial_name, fs)
    cached = TRIAL_FEATURE_CACHE.get(cache_key)
    if cached is None:
        cached = {
            "raw_groups": {},
            "derived": {},
            "outputs": {},
        }
        TRIAL_FEATURE_CACHE[cache_key] = cached
    return cached


def get_trial_group_array(trial_cache, trial_group, gpath, v_name, dtype=np.float32):
    raw_group_cache = trial_cache["raw_groups"].setdefault(gpath, {})
    if v_name in raw_group_cache:
        return raw_group_cache[v_name]

    grp = trial_group
    for part in gpath.split('/'):
        if part in grp:
            grp = grp[part]
        else:
            return None

    if v_name not in grp:
        return None

    arr = np.asarray(grp[v_name][:], dtype=dtype)
    raw_group_cache[v_name] = arr
    return arr


def get_or_build_trial_cache_value(trial_cache, namespace, cache_key, builder):
    cache_bucket = trial_cache[namespace]
    if cache_key not in cache_bucket:
        cache_bucket[cache_key] = builder()
    return cache_bucket[cache_key]


def canonicalize_quaternion_sequence(quat_array):
    """
    Enforce temporal sign continuity for quaternion sequences.
    q and -q encode the same rotation; this keeps consecutive samples in one hemisphere.
    """
    quat = np.asarray(quat_array, dtype=np.float32).copy()
    if quat.ndim != 2 or quat.shape[0] < 2 or quat.shape[1] != 4:
        return quat

    # Normalize first to make the dot-product continuity test stable.
    norms = np.linalg.norm(quat, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    quat /= norms

    for i in range(1, quat.shape[0]):
        if np.dot(quat[i - 1], quat[i]) < 0:
            quat[i] = -quat[i]
    return quat


def normalize_vector(vec, eps=1e-8):
    arr = np.asarray(vec, dtype=np.float32)
    norm = np.linalg.norm(arr)
    if norm < eps:
        return np.zeros_like(arr)
    return arr / norm


def normalize_vectors(vecs, axis=-1, eps=1e-8):
    arr = np.asarray(vecs, dtype=np.float32)
    norms = np.linalg.norm(arr, axis=axis, keepdims=True)
    norms[norms < eps] = 1.0
    return arr / norms


def quat_wxyz_to_rotmat_batch(quat_wxyz):
    quat = normalize_vectors(quat_wxyz, axis=1)
    if quat.ndim != 2 or quat.shape[1] != 4:
        return np.zeros((0, 3, 3), dtype=np.float32)

    w, x, y, z = quat[:, 0], quat[:, 1], quat[:, 2], quat[:, 3]
    rot = np.empty((quat.shape[0], 3, 3), dtype=np.float32)
    rot[:, 0, 0] = 1.0 - 2.0 * (y * y + z * z)
    rot[:, 0, 1] = 2.0 * (x * y - z * w)
    rot[:, 0, 2] = 2.0 * (x * z + y * w)
    rot[:, 1, 0] = 2.0 * (x * y + z * w)
    rot[:, 1, 1] = 1.0 - 2.0 * (x * x + z * z)
    rot[:, 1, 2] = 2.0 * (y * z - x * w)
    rot[:, 2, 0] = 2.0 * (x * z - y * w)
    rot[:, 2, 1] = 2.0 * (y * z + x * w)
    rot[:, 2, 2] = 1.0 - 2.0 * (x * x + y * y)
    return rot


def project_to_plane(vec, plane_normal):
    plane_normal = normalize_vector(plane_normal)
    vec = np.asarray(vec, dtype=np.float32)
    return vec - np.dot(vec, plane_normal) * plane_normal


def safe_signal_correlation(a, b, eps=1e-6):
    a = np.asarray(a, dtype=np.float32).reshape(-1)
    b = np.asarray(b, dtype=np.float32).reshape(-1)
    if a.shape[0] != b.shape[0] or a.shape[0] < 5:
        return 0.0
    a = a - np.mean(a)
    b = b - np.mean(b)
    a_std = float(np.std(a))
    b_std = float(np.std(b))
    if a_std < eps or b_std < eps:
        return 0.0
    return float(np.mean((a / a_std) * (b / b_std)))


def resolve_feature_indices(feature_names, patterns):
    if not feature_names or not patterns:
        return []

    indices = []
    for i, name in enumerate(feature_names):
        for pattern in patterns:
            if pattern and pattern in name:
                indices.append(i)
                break
    return sorted(set(indices))


def estimate_gravity_aligned_features(acc_local, gyro_local, quat_wxyz, a_tread, fs):
    quat_wxyz = canonicalize_quaternion_sequence(quat_wxyz)
    rot_gi = quat_wxyz_to_rotmat_batch(quat_wxyz)
    if rot_gi.shape[0] == 0:
        raise ValueError("Quaternion sequence is empty or invalid.")

    acc_global = np.einsum('nij,nj->ni', rot_gi, acc_local).astype(np.float32)
    gyro_global = np.einsum('nij,nj->ni', rot_gi, gyro_local).astype(np.float32)

    ref_len = min(len(acc_global), max(20, int(fs * 2.0)))
    gyro_ref = np.linalg.norm(gyro_global[:ref_len], axis=1)
    ref_mask = gyro_ref < 0.15
    ref_idx = np.where(ref_mask)[0]
    if len(ref_idx) < max(10, int(0.3 * fs)):
        ref_idx = np.arange(min(ref_len, max(20, int(fs * 1.0))))

    z_up = normalize_vector(np.mean(acc_global[ref_idx], axis=0))
    if np.linalg.norm(z_up) < 1e-6:
        z_up = np.array([0.0, 0.0, 1.0], dtype=np.float32)

    sensor_x_global = np.einsum('nij,j->ni', rot_gi, np.array([1.0, 0.0, 0.0], dtype=np.float32))
    sensor_y_global = np.einsum('nij,j->ni', rot_gi, np.array([0.0, 1.0, 0.0], dtype=np.float32))
    x_right = project_to_plane(np.mean(sensor_x_global[ref_idx], axis=0), z_up)
    forward_prior = project_to_plane(np.mean(sensor_y_global[ref_idx], axis=0), z_up)
    if np.linalg.norm(x_right) < 1e-6:
        if np.linalg.norm(forward_prior) < 1e-6:
            forward_prior = project_to_plane(np.array([0.0, 1.0, 0.0], dtype=np.float32), z_up)
        x_right = np.cross(forward_prior, z_up)
    x_right = normalize_vector(x_right)
    if np.linalg.norm(x_right) < 1e-6:
        x_right = np.array([1.0, 0.0, 0.0], dtype=np.float32)

    y_forward = normalize_vector(np.cross(z_up, x_right))
    if np.linalg.norm(forward_prior) > 1e-6 and np.dot(y_forward, normalize_vector(forward_prior)) < 0.0:
        y_forward = -y_forward
        x_right = -x_right

    g_mag = float(np.mean(np.linalg.norm(acc_global[ref_idx], axis=1)))
    acc_lin_global = acc_global - g_mag * z_up[None, :]

    body_rot_bg_single = np.stack([x_right, y_forward, z_up], axis=1).astype(np.float32)
    body_rot_bg = np.repeat(body_rot_bg_single[None, :, :], len(acc_global), axis=0)
    body_rot_gb = np.transpose(body_rot_bg, (0, 2, 1))
    acc_body = np.einsum('nij,nj->ni', body_rot_gb, acc_lin_global).astype(np.float32)
    gyro_body = np.einsum('nij,nj->ni', body_rot_gb, gyro_global).astype(np.float32)
    forward_accel_overground = acc_body[:, 1] + a_tread.astype(np.float32)

    return {
        'acc_global': acc_global,
        'acc_linear_global': acc_lin_global.astype(np.float32),
        'gyro_global': gyro_global,
        'body_rot_bg': body_rot_bg,
        'acc_body': acc_body,
        'gyro_body': gyro_body,
        'forward_accel_overground': forward_accel_overground[:, None].astype(np.float32),
    }


def estimate_symmetry_heading_features(acc_local, gyro_local, quat_wxyz, a_tread, fs, symmetry_signal):
    gravity_cache = estimate_gravity_aligned_features(acc_local, gyro_local, quat_wxyz, a_tread, fs)
    acc_base = gravity_cache['acc_body']
    gyro_base = gravity_cache['gyro_body']
    base_rot = gravity_cache['body_rot_bg'][0]
    x_right_base = base_rot[:, 0].astype(np.float32)
    y_forward_base = base_rot[:, 1].astype(np.float32)
    z_up = base_rot[:, 2].astype(np.float32)

    symmetry_signal = np.asarray(symmetry_signal, dtype=np.float32).reshape(-1)
    if symmetry_signal.shape[0] != acc_base.shape[0]:
        raise ValueError("symmetry_signal length does not match IMU sequence length.")

    n = acc_base.shape[0]
    yaw_offset = np.zeros(n, dtype=np.float32)
    body_rot_bg = np.zeros((n, 3, 3), dtype=np.float32)
    acc_body = np.zeros_like(acc_base, dtype=np.float32)
    gyro_body = np.zeros_like(gyro_base, dtype=np.float32)

    update_stride = max(1, int(fs * 0.05))
    window = max(30, int(fs * 0.8))
    heading_alpha = 0.2
    yaw_prev = 0.0
    search_deg = np.array([-20.0, -12.0, -8.0, -4.0, 0.0, 4.0, 8.0, 12.0, 20.0], dtype=np.float32)

    base_ax = acc_base[:, 0]
    base_ay = acc_base[:, 1]
    base_gx = gyro_base[:, 0]
    base_gy = gyro_base[:, 1]

    for i in range(n):
        if i == 0 or i % update_stride == 0:
            start = max(0, i - window + 1)
            sym_win = symmetry_signal[start:i + 1]
            if sym_win.shape[0] >= max(20, int(fs * 0.25)) and float(np.std(sym_win)) > 1e-3:
                acc_x_win = base_ax[start:i + 1]
                acc_y_win = base_ay[start:i + 1]
                gyro_x_win = base_gx[start:i + 1]
                gyro_y_win = base_gy[start:i + 1]

                best_score = None
                best_yaw = yaw_prev
                for delta_deg in search_deg:
                    yaw_cand = yaw_prev + np.deg2rad(float(delta_deg))
                    c = float(np.cos(yaw_cand))
                    s = float(np.sin(yaw_cand))
                    lat_acc = c * acc_x_win - s * acc_y_win
                    fwd_acc = s * acc_x_win + c * acc_y_win
                    lat_gyro = c * gyro_x_win - s * gyro_y_win
                    fwd_gyro = s * gyro_x_win + c * gyro_y_win

                    lat_score = abs(safe_signal_correlation(lat_acc, sym_win)) + 0.35 * abs(safe_signal_correlation(lat_gyro, sym_win))
                    fwd_penalty = 0.6 * abs(safe_signal_correlation(fwd_acc, sym_win)) + 0.2 * abs(safe_signal_correlation(fwd_gyro, sym_win))
                    smooth_penalty = 0.01 * abs(float(delta_deg))
                    score = fwd_penalty + smooth_penalty - lat_score

                    if best_score is None or score < best_score:
                        best_score = score
                        best_yaw = yaw_cand

                yaw_prev = float((1.0 - heading_alpha) * yaw_prev + heading_alpha * best_yaw)

        yaw_offset[i] = yaw_prev
        c = float(np.cos(yaw_prev))
        s = float(np.sin(yaw_prev))
        x_right = c * x_right_base - s * y_forward_base
        y_forward = s * x_right_base + c * y_forward_base

        body_rot_bg[i, :, 0] = x_right
        body_rot_bg[i, :, 1] = y_forward
        body_rot_bg[i, :, 2] = z_up

        acc_body[i, 0] = c * base_ax[i] - s * base_ay[i]
        acc_body[i, 1] = s * base_ax[i] + c * base_ay[i]
        acc_body[i, 2] = acc_base[i, 2]
        gyro_body[i, 0] = c * base_gx[i] - s * base_gy[i]
        gyro_body[i, 1] = s * base_gx[i] + c * base_gy[i]
        gyro_body[i, 2] = gyro_base[i, 2]

    forward_accel_overground = acc_body[:, 1] + a_tread.astype(np.float32)
    out = dict(gravity_cache)
    out['body_rot_bg'] = body_rot_bg
    out['acc_body'] = acc_body.astype(np.float32)
    out['gyro_body'] = gyro_body.astype(np.float32)
    out['forward_accel_overground'] = forward_accel_overground[:, None].astype(np.float32)
    out['heading_yaw_offset_rad'] = yaw_offset[:, None].astype(np.float32)
    return out


def estimate_body_frame_features(acc_local, gyro_local, quat_wxyz, a_tread, fs):
    quat_wxyz = canonicalize_quaternion_sequence(quat_wxyz)
    rot_gi = quat_wxyz_to_rotmat_batch(quat_wxyz)
    if rot_gi.shape[0] == 0:
        raise ValueError("Quaternion sequence is empty or invalid.")

    acc_global = np.einsum('nij,nj->ni', rot_gi, acc_local).astype(np.float32)
    gyro_global = np.einsum('nij,nj->ni', rot_gi, gyro_local).astype(np.float32)

    ref_len = min(len(acc_global), max(20, int(fs * 2.0)))
    gyro_ref = np.linalg.norm(gyro_global[:ref_len], axis=1)
    ref_mask = gyro_ref < 0.15
    ref_idx = np.where(ref_mask)[0]
    if len(ref_idx) < max(10, int(0.3 * fs)):
        ref_idx = np.arange(min(ref_len, max(20, int(fs * 1.0))))

    z_up = normalize_vector(np.mean(acc_global[ref_idx], axis=0))
    if np.linalg.norm(z_up) < 1e-6:
        z_up = np.array([0.0, 0.0, 1.0], dtype=np.float32)

    sensor_y_global = np.einsum('nij,j->ni', rot_gi, np.array([0.0, 1.0, 0.0], dtype=np.float32))
    forward_prior = project_to_plane(np.mean(sensor_y_global[ref_idx], axis=0), z_up)
    if np.linalg.norm(forward_prior) < 1e-6:
        sensor_z_global = np.einsum('nij,j->ni', rot_gi, np.array([0.0, 0.0, 1.0], dtype=np.float32))
        forward_prior = project_to_plane(np.mean(sensor_z_global[ref_idx], axis=0), z_up)
    if np.linalg.norm(forward_prior) < 1e-6:
        forward_prior = project_to_plane(np.array([0.0, 1.0, 0.0], dtype=np.float32), z_up)
    forward_prior = normalize_vector(forward_prior)
    forward_prev = forward_prior.copy()

    g_mag = float(np.mean(np.linalg.norm(acc_global[ref_idx], axis=1)))
    acc_lin_global = acc_global - g_mag * z_up[None, :]
    horiz_all = acc_lin_global - np.einsum('ij,j->i', acc_lin_global, z_up)[:, None] * z_up[None, :]

    body_rot_bg = np.zeros((len(acc_global), 3, 3), dtype=np.float32)
    window = max(20, int(fs * 1.5))
    motion_rms_threshold = 0.15
    gyro_rms_threshold = 0.08
    forward_update_alpha = 0.15
    forward_idle_alpha = 0.02
    horiz_energy_csum = np.concatenate([
        np.zeros(1, dtype=np.float64),
        np.cumsum(np.sum(horiz_all * horiz_all, axis=1), dtype=np.float64),
    ])
    gyro_norm = np.linalg.norm(gyro_global, axis=1)
    gyro_csum = np.concatenate([
        np.zeros(1, dtype=np.float64),
        np.cumsum(gyro_norm, dtype=np.float64),
    ])
    horiz_cov_csum = np.concatenate([
        np.zeros((1, 3, 3), dtype=np.float64),
        np.cumsum(horiz_all[:, :, None] * horiz_all[:, None, :], axis=0, dtype=np.float64),
    ], axis=0)

    for i in range(len(acc_global)):
        start = max(0, i - window + 1)
        window_len = i - start + 1
        horiz_energy = float(horiz_energy_csum[i + 1] - horiz_energy_csum[start])
        horiz_rms = float(np.sqrt(horiz_energy / max(window_len, 1)))
        gyro_rms = float((gyro_csum[i + 1] - gyro_csum[start]) / max(window_len, 1))
        is_moving = window_len >= 5 and (horiz_rms > motion_rms_threshold or gyro_rms > gyro_rms_threshold)

        if is_moving:
            cov = (horiz_cov_csum[i + 1] - horiz_cov_csum[start]).astype(np.float32)
            eigvals, eigvecs = np.linalg.eigh(cov)
            forward = eigvecs[:, int(np.argmax(eigvals))].astype(np.float32)
            forward = project_to_plane(forward, z_up)
            forward = normalize_vector(forward)
            if np.linalg.norm(forward) < 1e-6:
                forward = forward_prev
            if np.dot(forward, forward_prev) < 0.0:
                forward = -forward
            forward = normalize_vector((1.0 - forward_update_alpha) * forward_prev + forward_update_alpha * forward)
        else:
            forward = normalize_vector((1.0 - forward_idle_alpha) * forward_prev + forward_idle_alpha * forward_prior)

        x_right = normalize_vector(np.cross(forward, z_up))
        if np.linalg.norm(x_right) < 1e-6:
            x_right = np.array([1.0, 0.0, 0.0], dtype=np.float32)
        y_forward = normalize_vector(np.cross(z_up, x_right))
        if np.dot(y_forward, forward_prev) < 0.0:
            y_forward = -y_forward
            x_right = -x_right

        body_rot_bg[i, :, 0] = x_right
        body_rot_bg[i, :, 1] = y_forward
        body_rot_bg[i, :, 2] = z_up
        forward_prev = y_forward

    body_rot_gb = np.transpose(body_rot_bg, (0, 2, 1))
    acc_body = np.einsum('nij,nj->ni', body_rot_gb, acc_lin_global).astype(np.float32)
    gyro_body = np.einsum('nij,nj->ni', body_rot_gb, gyro_global).astype(np.float32)
    forward_accel_overground = acc_body[:, 1] + a_tread.astype(np.float32)

    return {
        'acc_global': acc_global,
        'acc_linear_global': acc_lin_global.astype(np.float32),
        'gyro_global': gyro_global,
        'body_rot_bg': body_rot_bg,
        'acc_body': acc_body,
        'gyro_body': gyro_body,
        'forward_accel_overground': forward_accel_overground[:, None].astype(np.float32),
    }

# -------------------------------------------------------------------------------------------------
# Helper Functions (Dataset, Plotting, etc) -> Copy from original
# -------------------------------------------------------------------------------------------------



# Filtering check logic removed.

def get_ground_contact(grf_fz, threshold=20.0):
    return (np.nan_to_num(grf_fz) > threshold).astype(float)

def butter_lowpass_filter(data, cutoff, fs, order=4):
    from scipy.signal import butter, filtfilt
    nyq = 0.5 * fs
    normal_cutoff = cutoff / nyq
    b, a = butter(order, normal_cutoff, btype='low', analog=False)
    if data.ndim == 1:
        y = filtfilt(b, a, data)
    else:
        y = filtfilt(b, a, data, axis=0)
    return y

class ComplementaryFilter:
    def __init__(self, alpha=0.98, fs=100.0):
        self.alpha = alpha
        self.dt = 1.0 / fs
        # State: [Roll, Pitch, Yaw] in radians
        self.angle = np.zeros(3)
        self.initialized = False

    def update(self, acc, gyro):
        """
        acc: (N, 3) accel in m/s^2 [ax, ay, az]
        gyro: (N, 3) gyro in rad/s [gx, gy, gz]
        Returns: (N, 3) Euler angles [Roll, Pitch, Yaw] in degrees
        """
        N = len(acc)
        if N == 0:
            return np.zeros((0, 3))
            
        # 1. Accelerometer Angle (Tilt) Vectorized
        ax, ay, az = acc[:, 0], acc[:, 1], acc[:, 2]
        gx, gy, gz = gyro[:, 0], gyro[:, 1], gyro[:, 2]
        
        acc_roll = np.arctan2(ay, az)
        acc_pitch = np.arctan2(-ax, np.sqrt(ay**2 + az**2))
        
        # Initialization
        if not self.initialized:
            self.angle[0] = acc_roll[0]
            self.angle[1] = acc_pitch[0]
            self.angle[2] = 0.0 # Initial Yaw
            self.initialized = True
            
        # 2. Fast IIR Vectorized Integration using scipy.signal.lfilter
        from scipy.signal import lfilter
        
        # Complementary Filter Difference Equation:
        # angle[n] = alpha * angle[n-1] + alpha * gyro[n] * dt + (1 - alpha) * acc_angle[n]
        # Rewrite for lfilter:
        # y[n] - alpha * y[n-1] = alpha * dt * gyro[n] + (1 - alpha) * acc_angle[n]
        # a = [1.0, -alpha]
        # b = [1.0] 
        # input x[n] = alpha * dt * gyro[n] + (1 - alpha) * acc_angle[n]
        # Except Yaw, which is just accumulating gyro: y[n] - y[n-1] = dt * gyro[n]
        
        alpha = self.alpha
        dt = self.dt
        
        # Coefficients for Roll/Pitch: a[0]*y[n] = b[0]*x[n] - a[1]*y[n-1] -> y[n] = x[n] + alpha*y[n-1]
        a_rp = [1.0, -alpha]
        b_rp = [1.0]
        
        # Inputs for Roll and Pitch
        # Note: In standard CF, rate integrated is added to previous state.
        # But this standard filter formula x[n] = (1-alpha)*acc[n] + alpha*rate[n]*dt is an approximation.
        # It's identical to the iterative: angle[i] = alpha*(angle[i-1] + rate[i]*dt) + (1-alpha)*acc[i]
        # Which reduces to: angle[i] - alpha*angle[i-1] = alpha*rate[i]*dt + (1-alpha)*acc[i]
        
        x_roll = alpha * dt * gx + (1.0 - alpha) * acc_roll
        x_pitch = alpha * dt * gy + (1.0 - alpha) * acc_pitch
        
        # Apply filter with initial conditions
        # To get matching lfilter outputs with initial state, we use zi
        import scipy.signal
        zi_roll = scipy.signal.lfilter_zi(b_rp, a_rp) * self.angle[0]
        zi_pitch = scipy.signal.lfilter_zi(b_rp, a_rp) * self.angle[1]
        
        roll_seq, _ = lfilter(b_rp, a_rp, x_roll, zi=zi_roll)
        pitch_seq, _ = lfilter(b_rp, a_rp, x_pitch, zi=zi_pitch)
        
        # Yaw is pure integration. lfilter_zi fails with Singular matrix for a=[1, -1].
        # Use simple cumulative sum instead for Jaw integration
        d_yaw = gz * dt
        yaw_seq = self.angle[2] + np.cumsum(d_yaw)
        
        # Combine
        angles = np.column_stack((roll_seq, pitch_seq, yaw_seq))
        
        # Update state using final states from sequences
        self.angle = angles[-1].copy()
            
        return np.degrees(angles)



class ExperimentLogger:
    def __init__(self, log_dir):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.csv_path = self.log_dir / "train_log.csv"
        self.log_file = open(self.csv_path, "w")
        self.log_file.write("epoch,train_loss,val_loss,lr,time\n")
        
    def log_epoch(self, epoch, train_loss, val_loss, lr, duration):
        self.log_file.write(f"{epoch},{train_loss:.6f},{val_loss:.6f},{lr:.2e},{duration:.2f}\n")
        self.log_file.flush()
        
    def close(self):
        self.log_file.close()
        
    def save_env(self):
        with open(self.log_dir / "env.txt", "w") as f:
            f.write(f"Date: {datetime.datetime.now()}\n")
            f.write(f"Python: {sys.version}\n")
            f.write(f"Platform: {platform.platform()}\n")
            # Could add pip freeze here if needed
            
    def save_metrics(self, metrics_dict):
        # Convert numpy types to native python for JSON serialization
        def convert(o):
            if isinstance(o, np.integer): return int(o)
            if isinstance(o, np.floating): return float(o)
            if isinstance(o, np.ndarray): return o.tolist()
            return str(o)
            
        with open(self.log_dir / "metrics.json", "w") as f:
            json.dump(metrics_dict, f, indent=4, default=convert)

    def save_config(self, config):
        with open(self.log_dir / "config.yaml", "w") as f:
            yaml.dump(config, f, default_flow_style=False)

class LazyWindowDataset(Dataset):
    def __init__(self, X_list, Y_list, input_window, output_window, stride, target_mode="sequence", est_tick_ranges=None, augment=False, noise_std=0.0,
                 standing_loss_weight=1.0, standing_std_threshold=2.0):
        """
        X_list: list of np.array (T, D_in) - Raw time series
        Y_list: list of np.array (T, D_out)
        target_mode: 'sequence', 'mean', 'last' (Used only if est_tick_ranges is None)
        est_tick_ranges: list of ints, e.g. [1, 2, 3] or [10]. If set, Y is (D_out, len(ranges)) or similar
        augment: bool, if True apply random noise
        noise_std: float, standard deviation of Gaussian noise
        standing_loss_weight: float, weight multiplier for standing (low-variance) windows (1.0 = disabled)
        standing_std_threshold: float, Y std below this → standing phase (degrees)
        """
        self.X_list = [torch.from_numpy(x).float() for x in X_list]
        self.Y_list = [torch.from_numpy(y).float() for y in Y_list]
        self.input_window = input_window
        self.output_window = output_window
        self.stride = stride
        self.target_mode = target_mode
        self.est_tick_ranges = est_tick_ranges
        self.augment = augment
        self.noise_std = noise_std
        self.use_standing_weight = (standing_loss_weight > 1.0)
        self.standing_loss_weight = standing_loss_weight
        self.standing_std_threshold = standing_std_threshold

        # Determine max lookahead for validity check
        if self.est_tick_ranges:
            self.max_lookahead = max(self.est_tick_ranges)
        else:
            self.max_lookahead = output_window

        # Pre-calculate valid indices vectorized
        import numpy as np

        # We need pairs of (series_idx, start_time_idx)
        # Instead of doing a python for loop over millions of points, we build arrays

        s_idxs = []
        t_idxs = []
        for s_idx, x_data in enumerate(self.X_list):
            length = x_data.shape[0]
            limit = length - input_window - self.max_lookahead + 1
            if limit > 0:
                t_arr = np.arange(0, limit, stride)
                s_arr = np.full_like(t_arr, fill_value=s_idx)
                t_idxs.append(t_arr)
                s_idxs.append(s_arr)

        if len(s_idxs) > 0:
            all_s = np.concatenate(s_idxs)
            all_t = np.concatenate(t_idxs)
            # Store as structured array or tuple of arrays instead of millions of python tuples
            self.indices_s = all_s
            self.indices_t = all_t
        else:
            self.indices_s = np.array([], dtype=int)
            self.indices_t = np.array([], dtype=int)

        # Pre-compute per-sample standing weights
        if self.use_standing_weight and len(self.indices_s) > 0:
            self._precompute_standing_weights()
        else:
            self.sample_weights = None
            
    def _precompute_standing_weights(self):
        """Pre-compute per-sample weights: standing windows get higher weight."""
        import numpy as np
        n = len(self.indices_s)
        weights = np.ones(n, dtype=np.float32)
        standing_count = 0
        for i in range(n):
            s_idx = self.indices_s[i]
            t = self.indices_t[i]
            y_np = self.Y_list[s_idx].numpy()
            # Check variance of Y in the input window region
            y_win = y_np[t : t + self.input_window]
            win_std = np.std(y_win, axis=0).mean()
            if win_std < self.standing_std_threshold:
                weights[i] = self.standing_loss_weight
                standing_count += 1
        self.sample_weights = torch.from_numpy(weights).float()
        print(f"[Standing Weight] {standing_count}/{n} samples ({standing_count/max(n,1)*100:.1f}%) "
              f"detected as standing (std<{self.standing_std_threshold}), weight={self.standing_loss_weight}")

    def __len__(self):
        return len(self.indices_s)

    def __getitem__(self, idx):
        s_idx = self.indices_s[idx]
        t = self.indices_t[idx]

        x_data = self.X_list[s_idx]
        y_data = self.Y_list[s_idx]

        limit = t + self.input_window

        x_win = x_data[t : limit].clone() # Clone to avoid modifying original or shared memory issues if augmenting

        if self.augment and self.noise_std > 0:
            x_win += torch.randn_like(x_win) * self.noise_std

        if self.est_tick_ranges:
            y_indices = [(limit + k - 1) for k in self.est_tick_ranges]
            y_win = y_data[y_indices] # (Len(ranges), D_out)
        else:
            # Continuous Sequence Mode
            end = limit + self.output_window
            y_win = y_data[limit : end] # Sequence target (Win_Out, D_out)

        if self.target_mode == "mean":
            y_win = y_win.mean(dim=0)
        elif self.target_mode == "last":
            y_win = y_win[-1, :]

        # Keep the common single-step target as (D_out) instead of (1, D_out).
        # This avoids silent broadcasting against model outputs shaped (B, D_out).
        if y_win.dim() == 2 and y_win.shape[0] == 1:
            y_win = y_win.squeeze(0)

        if self.sample_weights is not None:
            return x_win, y_win, self.sample_weights[idx]

        return x_win, y_win

def extract_condition_data_v2(
    f, sub, cond,
    input_vars, output_vars,
    fs=100,
    include_levels=None, include_trials=None,
    use_physical_velocity_model=False,
    use_gait_phase=False,
    input_lpf_cutoff=None, input_lpf_order=4,
    use_complementary_filter_euler=False,
    residual_target=False,
    calibrate_robot_thigh=False
):
    """
    input_vars, output_vars: list of (group_path, [var_names...])
    Return: (T, InDim), (T, OutDim)
    """
    
    # -------------------------------------------------------------------------
    # 1. Locate All Trials (Iterate Levels)
    # -------------------------------------------------------------------------
    if sub not in f or cond not in f[sub]:
        # print(f"[DEBUG] {sub}/{cond}: Missing group")
        return [], []

    # New Hierarchy: Subject -> Condition -> Level (lv0, lv4...) -> Trial (trial_01...)
    # We aggregate all trials found under all levels for this condition? 
    # Or just concatenate them? For now, let's concatenate all valid trials found.
    
    cond_group = f[sub][cond]
    level_keys = list(cond_group.keys()) # e.g. ['lv0', 'lv4']
    
    valid_trials_data = [] # List of (in_arr, out_arr) to be stacked or returned?
    # Actually, the original code returned a single array for the condition. 
    # If a condition has multiple trials (or levels), we should probably concatenate them along time 
    # OR return a list of trials. The caller `build_nn_dataset` logic:
    # `X_arr, Y_arr = extract...` then it creates windows.
    # If we concatenate unrelated trials, we create a jump discontinuity.
    # Ideally, we should yield trials or return a list.
    # BUT to keep changes minimal to `build_nn_dataset`, let's concatenate but insert a delimiter/gap if possible,
    # OR just accept the small discontinuity if it's treated as one long stream.
    # Better approach: Iterate and concat. 
    # Note: `build_nn_dataset` creates windows. If we concat, we risk a window spanning across trials.
    # However, standard practice often ignores this or uses a large gap.
    # Let's just concat for now to fit the signature.

    in_list_all = []
    out_list_all = []

    for lv in level_keys:
        if include_levels and lv not in include_levels:
             continue # Filter Level
             
        lv_group = cond_group[lv]
        trial_keys = list(lv_group.keys()) # e.g. ['trial_01']
        
        for trial_name in trial_keys:
            if include_trials and trial_name not in include_trials:
                 continue # Filter Trial
            trial_group = lv_group[trial_name]
            trial_cache = get_trial_cache_entry(getattr(f, "filename", "<memory>"), sub, cond, lv, trial_name, fs)
            
            # --- Per Trial Extraction ---
            
            # buffers for augmentation
            kin_q_arrays = []  # list of (data_array, var_name)
            left_fz = None
            right_fz = None
            
            curr_trial_in = []
            body_frame_cache = None
            
            # (A) Standard Load Inputs (Explicit)
            valid_trial = True

            target_is_human_thigh = has_human_thigh_output(output_vars)

            # [NEW] Pre-calculate Robot Thigh Angle Calibration Offsets
            robot_offset_L = 0.0
            robot_offset_R = 0.0
            def get_trial_signal(gpath, v_name, dtype=np.float32):
                return get_trial_group_array(trial_cache, trial_group, gpath, v_name, dtype=dtype)

            # Helper to get base data
            def get_data_from_group(g, path):
                del g
                if '/' not in path:
                    return None
                grp_path, v_name = path.rsplit('/', 1)
                return get_trial_signal(grp_path, v_name)

            def get_robot_offsets():
                def _build_offsets():
                    if target_is_human_thigh:
                        robot_l = get_trial_signal('robot/left', 'thigh_angle')
                        robot_r = get_trial_signal('robot/right', 'thigh_angle')
                        mocap_hip_l = get_trial_signal('mocap/kin_q', 'hip_flexion_l')
                        mocap_hip_r = get_trial_signal('mocap/kin_q', 'hip_flexion_r')
                        mocap_pelvis_tilt = get_trial_signal('mocap/kin_q', 'pelvis_tilt')
                        if robot_l is None or robot_r is None or mocap_hip_l is None or mocap_hip_r is None or mocap_pelvis_tilt is None:
                            return (0.0, 0.0)
                        # Human global sagittal thigh angle approximation:
                        # pelvis_tilt + hip_flexion
                        target_l = mocap_pelvis_tilt + mocap_hip_l
                        target_r = mocap_pelvis_tilt + mocap_hip_r
                    else:
                        robot_l = get_trial_signal('robot/left', 'hip_angle')
                        robot_r = get_trial_signal('robot/right', 'hip_angle')
                        mocap_hip_l = get_trial_signal('mocap/kin_q', 'hip_flexion_l')
                        mocap_hip_r = get_trial_signal('mocap/kin_q', 'hip_flexion_r')
                        mocap_pelvis = get_trial_signal('mocap/kin_q', 'pelvis_list')

                        if robot_l is None or robot_r is None or mocap_hip_l is None or mocap_hip_r is None or mocap_pelvis is None:
                            return (0.0, 0.0)
                        target_l = mocap_hip_l - mocap_pelvis
                        target_r = mocap_hip_r - mocap_pelvis

                    calib_len = min(100, len(robot_l), len(target_l), len(robot_r), len(target_r))
                    if calib_len <= 0:
                        return (0.0, 0.0)

                    offset_l = float(np.mean(target_l[:calib_len]) - np.mean(robot_l[:calib_len]))
                    offset_r = float(np.mean(target_r[:calib_len]) - np.mean(robot_r[:calib_len]))
                    return (offset_l, offset_r)

                return get_or_build_trial_cache_value(trial_cache, "derived", ("robot_offsets", calibrate_robot_thigh), _build_offsets)

            robot_offset_L, robot_offset_R = get_robot_offsets()

            def get_canonical_quat():
                def _build_quat():
                    quat_keys = ['quat_w', 'quat_x', 'quat_y', 'quat_z']
                    quat_cols = [get_trial_signal('robot/back_imu', key) for key in quat_keys]
                    if any(col is None for col in quat_cols):
                        return None
                    quat_stack = np.stack(quat_cols, axis=1)
                    return canonicalize_quaternion_sequence(quat_stack)

                return get_or_build_trial_cache_value(trial_cache, "derived", ("canonical_quat", "robot/back_imu"), _build_quat)

            def get_complementary_euler():
                def _build_euler():
                    accel_keys = ['accel_x', 'accel_y', 'accel_z']
                    gyro_keys = ['gyro_x', 'gyro_y', 'gyro_z']
                    accel_cols = [get_trial_signal('robot/back_imu', key) for key in accel_keys]
                    gyro_cols = [get_trial_signal('robot/back_imu', key) for key in gyro_keys]
                    if any(col is None for col in accel_cols + gyro_cols):
                        return None
                    cf = ComplementaryFilter(fs=fs)
                    return cf.update(np.stack(accel_cols, axis=1), np.stack(gyro_cols, axis=1)).astype(np.float32)

                return get_or_build_trial_cache_value(trial_cache, "derived", ("complementary_euler", fs), _build_euler)

            def get_body_frame_cache():
                nonlocal body_frame_cache
                if body_frame_cache is not None:
                    return body_frame_cache

                def _build_body_frame():
                    accel_keys = ['accel_x', 'accel_y', 'accel_z']
                    gyro_keys = ['gyro_x', 'gyro_y', 'gyro_z']
                    accel_cols = [get_trial_signal('robot/back_imu', key) for key in accel_keys]
                    gyro_cols = [get_trial_signal('robot/back_imu', key) for key in gyro_keys]
                    quat_wxyz = get_canonical_quat()
                    speed_l = get_trial_signal('treadmill/left', 'speed_leftbelt')
                    speed_r = get_trial_signal('treadmill/right', 'speed_rightbelt')
                    if any(col is None for col in accel_cols + gyro_cols) or quat_wxyz is None or speed_l is None or speed_r is None:
                        raise KeyError("Missing IMU or treadmill channels for body-frame features")

                    acc_local = np.stack(accel_cols, axis=1).astype(np.float32)
                    gyro_local = np.stack(gyro_cols, axis=1).astype(np.float32)
                    v_mean = (speed_l + speed_r) / 2.0
                    dt = 1.0 / fs
                    a_tread = np.diff(v_mean) / dt
                    a_tread = np.concatenate([[a_tread[0]], a_tread]).astype(np.float32)

                    return estimate_body_frame_features(
                        acc_local=acc_local,
                        gyro_local=gyro_local,
                        quat_wxyz=quat_wxyz.astype(np.float32),
                        a_tread=a_tread,
                        fs=fs,
                    )

                body_frame_cache = get_or_build_trial_cache_value(trial_cache, "derived", ("body_frame_imu", fs), _build_body_frame)
                return body_frame_cache

            def get_trunk_imu_inputs():
                accel_keys = ['accel_x', 'accel_y', 'accel_z']
                gyro_keys = ['gyro_x', 'gyro_y', 'gyro_z']
                accel_cols = [get_trial_signal('robot/back_imu', key) for key in accel_keys]
                gyro_cols = [get_trial_signal('robot/back_imu', key) for key in gyro_keys]
                quat_wxyz = get_canonical_quat()
                speed_l = get_trial_signal('treadmill/left', 'speed_leftbelt')
                speed_r = get_trial_signal('treadmill/right', 'speed_rightbelt')
                if any(col is None for col in accel_cols + gyro_cols) or quat_wxyz is None or speed_l is None or speed_r is None:
                    raise KeyError("Missing IMU or treadmill channels for derived trunk IMU features")

                acc_local = np.stack(accel_cols, axis=1).astype(np.float32)
                gyro_local = np.stack(gyro_cols, axis=1).astype(np.float32)
                v_mean = (speed_l + speed_r) / 2.0
                dt = 1.0 / fs
                a_tread = np.diff(v_mean) / dt
                a_tread = np.concatenate([[a_tread[0]], a_tread]).astype(np.float32)
                return acc_local, gyro_local, quat_wxyz.astype(np.float32), a_tread

            def get_symmetry_signal():
                def _build_symmetry_signal():
                    thi_l = get_trial_signal('robot/left', 'thigh_angle')
                    thi_r = get_trial_signal('robot/right', 'thigh_angle')
                    hip_l = get_trial_signal('robot/left', 'hip_angle')
                    hip_r = get_trial_signal('robot/right', 'hip_angle')
                    tor_l = get_trial_signal('robot/left', 'torque')
                    tor_r = get_trial_signal('robot/right', 'torque')

                    signal = None
                    for weight, lhs, rhs in (
                        (1.0, thi_l, thi_r),
                        (0.5, hip_l, hip_r),
                        (0.25, tor_l, tor_r),
                    ):
                        if lhs is None or rhs is None:
                            continue
                        diff = (np.asarray(lhs, dtype=np.float32) - np.asarray(rhs, dtype=np.float32)).reshape(-1)
                        diff = diff - np.mean(diff)
                        scale = float(np.std(diff))
                        if scale < 1e-6:
                            continue
                        contrib = weight * (diff / scale)
                        signal = contrib if signal is None else signal + contrib

                    if signal is None:
                        raise KeyError("Missing bilateral robot channels for symmetry heading")
                    if signal.shape[0] >= 5:
                        signal = butter_lowpass_filter(signal, cutoff=6.0, fs=fs, order=2).astype(np.float32)
                    return signal.astype(np.float32)

                return get_or_build_trial_cache_value(trial_cache, "derived", ("symmetry_signal", fs), _build_symmetry_signal)

            def get_gravity_aligned_cache():
                def _build_gravity_aligned():
                    acc_local, gyro_local, quat_wxyz, a_tread = get_trunk_imu_inputs()
                    return estimate_gravity_aligned_features(
                        acc_local=acc_local,
                        gyro_local=gyro_local,
                        quat_wxyz=quat_wxyz,
                        a_tread=a_tread,
                        fs=fs,
                    )

                return get_or_build_trial_cache_value(trial_cache, "derived", ("gravity_aligned_imu", fs), _build_gravity_aligned)

            def get_symmetry_heading_cache():
                def _build_symmetry_heading():
                    acc_local, gyro_local, quat_wxyz, a_tread = get_trunk_imu_inputs()
                    symmetry_signal = get_symmetry_signal()
                    return estimate_symmetry_heading_features(
                        acc_local=acc_local,
                        gyro_local=gyro_local,
                        quat_wxyz=quat_wxyz,
                        a_tread=a_tread,
                        fs=fs,
                        symmetry_signal=symmetry_signal,
                    )

                return get_or_build_trial_cache_value(trial_cache, "derived", ("symmetry_heading_imu", fs), _build_symmetry_heading)

            def get_deflection():
                def _build_deflection():
                    hip_l = get_trial_signal('robot/left', 'hip_angle')
                    mot_l = get_trial_signal('robot/left', 'motor_angle')
                    hip_r = get_trial_signal('robot/right', 'hip_angle')
                    mot_r = get_trial_signal('robot/right', 'motor_angle')
                    if any(sig is None for sig in (hip_l, mot_l, hip_r, mot_r)):
                        raise KeyError("Missing robot hip/motor angle channels for deflection")
                    return {
                        'left': (mot_l - hip_l)[:, None].astype(np.float32),
                        'right': (mot_r - hip_r)[:, None].astype(np.float32),
                    }

                return get_or_build_trial_cache_value(trial_cache, "derived", ("deflection",), _build_deflection)

            def get_asymmetry():
                def _build_asymmetry():
                    hip_l = get_trial_signal('robot/left', 'hip_angle')
                    hip_r = get_trial_signal('robot/right', 'hip_angle')
                    tor_l = get_trial_signal('robot/left', 'torque')
                    tor_r = get_trial_signal('robot/right', 'torque')
                    thi_l = get_trial_signal('robot/left', 'thigh_angle')
                    thi_r = get_trial_signal('robot/right', 'thigh_angle')
                    if any(sig is None for sig in (hip_l, hip_r, tor_l, tor_r)):
                        raise KeyError("Missing robot channels for asymmetry")
                    if thi_l is None or thi_r is None:
                        thi_l = np.zeros_like(hip_l, dtype=np.float32)
                        thi_r = np.zeros_like(hip_r, dtype=np.float32)
                    return {
                        'hip_diff': (hip_l - hip_r)[:, None].astype(np.float32),
                        'torque_diff': (tor_l - tor_r)[:, None].astype(np.float32),
                        'thigh_diff': (thi_l - thi_r)[:, None].astype(np.float32),
                    }

                return get_or_build_trial_cache_value(trial_cache, "derived", ("asymmetry",), _build_asymmetry)

            def get_mech_power():
                def _build_mech_power():
                    tor_l = get_trial_signal('robot/left', 'torque')
                    tor_r = get_trial_signal('robot/right', 'torque')
                    hip_l = get_trial_signal('robot/left', 'hip_angle')
                    hip_r = get_trial_signal('robot/right', 'hip_angle')
                    if any(sig is None for sig in (tor_l, tor_r, hip_l, hip_r)):
                        raise KeyError("Missing robot torque/hip angle channels for mech_power")
                    dt = 1.0 / fs
                    hip_dot_l = np.diff(hip_l) / dt
                    hip_dot_l = np.concatenate([[hip_dot_l[0]], hip_dot_l]).astype(np.float32)
                    hip_dot_r = np.diff(hip_r) / dt
                    hip_dot_r = np.concatenate([[hip_dot_r[0]], hip_dot_r]).astype(np.float32)
                    return {
                        'left': (tor_l * hip_dot_l)[:, None].astype(np.float32),
                        'right': (tor_r * hip_dot_r)[:, None].astype(np.float32),
                    }

                return get_or_build_trial_cache_value(trial_cache, "derived", ("mech_power", fs), _build_mech_power)

            def get_relative_kinematics():
                def _build_relative_kinematics():
                    euler_deg = get_complementary_euler()
                    hip_l = get_trial_signal('robot/left', 'hip_angle')
                    hip_r = get_trial_signal('robot/right', 'hip_angle')
                    thi_l = get_trial_signal('robot/left', 'thigh_angle')
                    thi_r = get_trial_signal('robot/right', 'thigh_angle')
                    if euler_deg is None or any(sig is None for sig in (hip_l, hip_r, thi_l, thi_r)):
                        raise KeyError("Missing euler or robot angle channels for relative_kinematics")

                    pitch = euler_deg[:, 1].astype(np.float32)
                    pitch_dot = np.gradient(pitch) * fs
                    if pitch.shape[0] >= 5:
                        pitch_dot = butter_lowpass_filter(pitch_dot, cutoff=10.0, fs=fs, order=2).astype(np.float32)

                    hip_l_cal = (hip_l + robot_offset_L).astype(np.float32)
                    hip_r_cal = (hip_r + robot_offset_R).astype(np.float32)
                    thi_l = thi_l.astype(np.float32)
                    thi_r = thi_r.astype(np.float32)
                    thi_dot_l = get_derived_signal('robot/left', 'thigh_angle', False)
                    thi_dot_r = get_derived_signal('robot/right', 'thigh_angle', False)
                    if thi_dot_l is None or thi_dot_r is None:
                        raise KeyError("Failed to derive thigh angle velocity for relative_kinematics")

                    return {
                        'pitch_minus_hip_l': (pitch - hip_l_cal)[:, None].astype(np.float32),
                        'pitch_minus_hip_r': (pitch - hip_r_cal)[:, None].astype(np.float32),
                        'pitch_minus_thigh_l': (pitch - thi_l)[:, None].astype(np.float32),
                        'pitch_minus_thigh_r': (pitch - thi_r)[:, None].astype(np.float32),
                        'pitchrate_minus_thighdot_l': (pitch_dot - thi_dot_l.reshape(-1))[:, None].astype(np.float32),
                        'pitchrate_minus_thighdot_r': (pitch_dot - thi_dot_r.reshape(-1))[:, None].astype(np.float32),
                        'hip_minus_thigh_l': (hip_l_cal - thi_l)[:, None].astype(np.float32),
                        'hip_minus_thigh_r': (hip_r_cal - thi_r)[:, None].astype(np.float32),
                    }

                return get_or_build_trial_cache_value(trial_cache, "derived", ("relative_kinematics", fs), _build_relative_kinematics)

            def get_compliance_proxy():
                def _build_compliance_proxy():
                    tor_l = get_trial_signal('robot/left', 'torque')
                    tor_r = get_trial_signal('robot/right', 'torque')
                    if tor_l is None or tor_r is None:
                        raise KeyError("Missing torque channels for compliance_proxy")

                    defl_cache = get_deflection()
                    thi_dot_l = get_derived_signal('robot/left', 'thigh_angle', False)
                    thi_dot_r = get_derived_signal('robot/right', 'thigh_angle', False)
                    if thi_dot_l is None or thi_dot_r is None:
                        raise KeyError("Failed to derive thigh angle velocity for compliance_proxy")

                    tor_l = tor_l.astype(np.float32).reshape(-1)
                    tor_r = tor_r.astype(np.float32).reshape(-1)
                    defl_l = defl_cache['left'].reshape(-1).astype(np.float32)
                    defl_r = defl_cache['right'].reshape(-1).astype(np.float32)
                    thi_dot_l = thi_dot_l.reshape(-1).astype(np.float32)
                    thi_dot_r = thi_dot_r.reshape(-1).astype(np.float32)
                    rate_eps = 5.0

                    return {
                        'deflection_l': defl_cache['left'].astype(np.float32),
                        'deflection_r': defl_cache['right'].astype(np.float32),
                        'load_align_l': (np.abs(tor_l) * np.abs(defl_l))[:, None].astype(np.float32),
                        'load_align_r': (np.abs(tor_r) * np.abs(defl_r))[:, None].astype(np.float32),
                        'torque_over_thighdot_l': (tor_l / (np.abs(thi_dot_l) + rate_eps))[:, None].astype(np.float32),
                        'torque_over_thighdot_r': (tor_r / (np.abs(thi_dot_r) + rate_eps))[:, None].astype(np.float32),
                        'thigh_power_l': (tor_l * thi_dot_l)[:, None].astype(np.float32),
                        'thigh_power_r': (tor_r * thi_dot_r)[:, None].astype(np.float32),
                    }

                return get_or_build_trial_cache_value(trial_cache, "derived", ("compliance_proxy", fs), _build_compliance_proxy)

            def get_load_coupling():
                def _build_load_coupling():
                    tor_l = get_trial_signal('robot/left', 'torque')
                    tor_r = get_trial_signal('robot/right', 'torque')
                    if tor_l is None or tor_r is None:
                        raise KeyError("Missing torque channels for load_coupling")

                    rel_cache = get_relative_kinematics()
                    tor_l = tor_l.astype(np.float32).reshape(-1)
                    tor_r = tor_r.astype(np.float32).reshape(-1)
                    load_win = max(5, int(round(0.25 * fs)))
                    tor_scale_l = rolling_mean_1d(np.abs(tor_l), load_win) + 1e-3
                    tor_scale_r = rolling_mean_1d(np.abs(tor_r), load_win) + 1e-3
                    pitch_gap_l = rel_cache['pitch_minus_hip_l'].reshape(-1).astype(np.float32)
                    pitch_gap_r = rel_cache['pitch_minus_hip_r'].reshape(-1).astype(np.float32)
                    rate_gap_l = rel_cache['pitchrate_minus_thighdot_l'].reshape(-1).astype(np.float32)
                    rate_gap_r = rel_cache['pitchrate_minus_thighdot_r'].reshape(-1).astype(np.float32)
                    hip_gap_l = rel_cache['hip_minus_thigh_l'].reshape(-1).astype(np.float32)
                    hip_gap_r = rel_cache['hip_minus_thigh_r'].reshape(-1).astype(np.float32)
                    return {
                        'torque_pitch_gap_l': (tor_l * pitch_gap_l)[:, None].astype(np.float32),
                        'torque_pitch_gap_r': (tor_r * pitch_gap_r)[:, None].astype(np.float32),
                        'torque_rate_gap_l': (tor_l * rate_gap_l)[:, None].astype(np.float32),
                        'torque_rate_gap_r': (tor_r * rate_gap_r)[:, None].astype(np.float32),
                        'torque_hip_thigh_gap_l': (tor_l * hip_gap_l)[:, None].astype(np.float32),
                        'torque_hip_thigh_gap_r': (tor_r * hip_gap_r)[:, None].astype(np.float32),
                        'norm_torque_pitch_gap_l': ((tor_l / tor_scale_l) * pitch_gap_l)[:, None].astype(np.float32),
                        'norm_torque_pitch_gap_r': ((tor_r / tor_scale_r) * pitch_gap_r)[:, None].astype(np.float32),
                        'norm_torque_rate_gap_l': ((tor_l / tor_scale_l) * rate_gap_l)[:, None].astype(np.float32),
                        'norm_torque_rate_gap_r': ((tor_r / tor_scale_r) * rate_gap_r)[:, None].astype(np.float32),
                        'norm_torque_hip_thigh_gap_l': ((tor_l / tor_scale_l) * hip_gap_l)[:, None].astype(np.float32),
                        'norm_torque_hip_thigh_gap_r': ((tor_r / tor_scale_r) * hip_gap_r)[:, None].astype(np.float32),
                        'rel_abs_pitch_gap_l': ((np.abs(tor_l) * np.abs(pitch_gap_l)) / tor_scale_l)[:, None].astype(np.float32),
                        'rel_abs_pitch_gap_r': ((np.abs(tor_r) * np.abs(pitch_gap_r)) / tor_scale_r)[:, None].astype(np.float32),
                        'rel_abs_rate_gap_l': ((np.abs(tor_l) * np.abs(rate_gap_l)) / tor_scale_l)[:, None].astype(np.float32),
                        'rel_abs_rate_gap_r': ((np.abs(tor_r) * np.abs(rate_gap_r)) / tor_scale_r)[:, None].astype(np.float32),
                        'rel_abs_hip_thigh_gap_l': ((np.abs(tor_l) * np.abs(hip_gap_l)) / tor_scale_l)[:, None].astype(np.float32),
                        'rel_abs_hip_thigh_gap_r': ((np.abs(tor_r) * np.abs(hip_gap_r)) / tor_scale_r)[:, None].astype(np.float32),
                    }

                return get_or_build_trial_cache_value(trial_cache, "derived", ("load_coupling", fs), _build_load_coupling)

            def rolling_mean_1d(x, window):
                x = np.asarray(x, dtype=np.float32).reshape(-1)
                w = max(int(window), 1)
                csum = np.concatenate([[0.0], np.cumsum(x, dtype=np.float64)])
                idx = np.arange(x.shape[0], dtype=np.int64)
                starts = np.maximum(idx - w + 1, 0)
                sums = csum[idx + 1] - csum[starts]
                denom = np.maximum(idx - starts + 1, 1)
                return (sums / denom).astype(np.float32)

            def lag_array(x, lag):
                x = np.asarray(x, dtype=np.float32).reshape(-1)
                lag = max(int(lag), 0)
                if lag == 0:
                    return x.copy()
                head = np.full((lag,), x[0], dtype=np.float32)
                return np.concatenate([head, x[:-lag]]).astype(np.float32)

            def get_contact_phase(side):
                cache_key = ("gait_phase", side)

                def _build_phase():
                    z_path = f"forceplate/grf/{side}/z"
                    z_data = get_data_from_group(trial_group, z_path)
                    if z_data is None:
                        hip_ref = get_trial_signal('robot/left', 'hip_angle')
                        if hip_ref is None:
                            raise KeyError(f"Missing forceplate and fallback hip angle for phase {side}")
                        return np.zeros((hip_ref.shape[0], 1), dtype=np.float32)

                    z_use = -z_data if sub.startswith("m2_") else z_data
                    contact = get_ground_contact(z_use).reshape(-1)
                    pad = np.pad(contact, (1, 0), constant_values=0)
                    hs = np.where(np.diff(pad) == 1)[0]
                    phase = np.zeros_like(contact, dtype=np.float32)
                    for k in range(len(hs) - 1):
                        s, e = hs[k], hs[k + 1]
                        phase[s:e] = np.linspace(0.0, 1.0, max(e - s, 1), endpoint=False, dtype=np.float32)
                    if len(hs) > 0:
                        phase[hs[-1]:] = 1.0
                    return phase[:, None].astype(np.float32)

                return get_or_build_trial_cache_value(trial_cache, "derived", cache_key, _build_phase)

            def get_interface_workloop():
                def _build_interface_workloop():
                    mech_cache = get_mech_power()
                    power_l = mech_cache['left'].reshape(-1).astype(np.float32)
                    power_r = mech_cache['right'].reshape(-1).astype(np.float32)
                    win = max(5, int(round(0.25 * fs)))
                    short_win = max(3, int(round(0.12 * fs)))
                    work_eps = 1e-3

                    def _per_side(power, curr_win):
                        pos_work = rolling_mean_1d(np.maximum(power, 0.0), curr_win)
                        neg_work = rolling_mean_1d(np.maximum(-power, 0.0), curr_win)
                        net_work = rolling_mean_1d(power, curr_win)
                        abs_work = (pos_work + neg_work).astype(np.float32)
                        work_balance = ((pos_work - neg_work) / (abs_work + work_eps)).astype(np.float32)
                        net_ratio = (net_work / (abs_work + work_eps)).astype(np.float32)
                        hysteresis = (pos_work + neg_work - np.abs(net_work)).astype(np.float32)
                        return pos_work, neg_work, net_work, abs_work, work_balance, net_ratio, hysteresis

                    pos_l, neg_l, net_l, abs_l, bal_l, ratio_l, hyst_l = _per_side(power_l, win)
                    pos_r, neg_r, net_r, abs_r, bal_r, ratio_r, hyst_r = _per_side(power_r, win)
                    spos_l, sneg_l, snet_l, sabs_l, sbal_l, sratio_l, _ = _per_side(power_l, short_win)
                    spos_r, sneg_r, snet_r, sabs_r, sbal_r, sratio_r, _ = _per_side(power_r, short_win)
                    return {
                        'left_pos_work': pos_l[:, None].astype(np.float32),
                        'right_pos_work': pos_r[:, None].astype(np.float32),
                        'left_neg_work': neg_l[:, None].astype(np.float32),
                        'right_neg_work': neg_r[:, None].astype(np.float32),
                        'left_net_work': net_l[:, None].astype(np.float32),
                        'right_net_work': net_r[:, None].astype(np.float32),
                        'left_abs_work': abs_l[:, None].astype(np.float32),
                        'right_abs_work': abs_r[:, None].astype(np.float32),
                        'left_work_balance': bal_l[:, None].astype(np.float32),
                        'right_work_balance': bal_r[:, None].astype(np.float32),
                        'left_net_work_ratio': ratio_l[:, None].astype(np.float32),
                        'right_net_work_ratio': ratio_r[:, None].astype(np.float32),
                        'left_hysteresis': hyst_l[:, None].astype(np.float32),
                        'right_hysteresis': hyst_r[:, None].astype(np.float32),
                        'left_pos_work_short': spos_l[:, None].astype(np.float32),
                        'right_pos_work_short': spos_r[:, None].astype(np.float32),
                        'left_neg_work_short': sneg_l[:, None].astype(np.float32),
                        'right_neg_work_short': sneg_r[:, None].astype(np.float32),
                        'left_net_work_short': snet_l[:, None].astype(np.float32),
                        'right_net_work_short': snet_r[:, None].astype(np.float32),
                        'left_abs_work_short': sabs_l[:, None].astype(np.float32),
                        'right_abs_work_short': sabs_r[:, None].astype(np.float32),
                        'left_work_balance_short': sbal_l[:, None].astype(np.float32),
                        'right_work_balance_short': sbal_r[:, None].astype(np.float32),
                        'left_net_work_ratio_short': sratio_l[:, None].astype(np.float32),
                        'right_net_work_ratio_short': sratio_r[:, None].astype(np.float32),
                    }

                return get_or_build_trial_cache_value(trial_cache, "derived", ("interface_workloop", fs), _build_interface_workloop)

            def get_interface_lag():
                def _build_interface_lag():
                    tor_l = get_trial_signal('robot/left', 'torque')
                    tor_r = get_trial_signal('robot/right', 'torque')
                    thi_dot_l = get_derived_signal('robot/left', 'thigh_angle', False)
                    thi_dot_r = get_derived_signal('robot/right', 'thigh_angle', False)
                    if any(sig is None for sig in (tor_l, tor_r, thi_dot_l, thi_dot_r)):
                        raise KeyError("Missing torque/thigh velocity channels for interface_lag")

                    tor_l = tor_l.astype(np.float32).reshape(-1)
                    tor_r = tor_r.astype(np.float32).reshape(-1)
                    thi_dot_l = thi_dot_l.astype(np.float32).reshape(-1)
                    thi_dot_r = thi_dot_r.astype(np.float32).reshape(-1)
                    lag_steps = [0, max(1, int(round(0.05 * fs))), max(2, int(round(0.10 * fs)))]
                    lag_ms = np.asarray([1000.0 * lag / fs for lag in lag_steps], dtype=np.float32)
                    win = max(5, int(round(0.15 * fs)))

                    def _per_side(torque, thigh_dot):
                        corr_feats = []
                        for lag in lag_steps:
                            corr_feats.append(rolling_mean_1d(torque * lag_array(thigh_dot, lag), win))
                        corr_stack = np.stack(corr_feats, axis=0).astype(np.float32)
                        best_idx = np.argmax(np.abs(corr_stack), axis=0)
                        best_lag_ms = lag_ms[best_idx]
                        lag_spread = (np.max(np.abs(corr_stack), axis=0) - np.min(np.abs(corr_stack), axis=0)).astype(np.float32)
                        return corr_stack, best_lag_ms.astype(np.float32), lag_spread

                    corr_l, best_lag_l, spread_l = _per_side(tor_l, thi_dot_l)
                    corr_r, best_lag_r, spread_r = _per_side(tor_r, thi_dot_r)
                    return {
                        'corr0_l': corr_l[0][:, None].astype(np.float32),
                        'corr50_l': corr_l[1][:, None].astype(np.float32),
                        'corr100_l': corr_l[2][:, None].astype(np.float32),
                        'best_lag_ms_l': best_lag_l[:, None].astype(np.float32),
                        'lag_spread_l': spread_l[:, None].astype(np.float32),
                        'corr0_r': corr_r[0][:, None].astype(np.float32),
                        'corr50_r': corr_r[1][:, None].astype(np.float32),
                        'corr100_r': corr_r[2][:, None].astype(np.float32),
                        'best_lag_ms_r': best_lag_r[:, None].astype(np.float32),
                        'lag_spread_r': spread_r[:, None].astype(np.float32),
                    }

                return get_or_build_trial_cache_value(trial_cache, "derived", ("interface_lag", fs), _build_interface_lag)

            def get_effective_impedance():
                def _build_effective_impedance():
                    tor_l = get_trial_signal('robot/left', 'torque')
                    tor_r = get_trial_signal('robot/right', 'torque')
                    thi_dot_l = get_derived_signal('robot/left', 'thigh_angle', False)
                    thi_dot_r = get_derived_signal('robot/right', 'thigh_angle', False)
                    defl_cache = get_deflection()
                    if any(sig is None for sig in (tor_l, tor_r, thi_dot_l, thi_dot_r)):
                        raise KeyError("Missing channels for effective_impedance")

                    def _run_rls(y, x1, x2, lam=0.985, delta=10.0):
                        y = y.astype(np.float64).reshape(-1)
                        x1 = x1.astype(np.float64).reshape(-1)
                        x2 = x2.astype(np.float64).reshape(-1)
                        theta = np.zeros(3, dtype=np.float64)
                        P = np.eye(3, dtype=np.float64) * float(delta)
                        out = np.zeros((y.shape[0], 4), dtype=np.float32)
                        for i in range(y.shape[0]):
                            phi = np.array([x1[i], x2[i], 1.0], dtype=np.float64)
                            pred = float(phi @ theta)
                            err = float(y[i] - pred)
                            denom = lam + float(phi @ P @ phi)
                            if denom < 1e-8:
                                denom = 1e-8
                            K = (P @ phi) / denom
                            theta = theta + K * err
                            P = (P - np.outer(K, phi) @ P) / lam
                            out[i, 0] = float(theta[0])
                            out[i, 1] = float(theta[1])
                            out[i, 2] = float(theta[2])
                            out[i, 3] = float(err)
                        return out

                    imp_l = _run_rls(
                        tor_l.astype(np.float32).reshape(-1),
                        defl_cache['left'].astype(np.float32).reshape(-1),
                        thi_dot_l.astype(np.float32).reshape(-1),
                    )
                    imp_r = _run_rls(
                        tor_r.astype(np.float32).reshape(-1),
                        defl_cache['right'].astype(np.float32).reshape(-1),
                        thi_dot_r.astype(np.float32).reshape(-1),
                    )
                    return {
                        'k_eff_l': imp_l[:, 0:1].astype(np.float32),
                        'c_eff_l': imp_l[:, 1:2].astype(np.float32),
                        'b_eff_l': imp_l[:, 2:3].astype(np.float32),
                        'pred_err_l': imp_l[:, 3:4].astype(np.float32),
                        'k_eff_r': imp_r[:, 0:1].astype(np.float32),
                        'c_eff_r': imp_r[:, 1:2].astype(np.float32),
                        'b_eff_r': imp_r[:, 2:3].astype(np.float32),
                        'pred_err_r': imp_r[:, 3:4].astype(np.float32),
                    }

                return get_or_build_trial_cache_value(trial_cache, "derived", ("effective_impedance", fs), _build_effective_impedance)

            def get_phase_locked():
                def _build_phase_locked():
                    phase_l = get_contact_phase('left').reshape(-1).astype(np.float32)
                    phase_r = get_contact_phase('right').reshape(-1).astype(np.float32)
                    mech_cache = get_mech_power()
                    tor_l = get_trial_signal('robot/left', 'torque')
                    tor_r = get_trial_signal('robot/right', 'torque')
                    if tor_l is None or tor_r is None:
                        raise KeyError("Missing torque channels for phase_locked")

                    theta_l = (2.0 * np.pi * phase_l).astype(np.float32)
                    theta_r = (2.0 * np.pi * phase_r).astype(np.float32)
                    phase_rate_l = (np.gradient(phase_l) * fs).astype(np.float32)
                    phase_rate_r = (np.gradient(phase_r) * fs).astype(np.float32)
                    power_l = mech_cache['left'].reshape(-1).astype(np.float32)
                    power_r = mech_cache['right'].reshape(-1).astype(np.float32)
                    tor_l = tor_l.astype(np.float32).reshape(-1)
                    tor_r = tor_r.astype(np.float32).reshape(-1)
                    return {
                        'sin_phase_l': np.sin(theta_l)[:, None].astype(np.float32),
                        'cos_phase_l': np.cos(theta_l)[:, None].astype(np.float32),
                        'phase_rate_l': phase_rate_l[:, None].astype(np.float32),
                        'power_phase_sin_l': (power_l * np.sin(theta_l))[:, None].astype(np.float32),
                        'torque_phase_cos_l': (tor_l * np.cos(theta_l))[:, None].astype(np.float32),
                        'sin_phase_r': np.sin(theta_r)[:, None].astype(np.float32),
                        'cos_phase_r': np.cos(theta_r)[:, None].astype(np.float32),
                        'phase_rate_r': phase_rate_r[:, None].astype(np.float32),
                        'power_phase_sin_r': (power_r * np.sin(theta_r))[:, None].astype(np.float32),
                        'torque_phase_cos_r': (tor_r * np.cos(theta_r))[:, None].astype(np.float32),
                    }

                return get_or_build_trial_cache_value(trial_cache, "derived", ("phase_locked", fs), _build_phase_locked)

            def get_trunk_consistency():
                def _build_trunk_consistency():
                    gravity_cache = get_gravity_aligned_cache()
                    euler_deg = get_complementary_euler()
                    thi_dot_l = get_derived_signal('robot/left', 'thigh_angle', False)
                    thi_dot_r = get_derived_signal('robot/right', 'thigh_angle', False)
                    if euler_deg is None or thi_dot_l is None or thi_dot_r is None:
                        raise KeyError("Missing signals for trunk_consistency")

                    gyro_body = gravity_cache['gyro_body'].astype(np.float32)
                    acc_body = gravity_cache['acc_body'].astype(np.float32)
                    pitch = euler_deg[:, 1].astype(np.float32)
                    pitch_dot = (np.gradient(pitch) * fs).astype(np.float32)
                    if pitch.shape[0] >= 5:
                        pitch_dot = butter_lowpass_filter(pitch_dot, cutoff=10.0, fs=fs, order=2).astype(np.float32)

                    gyro_lat = gyro_body[:, 0].reshape(-1)
                    gyro_fwd = gyro_body[:, 1].reshape(-1)
                    acc_lat = acc_body[:, 0].reshape(-1)
                    acc_fwd = acc_body[:, 1].reshape(-1)
                    thi_dot_l = thi_dot_l.reshape(-1).astype(np.float32)
                    thi_dot_r = thi_dot_r.reshape(-1).astype(np.float32)
                    return {
                        'gyro_forward_minus_thighdot_l': (gyro_fwd - thi_dot_l)[:, None].astype(np.float32),
                        'gyro_forward_minus_thighdot_r': (gyro_fwd - thi_dot_r)[:, None].astype(np.float32),
                        'gyro_forward_minus_pitchdot': (gyro_fwd - pitch_dot)[:, None].astype(np.float32),
                        'gyro_leak_ratio': (np.abs(gyro_lat) / (np.abs(gyro_fwd) + 0.1))[:, None].astype(np.float32),
                        'accel_leak_ratio': (np.abs(acc_lat) / (np.abs(acc_fwd) + 0.5))[:, None].astype(np.float32),
                    }

                return get_or_build_trial_cache_value(trial_cache, "derived", ("trunk_consistency", fs), _build_trunk_consistency)

            def get_derived_signal(gpath, base_name, is_accel):
                cache_key = ("derivative", gpath, base_name, 2 if is_accel else 1, fs)

                def _build_derivative():
                    base_data = get_trial_signal(gpath, base_name)
                    if base_data is None:
                        return None
                    d1 = np.gradient(base_data, axis=0) * fs
                    target_data = np.gradient(d1, axis=0) * fs if is_accel else d1
                    return butter_lowpass_filter(target_data, cutoff=30.0, fs=fs, order=4).astype(np.float32)

                return get_or_build_trial_cache_value(trial_cache, "derived", cache_key, _build_derivative)

            def get_filtered_signal(gpath, v_name):
                if input_lpf_cutoff is None:
                    return get_trial_signal(gpath, v_name)

                cache_key = ("input_lpf", gpath, v_name, input_lpf_cutoff, input_lpf_order)

                def _build_filtered():
                    base_data = get_trial_signal(gpath, v_name)
                    if base_data is None:
                        return None
                    return butter_lowpass_filter(base_data, input_lpf_cutoff, fs, input_lpf_order).astype(np.float32)

                return get_or_build_trial_cache_value(trial_cache, "derived", cache_key, _build_filtered)

            for gpath, vars in input_vars:
                # [NEW] Complementary Filter Interception
                # If this group is 'derived/euler', we generate it from 'robot/back_imu' or similar.
                # BUT the user requested to Replace inputs. 
                # The config `exp_euler_angles.yaml` will likely specify `input_vars` involving `derived/euler`.
                # So we catch that here.
                
                if use_complementary_filter_euler and "derived/euler" in gpath:
                    # We need Accel and Gyro from this trial.
                    # Assume path is 'robot/back_imu' for source.
                    # Or try to find it.
                    
                    # 1. Load Source IMU Data
                    # Helper navigation
                    imu_path = "robot/back_imu"
                    grp = trial_group
                    parts = imu_path.split('/')
                    valid_imu = True
                    for p in parts:
                        if p in grp: grp = grp[p]
                        elif p in f[sub][cond][lv][trial_name]: # Try absolute look up if relative fails? no
                             # Fallback check
                             pass 
                        else: valid_imu=False; break
                    
                    if not valid_imu:
                        # Try finding it in 'back_imu' directly?
                        if 'back_imu' in trial_group:
                            grp = trial_group['back_imu']
                            valid_imu = True
                    
                    if not valid_imu:
                        print(f"[WARN] IMU data not found for Euler Filter in {sub}/{cond}/{lv}/{trial_name}")
                        valid_trial = False
                        break
                        
                    try:
                        euler_deg = get_complementary_euler()
                        if euler_deg is None:
                            raise KeyError("Euler cache returned None")
                    except KeyError as e:
                        print(f"[WARN] Incomplete IMU channels: {e}")
                        valid_trial = False
                        break
                    
                    # Columns requested: vars (e.g. ['roll', 'pitch', 'yaw'])
                    cols = []
                    for v in vars:
                        if v == 'roll': cols.append(euler_deg[:, 0:1])
                        elif v == 'pitch': cols.append(euler_deg[:, 1:2])
                        elif v == 'yaw': cols.append(euler_deg[:, 2:3])
                    
                    if cols:
                        arr = np.concatenate(cols, axis=1).astype(np.float32)
                        kin_q_arrays.append(arr)
                        curr_trial_in.append(arr)
                    continue # Skip normal loading for this group

                # [NEW] Derived Explicit Features
                if "derived/deflection" in gpath:
                    try:
                        deflection_cache = get_deflection()
                        cols = []
                        for v in vars:
                            if v in deflection_cache:
                                cols.append(deflection_cache[v])
                        
                        if cols:
                            arr = np.concatenate(cols, axis=1).astype(np.float32)
                            kin_q_arrays.append(arr)
                            curr_trial_in.append(arr)
                        continue
                    except Exception as e:
                        print(f"[WARN] Failed to compute deflection in {sub}/{cond}: {e}")
                        valid_trial = False; break

                if "derived/asymmetry" in gpath:
                    try:
                        asymmetry_cache = get_asymmetry()
                        cols = []
                        for v in vars:
                            if v in asymmetry_cache:
                                cols.append(asymmetry_cache[v])
                        
                        if cols:
                            arr = np.concatenate(cols, axis=1).astype(np.float32)
                            kin_q_arrays.append(arr)
                            curr_trial_in.append(arr)
                        continue
                    except Exception as e:
                        print(f"[WARN] Failed to compute asymmetry in {sub}/{cond}: {e}")
                        valid_trial = False; break

                if "derived/mech_power" in gpath:
                    try:
                        mech_power_cache = get_mech_power()
                        cols = []
                        for v in vars:
                            if v in mech_power_cache:
                                cols.append(mech_power_cache[v])
                            
                        if cols:
                            arr = np.concatenate(cols, axis=1).astype(np.float32)
                            kin_q_arrays.append(arr)
                            curr_trial_in.append(arr)
                        continue
                    except Exception as e:
                        print(f"[WARN] Failed to compute mech_power in {sub}/{cond}: {e}")
                        valid_trial = False; break

                if "derived/relative_kinematics" in gpath:
                    try:
                        relkin_cache = get_relative_kinematics()
                        cols = []
                        for v in vars:
                            if v in relkin_cache:
                                cols.append(relkin_cache[v])

                        if cols:
                            arr = np.concatenate(cols, axis=1).astype(np.float32)
                            kin_q_arrays.append(arr)
                            curr_trial_in.append(arr)
                        continue
                    except Exception as e:
                        print(f"[WARN] Failed to compute relative_kinematics in {sub}/{cond}: {e}")
                        valid_trial = False; break

                if "derived/compliance_proxy" in gpath:
                    try:
                        compliance_cache = get_compliance_proxy()
                        cols = []
                        for v in vars:
                            if v in compliance_cache:
                                cols.append(compliance_cache[v])

                        if cols:
                            arr = np.concatenate(cols, axis=1).astype(np.float32)
                            kin_q_arrays.append(arr)
                            curr_trial_in.append(arr)
                        continue
                    except Exception as e:
                        print(f"[WARN] Failed to compute compliance_proxy in {sub}/{cond}: {e}")
                        valid_trial = False; break

                if "derived/load_coupling" in gpath:
                    try:
                        coupling_cache = get_load_coupling()
                        cols = []
                        for v in vars:
                            if v in coupling_cache:
                                cols.append(coupling_cache[v])

                        if cols:
                            arr = np.concatenate(cols, axis=1).astype(np.float32)
                            kin_q_arrays.append(arr)
                            curr_trial_in.append(arr)
                        continue
                    except Exception as e:
                        print(f"[WARN] Failed to compute load_coupling in {sub}/{cond}: {e}")
                        valid_trial = False; break

                if "derived/interface_workloop" in gpath:
                    try:
                        workloop_cache = get_interface_workloop()
                        cols = []
                        for v in vars:
                            if v in workloop_cache:
                                cols.append(workloop_cache[v])

                        if cols:
                            arr = np.concatenate(cols, axis=1).astype(np.float32)
                            kin_q_arrays.append(arr)
                            curr_trial_in.append(arr)
                        continue
                    except Exception as e:
                        print(f"[WARN] Failed to compute interface_workloop in {sub}/{cond}: {e}")
                        valid_trial = False; break

                if "derived/interface_lag" in gpath:
                    try:
                        lag_cache = get_interface_lag()
                        cols = []
                        for v in vars:
                            if v in lag_cache:
                                cols.append(lag_cache[v])

                        if cols:
                            arr = np.concatenate(cols, axis=1).astype(np.float32)
                            kin_q_arrays.append(arr)
                            curr_trial_in.append(arr)
                        continue
                    except Exception as e:
                        print(f"[WARN] Failed to compute interface_lag in {sub}/{cond}: {e}")
                        valid_trial = False; break

                if "derived/effective_impedance" in gpath:
                    try:
                        imp_cache = get_effective_impedance()
                        cols = []
                        for v in vars:
                            if v in imp_cache:
                                cols.append(imp_cache[v])

                        if cols:
                            arr = np.concatenate(cols, axis=1).astype(np.float32)
                            kin_q_arrays.append(arr)
                            curr_trial_in.append(arr)
                        continue
                    except Exception as e:
                        print(f"[WARN] Failed to compute effective_impedance in {sub}/{cond}: {e}")
                        valid_trial = False; break

                if "derived/phase_locked" in gpath:
                    try:
                        phase_cache = get_phase_locked()
                        cols = []
                        for v in vars:
                            if v in phase_cache:
                                cols.append(phase_cache[v])

                        if cols:
                            arr = np.concatenate(cols, axis=1).astype(np.float32)
                            kin_q_arrays.append(arr)
                            curr_trial_in.append(arr)
                        continue
                    except Exception as e:
                        print(f"[WARN] Failed to compute phase_locked in {sub}/{cond}: {e}")
                        valid_trial = False; break

                if "derived/trunk_consistency" in gpath:
                    try:
                        trunk_cache = get_trunk_consistency()
                        cols = []
                        for v in vars:
                            if v in trunk_cache:
                                cols.append(trunk_cache[v])

                        if cols:
                            arr = np.concatenate(cols, axis=1).astype(np.float32)
                            kin_q_arrays.append(arr)
                            curr_trial_in.append(arr)
                        continue
                    except Exception as e:
                        print(f"[WARN] Failed to compute trunk_consistency in {sub}/{cond}: {e}")
                        valid_trial = False; break

                if "derived/gravity_aligned_imu" in gpath:
                    try:
                        gravity_cache = get_gravity_aligned_cache()
                        cols = []
                        for v in vars:
                            if v == 'accel_right': cols.append(gravity_cache['acc_body'][:, 0:1])
                            elif v == 'accel_forward': cols.append(gravity_cache['acc_body'][:, 1:2])
                            elif v == 'accel_up': cols.append(gravity_cache['acc_body'][:, 2:3])
                            elif v == 'gyro_right': cols.append(gravity_cache['gyro_body'][:, 0:1])
                            elif v == 'gyro_forward': cols.append(gravity_cache['gyro_body'][:, 1:2])
                            elif v == 'gyro_up': cols.append(gravity_cache['gyro_body'][:, 2:3])
                            elif v == 'forward_accel_overground': cols.append(gravity_cache['forward_accel_overground'])

                        if cols:
                            arr = np.concatenate(cols, axis=1).astype(np.float32)
                            kin_q_arrays.append(arr)
                            curr_trial_in.append(arr)
                        continue
                    except Exception as e:
                        print(f"[WARN] Failed to compute gravity_aligned_imu in {sub}/{cond}: {e}")
                        valid_trial = False; break

                if "derived/symmetry_heading_imu" in gpath:
                    try:
                        sym_cache = get_symmetry_heading_cache()
                        cols = []
                        for v in vars:
                            if v == 'accel_right': cols.append(sym_cache['acc_body'][:, 0:1])
                            elif v == 'accel_forward': cols.append(sym_cache['acc_body'][:, 1:2])
                            elif v == 'accel_up': cols.append(sym_cache['acc_body'][:, 2:3])
                            elif v == 'gyro_right': cols.append(sym_cache['gyro_body'][:, 0:1])
                            elif v == 'gyro_forward': cols.append(sym_cache['gyro_body'][:, 1:2])
                            elif v == 'gyro_up': cols.append(sym_cache['gyro_body'][:, 2:3])
                            elif v == 'forward_accel_overground': cols.append(sym_cache['forward_accel_overground'])
                            elif v == 'heading_yaw_offset_rad': cols.append(sym_cache['heading_yaw_offset_rad'])

                        if cols:
                            arr = np.concatenate(cols, axis=1).astype(np.float32)
                            kin_q_arrays.append(arr)
                            curr_trial_in.append(arr)
                        continue
                    except Exception as e:
                        print(f"[WARN] Failed to compute symmetry_heading_imu in {sub}/{cond}: {e}")
                        valid_trial = False; break

                if "derived/body_frame_imu" in gpath:
                    try:
                        body_cache = get_body_frame_cache()
                        cols = []
                        for v in vars:
                            if v == 'accel_right': cols.append(body_cache['acc_body'][:, 0:1])
                            elif v == 'accel_forward': cols.append(body_cache['acc_body'][:, 1:2])
                            elif v == 'accel_up': cols.append(body_cache['acc_body'][:, 2:3])
                            elif v == 'gyro_right': cols.append(body_cache['gyro_body'][:, 0:1])
                            elif v == 'gyro_forward': cols.append(body_cache['gyro_body'][:, 1:2])
                            elif v == 'gyro_up': cols.append(body_cache['gyro_body'][:, 2:3])
                            elif v == 'forward_accel_overground': cols.append(body_cache['forward_accel_overground'])

                        if cols:
                            arr = np.concatenate(cols, axis=1).astype(np.float32)
                            kin_q_arrays.append(arr)
                            curr_trial_in.append(arr)
                        continue
                    except Exception as e:
                        print(f"[WARN] Failed to compute body_frame_imu in {sub}/{cond}: {e}")
                        valid_trial = False; break

                # [NEW] Global IMU + Treadmill Acceleration Interception
                if "derived/global_accel" in gpath:
                    try:
                        body_cache = get_body_frame_cache()
                        cols = []
                        for v in vars:
                            if v == 'accel_x': cols.append(body_cache['acc_global'][:, 0:1])
                            elif v == 'accel_y': cols.append(body_cache['acc_global'][:, 1:2])
                            elif v == 'accel_z': cols.append(body_cache['acc_global'][:, 2:3])
                            elif v == 'accel_x_overground': cols.append(body_cache['acc_body'][:, 0:1])
                            elif v == 'accel_y_overground': cols.append(body_cache['forward_accel_overground'])
                            elif v == 'a_tread': cols.append((body_cache['forward_accel_overground'] - body_cache['acc_body'][:, 1:2]))
                            
                        if cols:
                            arr = np.concatenate(cols, axis=1).astype(np.float32)
                            kin_q_arrays.append(arr)
                            curr_trial_in.append(arr)
                        continue # Skip normal loading
                        
                    except Exception as e:
                        print(f"[WARN] Failed to compute global_accel in {sub}/{cond}: {e}")
                        valid_trial = False
                        break

                # Normal Loading Logic
                # gpath is e.g. 'robot/back_imu' or 'mocap/kin_q'
                
                # Navigate to group
                grp = trial_group
                parts = gpath.split('/')
                missing_grp = False
                for p in parts:
                    if p in grp: grp = grp[p]
                    else: missing_grp=True; break
                
                if missing_grp and gpath != "derived":
                    print(f"[DEBUG] {sub}/{cond}/{lv}/{trial_name}: Missing group {gpath}")
                    valid_trial = False
                    break

                quat_cache = None
                if gpath == "robot/back_imu" and any(vn in {'quat_w', 'quat_x', 'quat_y', 'quat_z'} for vn in vars):
                    quat_cache = get_canonical_quat()
                
                # Load Data Columns
                block_cols = []
                for v_name in vars:
                    col_data = None
                    base_name = None
                    is_accel = False
                    
                    # 1. Direct Load
                    if v_name in grp:
                        if quat_cache is not None and v_name in {'quat_w', 'quat_x', 'quat_y', 'quat_z'}:
                            quat_idx = {'quat_w': 0, 'quat_x': 1, 'quat_y': 2, 'quat_z': 3}[v_name]
                            col_data = quat_cache[:, quat_idx]
                        else:
                            col_data = get_filtered_signal(gpath, v_name)
                            
                        # [NEW] Apply calibration offset for Robot Thigh Angle
                        if 'robot' in gpath and 'hip_angle' in v_name:
                            if 'left' in gpath:
                                col_data = col_data + robot_offset_L
                            elif 'right' in gpath:
                                col_data = col_data + robot_offset_R
                    
                    # 2. Derived Logic (Velocity/Acceleration/Contact)
                    elif v_name.endswith('_dot') or v_name.endswith('_ddot'):
                        if v_name.endswith('_ddot'):
                            base_name = v_name[:-5]
                            is_accel = True
                        else:
                            base_name = v_name[:-4]
                            is_accel = False
                        
                        if base_name in grp:
                            base_data = get_trial_signal(gpath, base_name)
                            target_data = get_derived_signal(gpath, base_name, is_accel)
                            col_data = target_data
                            
                            # [NEW] Physical Velocity Model (Integrated)
                            if use_physical_velocity_model and not is_accel and 'hip' in v_name and 'flexion' in v_name:
                                # V = L * theta_dot * cos(theta_rad)
                                # theta = base_data
                                # theta_dot = target_data (d1)
                                
                                # Load Leg Length
                                L = 0.9 # Default
                                if sub in f and "leg_length" in f[sub].attrs:
                                    L = f[sub].attrs["leg_length"]
                                elif sub in f and "sub_info" in f[sub] and "leg_length" in f[sub]["sub_info"].attrs:
                                    L = f[sub]["sub_info"].attrs["leg_length"]
                                
                                theta_rad = base_data
                                theta_dot = target_data
                                v_phys = L * theta_dot * np.cos(theta_rad)
                                col_data = v_phys
                                # print(f"[DEBUG] Applied Physical Model (L={L:.2f}) for {v_name}")
                        else:
                             print(f"[WARN] Base data {base_name} not found for {v_name}")
                             valid_trial = False
                             break

                    # [NEW] Fallback for Milestone 1: hip_angle -> motor_angle
                    elif 'hip_angle' in v_name:
                        # Check for motor_angle if hip_angle is missing
                        alt_name = v_name.replace('hip_angle', 'motor_angle')
                        if alt_name in grp:
                            col_data = get_filtered_signal(gpath, alt_name)
                            print(f"[INFO] Loaded {alt_name} as fallback for {v_name}")
                        else:
                             # Debug why it wasn't found
                            print(f"[DEBUG-FALLBACK] {alt_name} NOT found in grp. Keys: {list(grp.keys())}")

                    # 3. Derive Contact from GRF Z
                    elif v_name == 'contact':
                         # Logic: If 'z' exists in this group, use threshold
                         if 'z' in grp:
                             fz = grp['z'][:]
                             col_data = get_ground_contact(fz, threshold=20.0).reshape(-1, 1)
                         else:
                             print(f"[DEBUG] {sub}/{cond}/{lv}/{trial_name}: GRF Z not found for contact derivation")
                             valid_trial = False
                             break
                             
                    # 4. Gait Phase (Derived)
                    elif gpath == "derived" and "gait_phase" in v_name:
                         # Load contact relation
                         side = 'left' if '_L' in v_name else 'right'
                         z_path = f"forceplate/grf/{side}/z"
                         z_data = get_data_from_group(trial_group, z_path)
                         if sub.startswith("m2_"):
                             z_data = -z_data
                         if z_data is not None:
                             cont = get_ground_contact(z_data)
                             # Calculate Phase
                             # Simple 1-period ramp
                             pad = np.pad(cont.flatten(), (1,0), constant_values=0)
                             diff = np.diff(pad)
                             hs = np.where(diff == 1)[0]
                             ph = np.zeros_like(cont)
                             for k in range(len(hs)-1):
                                 s, e = hs[k], hs[k+1]
                                 ph[s:e] = np.linspace(0, 1, e-s)
                             if len(hs)>0: ph[hs[-1]:] = 1.0 # Tail
                             col_data = ph[:, None]
                         else:
                             # Fallback 0
                             print(f"[WARN] No Z force for Gait Phase {v_name}")
                             col_data = np.zeros((get_data_from_group(trial_group, "robot/left/hip_angle").shape[0], 1))
                    
                    else:
                        print(f"[DEBUG] {sub}/{cond}/{lv}/{trial_name}: Dataset {v_name} not found in {gpath}")
                        valid_trial = False
                        break

                    # -------------------------------------------------------------------------
                    # [NEW] Data Correction: Hardcoded Sign Flipping based on User Request
                    # -------------------------------------------------------------------------
                    if col_data is not None:
                         # 1. Milestone 1 Corrections (prefix "m1_")
                        if sub.startswith("m1_"):
                            # GRF Left X
                            if "grf" in gpath and "left" in gpath and v_name == "x":
                                col_data = -col_data
                            # GRF Right X
                            elif "grf" in gpath and "right" in gpath and v_name == "x":
                                col_data = -col_data
                            # Knee Angle L & L_dot
                            elif "knee_angle_l" in v_name:
                                col_data = -col_data
                            # Knee Angle R & R_dot
                            elif "knee_angle_r" in v_name:
                                col_data = -col_data

                        # 2. Milestone 2 Corrections (prefix "m2_")
                        elif sub.startswith("m2_"):
                            # GRF Left Z
                            if "grf" in gpath and "left" in gpath and v_name == "z":
                                col_data = -col_data
                            # GRF Right Z
                            elif "grf" in gpath and "right" in gpath and v_name == "z":
                                col_data = -col_data

                    # Append to block columns
                    if col_data is not None:
                        if col_data.ndim == 1: col_data = col_data[:, None]
                        block_cols.append(col_data)
                    else:
                        valid_trial = False
                        break
                
                if not valid_trial: break
                arr = np.concatenate(block_cols, axis=1).astype(np.float32)
                    
                # [FIX] GRF Normalization (Requested by User)
                # "forceplate" AND "grf" in path -> divide by body weight
                # Need mass.
                if "forceplate" in gpath.lower() and "grf" in gpath.lower():
                     # Get Mass
                     mass = 70.0 # Default
                     # Try to read mass from subject level attributes
                     if sub in f and "mass" in f[sub].attrs:
                         mass = f[sub].attrs["mass"]
                     bw = mass * 9.81
                     arr = arr / bw
                     # print(f"[DEBUG] Applied GRF Norm (mass={mass}) to {gpath}")

                kin_q_arrays.append(arr)
                curr_trial_in.append(arr)
                # Loop (524-589) Removed: Redundant data loading.
                # 'arr' already contains all variables for this group.

            if not valid_trial: continue

            # (B) Augment: Gait Phase
            if use_gait_phase:
                 # Logic: Find contact in curr_trial_in? 
                 # curr_trial_in is list of arrays corresponding to input_vars.
                 # We need to find which one is contact.
                 # But input_vars might not include contact if we are adding Gait Phase.
                 # We need to load contact explicitly.
                 
                 # Load Left Contact
                 contact_L = None
                 contact_R = None
                 
                 # Try to find GRF groups
                 # Using helper get_data_from_group
                 g_L = get_data_from_group(trial_group, "forceplate/grf/left/z")
                 g_R = get_data_from_group(trial_group, "forceplate/grf/right/z")
                 
                 if g_L is not None: contact_L = get_ground_contact(g_L)
                 if g_R is not None: contact_R = get_ground_contact(g_R)
                 
                 if contact_L is not None and contact_R is not None:
                     # Calculate Phase
                     def calc_phase(contact):
                         # Contact 0->1 transition is HS.
                         # Reset to 0 at HS, then ramp to 1 until next HS.
                         # Simple ramp: (t - t_hs) / (t_next_hs - t_hs)
                         # This requires future info (offline). We are offline here.
                         
                         phase = np.zeros(len(contact))  # 1D array
                         # Find HS indices
                         pad = np.pad(contact.flatten(), (1,0), constant_values=0)
                         diff = np.diff(pad)
                         hs_indices = np.where(diff == 1)[0]
                         
                         # Fill phase
                         for i in range(len(hs_indices)-1):
                             start = hs_indices[i]
                             end = hs_indices[i+1]
                             dur = end - start
                             ramp = np.linspace(0, 1, dur, endpoint=False)
                             phase[start:end] = ramp
                             
                         # Tail
                         if len(hs_indices) > 0:
                             last = hs_indices[-1]
                             # Just continue linear trend or hold? 
                             phase[last:] = 1.0 
                             
                         return phase[:, None]  # Return as 2D column
                         
                     ph_L = calc_phase(contact_L)
                     ph_R = calc_phase(contact_R)
                     
                     # Append to inputs ?
                     # If the USER requested 'derived/gait_phase_L' in input_vars, 
                     # we should have handled it in the loop.
                     # But 'derived' logic was not in the loop.
                     # We append it here as "Extra Features".
                     # However, build_nn_dataset expects columns to match input_vars count.
                     # If input_vars has 'derived', we handled it? No.
                     # We need to handle 'derived' in the main loop OR
                     # Assume input_vars INCLUDES 'gait_phase' logic.
                     pass 

            # (C) Physical Velocity Model Processing
            if use_physical_velocity_model:
                # Iterate columns found in this trial
                # We need column indices matching 'hip_flexion' and 'hip_flexion_dot'.
                # This is tricky because we flattened everything.
                # Better: Check 'input_vars' loop again.
                pass
                
            # [FIX] Physical Velocity Model should be applied DURING loading (Line 600ish)
            # Retrying the logic in the main loop is hard.
            # We will iterate the loaded buffer if we can map usage.
            # But the buffer is just values.
            # We implemented specific handling below.
            pass

            if not curr_trial_in:
                 continue

            # --- Synchronization (Handle slight length mismatches between sensor groups) ---
            # 1. Collect all potential arrays (inputs and outputs) to find global min length
            all_objs = curr_trial_in.copy()
            
            # Identify output arrays first
            extracted_outs = []
            valid_out = True
            for gpath, vars in output_vars:
                if gpath != "derived/human_thigh":
                    grp = trial_group
                    parts = gpath.split('/')
                    found_grp = True
                    for p in parts:
                        if p in grp: grp = grp[p]
                        else: found_grp = False; break
                    if not found_grp:
                        valid_out = False
                        break
                for v in vars:
                    output_key = (gpath, v, residual_target, calibrate_robot_thigh)

                    def _build_output():
                        if gpath == "derived/human_thigh":
                            pelvis_tilt = get_trial_signal('mocap/kin_q', 'pelvis_tilt')
                            if pelvis_tilt is None:
                                return None
                            if v in ['left', 'thigh_l', 'thigh_angle_l']:
                                hip_flex = get_trial_signal('mocap/kin_q', 'hip_flexion_l')
                                robot_thigh = get_trial_signal('robot/left', 'thigh_angle')
                                robot_offset = robot_offset_L
                            elif v in ['right', 'thigh_r', 'thigh_angle_r']:
                                hip_flex = get_trial_signal('mocap/kin_q', 'hip_flexion_r')
                                robot_thigh = get_trial_signal('robot/right', 'thigh_angle')
                                robot_offset = robot_offset_R
                            else:
                                return None
                            if hip_flex is None:
                                return None
                            d = pelvis_tilt + hip_flex
                            if residual_target and robot_thigh is not None:
                                d = d - (robot_thigh + robot_offset)
                            return np.nan_to_num(d).reshape(-1, 1).astype(np.float32)

                        d = get_trial_signal(gpath, v)
                        if d is None:
                            return None

                        if 'mocap' in gpath and 'kin_q' in gpath and v in ['hip_flexion_l', 'hip_flexion_r']:
                            p_list = get_trial_signal('mocap/kin_q', 'pelvis_list')
                            if p_list is not None:
                                d = d - p_list

                            if residual_target:
                                if 'hip_flexion_l' in v:
                                    robot_hip = get_trial_signal('robot/left', 'hip_angle')
                                    if robot_hip is not None:
                                        d = d - (robot_hip + robot_offset_L)
                                elif 'hip_flexion_r' in v:
                                    robot_hip = get_trial_signal('robot/right', 'hip_angle')
                                    if robot_hip is not None:
                                        d = d - (robot_hip + robot_offset_R)

                        return np.nan_to_num(d).reshape(-1, 1).astype(np.float32)

                    d = get_or_build_trial_cache_value(trial_cache, "outputs", output_key, _build_output)
                    if d is None:
                        valid_out = False
                        break
                    extracted_outs.append(d)
            
            if not valid_out or not extracted_outs:
                continue
                
            # 2. Find common minimum length
            all_objs.extend(extracted_outs)
            min_len_trial = min([a.shape[0] for a in all_objs])
            
            # 3. Trim and Stack
            in_arr_trial = np.hstack([a[:min_len_trial] for a in curr_trial_in])
            out_arr_trial = np.hstack([a[:min_len_trial] for a in extracted_outs])
            
            # Valid trial found
            in_list_all.append(in_arr_trial)
            out_list_all.append(out_arr_trial)

    if not in_list_all:
        return [], []
        
    return in_list_all, out_list_all

def build_nn_dataset(
    data_path,
    sub_names, cond_names,
    input_vars, output_vars,
    time_window_input, time_window_output, stride,
    subject_selection=None,
    condition_selection=None,
    level_selection=None,
    debug_plot=False,
    est_tick_ranges=None,
    use_physical_velocity_model=False,
    use_gait_phase=False,
    input_lpf_cutoff=None,
    input_lpf_order=4,
    use_complementary_filter_euler=False,
    residual_target=False,
    calibrate_robot_thigh=False,
    return_metadata=False
):
    X_list = []
    Y_list = []
    meta_list = []

    # print(f"[DEBUG] build_nn_dataset called with subjects={sub_names} conditions={cond_names}")
    
    if not os.path.exists(data_path):
         # Try global path if relative fails? 
         # Assuming data_path is correct.
         pass
         
    include_levels = None
    if level_selection and isinstance(level_selection, dict):
        include_levels = level_selection.get('include')

    with h5py.File(data_path, 'r') as f:
        # print(f"[DEBUG] H5 file opened. Keys: {list(f.keys())}")
        for sub in sub_names:
            if subject_selection:
                if sub not in subject_selection.get('include', sub_names):
                    continue
                if sub in subject_selection.get('exclude', []):
                    continue
            
            # print(f"[DEBUG] Processing sub {sub}")
            
            if sub not in f:
                continue

            for cond in cond_names:
                if condition_selection:
                    if condition_selection.get('include') and cond not in condition_selection['include']:
                        continue
                    if cond in condition_selection.get('exclude', []):
                        continue
                        
                if cond not in f[sub]:
                    # print(f"[DEBUG] Cond {cond} not in f[{sub}]! Keys: {list(f[sub].keys())}")
                    continue

                # Data load
                X_trials, Y_trials = extract_condition_data_v2(
                    f, sub, cond, input_vars, output_vars,
                    include_levels=include_levels,
                    use_physical_velocity_model=use_physical_velocity_model,
                    use_gait_phase=use_gait_phase,
                    input_lpf_cutoff=input_lpf_cutoff,
                    input_lpf_order=input_lpf_order,
                    use_complementary_filter_euler=use_complementary_filter_euler,
                    residual_target=residual_target,
                    calibrate_robot_thigh=calibrate_robot_thigh
                )
                
                if not X_trials:
                    # print(f"[DEBUG] Extract returned empty for {sub}/{cond}")
                    continue
                
                # Iterate over executed trials
                for X_arr, Y_arr in zip(X_trials, Y_trials):
                    # Check min length
                    if est_tick_ranges:
                        req_out_len = max(est_tick_ranges)
                    else:
                        req_out_len = time_window_output
                        
                    min_len = time_window_input + req_out_len
                    
                    if len(X_arr) < min_len:
                        continue

                    # Store RAW series (Lazy Loading)
                    X_list.append(X_arr)
                    Y_list.append(Y_arr)
                    if return_metadata:
                        meta_list.append({
                            "subject": sub,
                            "condition": cond,
                            "source_path": data_path,
                        })

    if len(X_list) == 0:
        print("[DEBUG] X_list is empty at end of build_nn_dataset")
        if return_metadata:
            return [], [], []
        return [], []
    
    # Return LIST of arrays, not stacked array
    if return_metadata:
        return X_list, Y_list, meta_list
    return X_list, Y_list

def build_nn_dataset_multi(
    config,
    sub_names, cond_names,
    input_vars, output_vars,
    time_window_input, time_window_output, stride,
    subject_selection=None,
    condition_selection=None,
    level_selection=None,
    est_tick_ranges=None,
    use_physical_velocity_model=False,
    use_gait_phase=False,
    input_lpf_cutoff=None,
    input_lpf_order=4,
    use_complementary_filter_euler=False,
    residual_target=False,
    calibrate_robot_thigh=False
):
    # Determine data sources
    data_sources = {}

    if 'shared' in config and 'data_sources' in config['shared']:
        for ds_name, ds_config in config['shared']['data_sources'].items():
            prefix = ds_config.get('prefix', '')
            path = ds_config.get('path', '')
            exclude = ds_config.get('exclude_subjects', [])
            if path:
                 data_sources[prefix] = {'path': path, 'exclude_subjects': exclude}
    
    # Fallback to single path in config
    if not data_sources:
        data_path = config.get('data_path')
        if not data_path:
             # Try nested
             if '01_construction' in config: data_path = config['01_construction'].get('src_h5')
             if not data_path and 'shared' in config: data_path = config['shared'].get('src_h5')
             if not data_path: data_path = './combined_data.h5'
             
        data_sources = {'': {'path': data_path, 'exclude_subjects': []}} # Empty prefix for default
        
    X_all = []
    Y_all = []
    
    print(f"[DATA] Loading Multi-Source: keys={list(data_sources.keys())}")
    
    for prefix, src_cfg in data_sources.items():
        path = src_cfg['path']
        src_exclude = src_cfg.get('exclude_subjects', [])
        
        # 1. Filter & Strip 'sub_names'
        # sub_names are like ['m1_S011', 'm2_S001', ...]
        # We only keep those matching the current prefix.
        current_source_subs = []
        if sub_names:
            for s in sub_names:
                if prefix and s.startswith(prefix):
                    # Match prefix -> Strip and Keep
                    stripped = s[len(prefix):]
                    current_source_subs.append(stripped)
                elif not prefix:
                    # No prefix source (Legacy or Single H5)
                    # We try to keep all, provided they don't look like they belong to another prefix?
                    # Or simpler: Just keep all. If they aren't in H5, build_nn_dataset skips them.
                    current_source_subs.append(s)
        
        if not current_source_subs:
            continue
            
        base_source_subs = [s for s in current_source_subs if s not in src_exclude]
        if not base_source_subs:
            continue

        cache_key = (
            path,
            tuple(sorted(base_source_subs)),
            tuple(cond_names) if cond_names else tuple(),
            freeze_nested(input_vars),
            freeze_nested(output_vars),
            time_window_input,
            time_window_output,
            stride,
            freeze_nested(condition_selection),
            freeze_nested(level_selection),
            freeze_nested(est_tick_ranges),
            use_physical_velocity_model,
            use_gait_phase,
            input_lpf_cutoff,
            input_lpf_order,
            use_complementary_filter_euler,
            residual_target,
            calibrate_robot_thigh,
        )

        cached_dataset = TRIAL_DATASET_CACHE.get(cache_key)
        if cached_dataset is None:
            X_src_full, Y_src_full, meta_src_full = build_nn_dataset(
                path, base_source_subs, cond_names,
                input_vars, output_vars,
                time_window_input, time_window_output, stride,
                subject_selection={'include': base_source_subs, 'exclude': []},
                condition_selection=condition_selection,
                level_selection=level_selection,
                est_tick_ranges=est_tick_ranges,
                use_physical_velocity_model=use_physical_velocity_model,
                use_gait_phase=use_gait_phase,
                input_lpf_cutoff=input_lpf_cutoff,
                input_lpf_order=input_lpf_order,
                use_complementary_filter_euler=use_complementary_filter_euler,
                residual_target=residual_target,
                calibrate_robot_thigh=calibrate_robot_thigh,
                return_metadata=True
            )
            cached_dataset = {
                "X": X_src_full,
                "Y": Y_src_full,
                "meta": meta_src_full,
            }
            TRIAL_DATASET_CACHE[cache_key] = cached_dataset

        # 2. Filter & Strip 'subject_selection'
        # subject_selection has 'include' and 'exclude' lists of full names.
        curr_sub_select = {}
        if subject_selection:
            # Handle Include
            if 'include' in subject_selection:
                inc_list = []
                for s in subject_selection['include']:
                    if prefix and s.startswith(prefix): inc_list.append(s[len(prefix):])
                    elif not prefix: inc_list.append(s)
                curr_sub_select['include'] = inc_list
            
            # Handle Exclude
            # Combine Global Exclude (from subject_selection) AND Source-Specific Exclude
            ex_list = []
            if 'exclude' in subject_selection:
                for s in subject_selection['exclude']:
                    if prefix and s.startswith(prefix): ex_list.append(s[len(prefix):])
                    elif not prefix: ex_list.append(s)
            
            # Add Source Excludes (assuming they match keys in H5 directly? or full names?)
            # Config usually has exclude_subjects: ['S004'] for that source.
            if src_exclude:
                ex_list.extend(src_exclude)
            
            curr_sub_select['exclude'] = ex_list

        include_set = None
        exclude_set = set(src_exclude)
        if curr_sub_select.get('include'):
            include_set = set(curr_sub_select['include'])
        if curr_sub_select.get('exclude'):
            exclude_set.update(curr_sub_select['exclude'])

        selected_count = 0
        for x_arr, y_arr, meta in zip(cached_dataset["X"], cached_dataset["Y"], cached_dataset["meta"]):
            trial_sub = meta["subject"]
            if include_set is not None and trial_sub not in include_set:
                continue
            if trial_sub in exclude_set:
                continue
            X_all.append(x_arr.copy())
            Y_all.append(y_arr.copy())
            selected_count += 1

        if selected_count:
            print(f"     Loaded {selected_count} trials (cached)")

    return X_all, Y_all

def plot_model_summary(results):
    """
    results: list of (exp_name, seed, metrics_data, ckpt, ...)
    metrics_data: either float (old style loss) or dict (new style full metrics)
    """
    import matplotlib.pyplot as plt
    
    # Organize data
    # Structure: names -> list of metrics
    data = {}
    
    for row in results:
        name = row[0]
        # seed = row[1] 
        metrics_val = row[2]
        
        if name not in data:
            data[name] = {'huber': [], 'mae': [], 'rmse': [], 'params': []}
            
        if isinstance(metrics_val, dict):
            data[name]['huber'].append(metrics_val.get('test_huber', 0.0))
            data[name]['mae'].append(metrics_val.get('test_mae', 0.0))
            data[name]['rmse'].append(metrics_val.get('test_rmse', 0.0))
            data[name]['params'].append(metrics_val.get('n_params', 0))
        else:
            # Fallback if only float provided
            data[name]['huber'].append(float(metrics_val))
            
    names = sorted(data.keys())
    
    # Prepare Stats
    means = {k: [] for k in ['huber', 'mae', 'rmse', 'params']}
    stds  = {k: [] for k in ['huber', 'mae', 'rmse', 'params']}
    
    print("\n=== Experiment Summary ===")
    for n in names:
        d = data[n]
        print(f"[{n}]")
        for k in means.keys():
            if len(d[k]) > 0:
                m = np.mean(d[k])
                s = np.std(d[k])
                means[k].append(m)
                stds[k].append(s)
                print(f"  {k}: {m:.6f} (+/- {s:.6f})")
            else:
                means[k].append(0)
                stds[k].append(0)

    # Plotting 2x2
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    
    # 1. Huber Loss
    ax = axes[0, 0]
    x_pos = np.arange(len(names))
    ax.bar(x_pos, means['huber'], yerr=stds['huber'], align='center', alpha=0.7, capsize=10, color='skyblue')
    ax.set_xticks(x_pos)
    ax.set_xticklabels(names, rotation=45, ha='right')
    ax.set_ylabel('Huber Loss')
    ax.set_title('Test Huber Loss')
    ax.grid(axis='y', linestyle='--', alpha=0.5)

    # 2. MAE
    ax = axes[0, 1]
    ax.bar(x_pos, means['mae'], yerr=stds['mae'], align='center', alpha=0.7, capsize=10, color='lightgreen')
    ax.set_xticks(x_pos)
    ax.set_xticklabels(names, rotation=45, ha='right')
    ax.set_ylabel('MAE')
    ax.set_title('Test MAE')
    ax.grid(axis='y', linestyle='--', alpha=0.5)

    # 3. RMSE
    ax = axes[1, 0]
    ax.bar(x_pos, means['rmse'], yerr=stds['rmse'], align='center', alpha=0.7, capsize=10, color='salmon')
    ax.set_xticks(x_pos)
    ax.set_xticklabels(names, rotation=45, ha='right')
    ax.set_ylabel('RMSE')
    ax.set_title('Test RMSE')
    ax.grid(axis='y', linestyle='--', alpha=0.5)
    
    # 4. Params vs Performance (Scatter)
    ax = axes[1, 1]
    # x-axis: params, y-axis: MAE (or Huber)
    # Scatter plot of means
    
    # Color map for names
    colors = plt.cm.get_cmap('tab10', len(names))
    
    for i, n in enumerate(names):
        p_mean = means['params'][i]
        mae_mean = means['mae'][i]
        
        ax.scatter(p_mean, mae_mean, s=100, color=colors(i), label=n, edgecolors='k')
        
    ax.set_xlabel('# Parameters')
    ax.set_ylabel('Test MAE')
    ax.set_title('Parameters vs. Performance (MAE)')
    ax.grid(True, linestyle='--', alpha=0.5)
    ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    
    plt.tight_layout()
    return fig

# -------------------------------------------------------------------------------------------------
# Model Definition: TCN_MLP Only
# -------------------------------------------------------------------------------------------------

class Chomp1d(nn.Module):
    """Remove the last `chomp_size` elements to keep causality after padding."""
    def __init__(self, chomp_size: int):
        super().__init__()
        self.chomp_size = chomp_size

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.chomp_size == 0:
            return x
        return x[:, :, :-self.chomp_size]


class TemporalBlock(nn.Module):
    def __init__(
        self,
        in_ch: int,
        out_ch: int,
        kernel_size: int,
        stride: int,
        dilation: int,
        dropout: float,
        norm_type: Optional[str] = None,
    ):
        super().__init__()
        from torch.nn.utils import weight_norm
        padding = (kernel_size - 1) * dilation  # causal padding

        self.conv1 = nn.Conv1d(in_ch, out_ch, kernel_size, stride=stride, padding=padding, dilation=dilation)
        self.chomp1 = Chomp1d(padding)
        self.relu1 = nn.ReLU(inplace=True)
        self.drop1 = nn.Dropout(dropout)

        self.conv2 = nn.Conv1d(out_ch, out_ch, kernel_size, stride=stride, padding=padding, dilation=dilation)
        self.chomp2 = Chomp1d(padding)
        self.relu2 = nn.ReLU(inplace=True)
        self.drop2 = nn.Dropout(dropout)

        if norm_type == 'weight':
            self.conv1 = weight_norm(self.conv1)
            self.conv2 = weight_norm(self.conv2)
            self.bn1 = nn.Identity()
            self.bn2 = nn.Identity()
        elif norm_type == 'batch':
            self.bn1 = nn.BatchNorm1d(out_ch)
            self.bn2 = nn.BatchNorm1d(out_ch)
        elif norm_type == 'layer':
            self.bn1 = nn.GroupNorm(1, out_ch)
            self.bn2 = nn.GroupNorm(1, out_ch)
        elif norm_type == 'instance':
            self.bn1 = nn.InstanceNorm1d(out_ch)
            self.bn2 = nn.InstanceNorm1d(out_ch)
        else:
            self.bn1 = nn.Identity()
            self.bn2 = nn.Identity()

        self.net = nn.Sequential(
            self.conv1, self.chomp1, self.bn1, self.relu1, self.drop1,
            self.conv2, self.chomp2, self.bn2, self.relu2, self.drop2
        )

        self.downsample = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.net(x)
        res = self.downsample(x)
        return self.relu(out + res)

class TCNEncoder(nn.Module):
    def __init__(self, input_dim, channels=(64, 64, 128), kernel_size=3, dropout=0.1, norm_type=None, return_last=True):
        super().__init__()
        self.return_last = return_last
        
        layers = []
        in_ch = input_dim
        for i, ch in enumerate(channels):
            dilation = 2 ** i
            layers.append(TemporalBlock(in_ch, ch, kernel_size, stride=1, dilation=dilation, dropout=dropout, norm_type=norm_type))
            in_ch = ch
            
        self.network = nn.Sequential(*layers)
        self.out_ch = channels[-1]

    def forward(self, x):
        # x: (B, T, D) -> (B, D, T)
        # Handle 2D input (B, D) -> (B, 1, D)
        if x.dim() == 2:
            x = x.unsqueeze(1)
        x = x.transpose(1, 2)
        y = self.network(x)
        if self.return_last:
            return y[:, :, -1]
        else:
            return y.transpose(1, 2)

# KinematicChainLoss moved to losses.py

class TCN_MLP(nn.Module):
    def __init__(self, input_dim, output_dim, horizon, channels=(64,64,128), kernel_size=3, 
                 dropout=0.1, head_dropout=None, mlp_hidden=128,
                 use_input_norm=False, 
                 tcn_norm=None, 
                 mlp_norm=None, **kwargs):
        super().__init__()
        
        self.use_input_norm = use_input_norm
        if use_input_norm:
            norm_type = kwargs.get('input_norm_type', 'layer')
            if norm_type == 'instance':
                # InstanceNorm1d expects (B, C, T). 
                # Our input is (B, T, D). We will transpose in forward or use LayerNorm if 1D.
                self.input_norm = nn.InstanceNorm1d(input_dim)
            else:
                self.input_norm = nn.LayerNorm(input_dim)
            
        # TCN Encoder
        self.enc = TCNEncoder(input_dim, channels, kernel_size, dropout, norm_type=tcn_norm)
        
        self.horizon = horizon
        self.output_dim = output_dim
        
        # Calculate Head Input Size from TCN Output
        head_in = self.enc.out_ch

        # MLP Head construction
        head_layers = []
        
        # Support for multi-layer hidden
        if isinstance(mlp_hidden, (list, tuple)):
            h_list = mlp_hidden
        else:
            h_list = [mlp_hidden]
            
        if head_dropout is None: head_dropout = dropout
            
        curr_in = head_in
        for h_size in h_list:
            head_layers.append(nn.Linear(curr_in, h_size))
            if mlp_norm == 'batch':
                head_layers.append(nn.LayerNorm(h_size))
            elif mlp_norm == 'layer':
                head_layers.append(nn.LayerNorm(h_size))
            
            head_layers.append(nn.ReLU())
            if head_dropout > 0:
                head_layers.append(nn.Dropout(head_dropout))
            
            curr_in = h_size
            
        self.head_base = nn.Sequential(*head_layers)
        
        # Final Output Layer (No LSTM, so just Linear: hidden -> horizon*out)
        self.head_out = nn.Linear(curr_in, horizon * output_dim)

    def forward(self, x):
        # x: (B, T, D)
        # Handle 2D input (B, D) -> (B, 1, D)
        if x.dim() == 2:
            x = x.unsqueeze(1)
        
        if self.use_input_norm:
            if isinstance(self.input_norm, nn.InstanceNorm1d):
                # x: (B, T, D) -> (B, D, T) for InstanceNorm1d
                x = x.transpose(1, 2)
                x = self.input_norm(x)
                x = x.transpose(1, 2)
            else:
                x = self.input_norm(x)
            
        # TCN Encoder
        ctx = self.enc(x) # (B, C)
        
        # MLP Head
        feat = self.head_base(ctx) # (B, Hidden)
        
        out = self.head_out(feat) # (B, H*out)
        
        # Reshape to (B, H, out)
        if self.horizon > 1:
            out = out.view(-1, self.horizon, self.output_dim)
            
        return out

# -------------------------------------------------------------------------------------------------
# [NEW] Advanced Model Architectures (Moved to be after TCN_MLP defined)
# =========================================================================================

class StanceGatedTCN(TCN_MLP):
    def __init__(self, *args, **kwargs):
        # Extract subclass-specific args
        gating_dim = kwargs.pop('gating_dim', 1) 
        # But TCN_MLP doesn't accept 'gating_dim'. 
        # We need to handle args carefully.
        # Assuming args are passed positionally matching TCN_MLP, or kwargs.
        super().__init__(*args, **kwargs)
        
        input_dim = kwargs.get('input_dim') if 'input_dim' in kwargs else args[0]
        
        # Gating Network: (B, T, In) -> (B, T, In)
        # Simple MLP per-step or shared weights? Shared weights (Conv1d(1)) or Linear.
        # We use a small MLP applied to each time step.
        self.gating_net = nn.Sequential(
            nn.Linear(input_dim, 16),
            nn.ReLU(),
            nn.Linear(16, input_dim),
            nn.Sigmoid()
        )
        
    def forward(self, x):
        # x: (B, T, D)
        # Handle 2D input (B, D) -> (B, 1, D)
        if x.dim() == 2:
            x = x.unsqueeze(1)
        
        # 1. Calculate Gate
        # We use the whole input to determine relevance
        # We use the whole input to determine relevance
        gate = self.gating_net(x) # (B, T, D)
        
        # 2. Apply Gate
        x_gated = x * gate
        
        # 3. Standard TCN Forward (Manual implementation since TCN_MLP.forward is rigid)
        # We can call super().forward(x_gated)
        return super().forward(x_gated)


class LoadGatedTCN(TCN_MLP):
    def __init__(self, *args, **kwargs):
        gate_feature_indices = kwargs.pop('gate_feature_indices', None)
        gate_hidden = kwargs.pop('gate_hidden', 16)
        gate_scale = kwargs.pop('gate_scale', 0.5)
        super().__init__(*args, **kwargs)

        input_dim = kwargs.get('input_dim') if 'input_dim' in kwargs else args[0]
        self.gate_feature_indices = gate_feature_indices or []
        self.gate_scale = float(gate_scale)
        gate_in_dim = len(self.gate_feature_indices) if self.gate_feature_indices else input_dim

        self.gating_net = nn.Sequential(
            nn.Linear(gate_in_dim, gate_hidden),
            nn.ReLU(),
            nn.Linear(gate_hidden, input_dim),
            nn.Sigmoid()
        )

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1)

        if self.gate_feature_indices:
            gate_src = x[:, :, self.gate_feature_indices]
        else:
            gate_src = x

        gate = self.gating_net(gate_src)
        scale = 1.0 + self.gate_scale * (gate - 0.5)
        x_gated = x * scale
        return super().forward(x_gated)


class GroupedAdditiveLinear(nn.Module):
    def __init__(self, input_dim, output_dim, horizon, branch_feature_indices=None, **kwargs):
        super().__init__()
        del input_dim, kwargs
        self.horizon = horizon
        self.output_dim = output_dim
        self.branch_feature_indices = {}
        self.branch_heads = nn.ModuleDict()

        branch_feature_indices = branch_feature_indices or {}
        for name, indices in branch_feature_indices.items():
            if not indices:
                continue
            self.branch_feature_indices[name] = list(indices)
            self.branch_heads[name] = nn.Linear(len(indices), horizon * output_dim)

        if not self.branch_heads:
            self.branch_feature_indices["all"] = []
            self.branch_heads["all"] = nn.LazyLinear(horizon * output_dim)

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1)
        x_last = x[:, -1, :]
        out = None
        for name, head in self.branch_heads.items():
            idx = self.branch_feature_indices.get(name, [])
            xb = x_last if not idx else x_last[:, idx]
            branch_out = head(xb)
            out = branch_out if out is None else (out + branch_out)
        if self.horizon > 1:
            out = out.view(-1, self.horizon, self.output_dim)
        return out


class FactorizedBranchTCN(nn.Module):
    def __init__(
        self,
        input_dim,
        output_dim,
        horizon,
        channels=(64, 64, 128),
        kernel_size=3,
        dropout=0.1,
        head_dropout=None,
        mlp_hidden=64,
        use_input_norm=False,
        tcn_norm=None,
        mlp_norm=None,
        branch_feature_indices=None,
        branch_channels=None,
        **kwargs,
    ):
        super().__init__()
        del input_dim, use_input_norm, kwargs
        self.horizon = horizon
        self.output_dim = output_dim
        self.branch_feature_indices = {}
        self.branch_encoders = nn.ModuleDict()
        self.branch_bases = nn.ModuleDict()
        self.branch_outs = nn.ModuleDict()

        if head_dropout is None:
            head_dropout = dropout
        if isinstance(mlp_hidden, (list, tuple)):
            branch_hidden = int(mlp_hidden[0]) if mlp_hidden else 64
        else:
            branch_hidden = int(mlp_hidden)
        if branch_channels is None:
            branch_channels = channels

        branch_feature_indices = branch_feature_indices or {}
        for name, indices in branch_feature_indices.items():
            if not indices:
                continue
            indices = list(indices)
            self.branch_feature_indices[name] = indices
            enc = TCNEncoder(len(indices), branch_channels, kernel_size, dropout, norm_type=tcn_norm)
            self.branch_encoders[name] = enc
            layers = [nn.Linear(enc.out_ch, branch_hidden)]
            if mlp_norm in ('batch', 'layer'):
                layers.append(nn.LayerNorm(branch_hidden))
            layers.append(nn.ReLU())
            if head_dropout > 0:
                layers.append(nn.Dropout(head_dropout))
            self.branch_bases[name] = nn.Sequential(*layers)
            self.branch_outs[name] = nn.Linear(branch_hidden, horizon * output_dim)

        if not self.branch_encoders:
            raise ValueError("FactorizedBranchTCN requires at least one non-empty branch.")

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1)
        out = None
        for name, idx in self.branch_feature_indices.items():
            xb = x[:, :, idx]
            ctx = self.branch_encoders[name](xb)
            feat = self.branch_bases[name](ctx)
            branch_out = self.branch_outs[name](feat)
            out = branch_out if out is None else (out + branch_out)
        if self.horizon > 1:
            out = out.view(-1, self.horizon, self.output_dim)
        return out

class AttentionTCN(TCN_MLP):
    def __init__(self, *args, **kwargs):
        atten_type = kwargs.pop('attention_type', 'temporal')
        heads = kwargs.pop('attention_heads', 4)
        super().__init__(*args, **kwargs)
        
        # Attention Layer - placed AFTER Encoder, BEFORE Head
        # Encoder out: (B, enc_out_ch) is pooled? No.
        # TCNEncoder returns (B, C_out) picking last step?
        # Wait, TCNEncoder code: return y[:, :, -1] (Last step).
        # This kills temporal dimension!
        # If we want Temporal Attention, we need the full sequence from Encoder.
        
        # We need to hack TCNEncoder or override it.
        # TCNEncoder is defined in this file.
        # We can wrap self.enc with a version that returns full sequence, 
        # OR we just access self.enc.network directly?
        pass

    def forward(self, x):
        # Handle 2D input (B, D) -> (B, 1, D)
        if x.dim() == 2:
            x = x.unsqueeze(1)
            
        if self.use_input_norm:
            x = self.input_norm(x)
            
        # Access internal network of encoder to get Full Sequence
        # TCNEncoder.forward: x.transpose(1, 2) -> network -> y
        x_t = x.transpose(1, 2) # (B, C, T)
        enc_seq = self.enc.network(x_t) # (B, C_out, T)
        
        # Apply Temporal Attention?
        # Query: Last step? Or learned parameter?
        # "Temporal Attention": Weighted sum of all time steps.
        # Key/Value: enc_seq (T steps). Query: Last step or global context.
        
        # Simple Attention: Alpha = Softmax(Linear(seq))
        # Context = Sum(Alpha * seq)
        
        # But wait, we haven't defined the attention layer in __init__ because we needed 'out_ch'
        # which is available in self.enc.out_ch
        
        # Lazy Init check? No, do it in init?
        # In init, we can access self.enc.out_ch
        if not hasattr(self, 'atten_layer'):
             dim = self.enc.out_ch
             self.atten_w = nn.Linear(dim, 1) # Score
             self.atten_layer = True
             self.atten_w.to(x.device) # Ensure device
        
        # Calculate Scores
        # enc_seq: (B, C, T) -> (B, T, C)
        seq = enc_seq.transpose(1, 2)
        scores = self.atten_w(seq) # (B, T, 1)
        weights = F.softmax(scores, dim=1) # (B, T, 1)
        
        # Context Vector
        ctx = torch.sum(seq * weights, dim=1) # (B, C)
        
        # MLP Head
        feat = self.head_base(ctx)
        out = self.head_out(feat)
        
        if self.horizon > 1:
            out = out.view(-1, self.horizon, self.output_dim)
            
        return out

# -------------------------------------------------------------------------------------------------
# Training Function (Accepts Config)
# -------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------
# TCN + GRU Hybrid Model
# -------------------------------------------------------------------------------------------------
class TCN_GRU(TCN_MLP):
    def __init__(self, input_dim, output_dim, horizon, channels=(64,64,128), kernel_size=3, 
                 dropout=0.1, head_dropout=None, mlp_hidden=128,
                 gru_hidden=64, gru_layers=1, bidirectional=False, **kwargs):
        super().__init__(input_dim, output_dim, horizon, channels, kernel_size, dropout, 
                         head_dropout, mlp_hidden, **kwargs)
        
        # Override Encoder to return sequence
        tcn_norm = kwargs.get('tcn_norm', None)
        self.enc = TCNEncoder(input_dim, channels, kernel_size, dropout, norm_type=tcn_norm, return_last=False)
        
        # GRU Layer
        tcn_out_dim = channels[-1]
        self.gru_hidden = gru_hidden
        self.gru_layers = gru_layers
        self.bidirectional = bidirectional
        
        self.gru = nn.GRU(tcn_out_dim, gru_hidden, num_layers=gru_layers, 
                          batch_first=True, dropout=dropout if gru_layers>1 else 0.0,
                          bidirectional=bidirectional)
        
        # Rebuild Head
        gru_out_dim = gru_hidden * (2 if bidirectional else 1)
        
        head_layers = []
        if isinstance(mlp_hidden, int): mlp_hidden = [mlp_hidden]
        if head_dropout is None: head_dropout = dropout
        mlp_norm = kwargs.get('mlp_norm', None)
        
        curr_in = gru_out_dim
        for h_size in mlp_hidden:
            head_layers.append(nn.Linear(curr_in, h_size))
            if mlp_norm == 'layer': head_layers.append(nn.LayerNorm(h_size))
            elif mlp_norm == 'batch': head_layers.append(nn.LayerNorm(h_size))
            head_layers.append(nn.ReLU())
            if head_dropout > 0: head_layers.append(nn.Dropout(head_dropout))
            curr_in = h_size
            
        self.head_base = nn.Sequential(*head_layers)
        self.head_out = nn.Linear(curr_in, horizon * output_dim)

    def forward(self, x):
        if x.dim() == 2: x = x.unsqueeze(1)
        if self.use_input_norm:
            if isinstance(self.input_norm, nn.InstanceNorm1d):
                x = x.transpose(1, 2); x = self.input_norm(x); x = x.transpose(1, 2)
            else:
                x = self.input_norm(x)
        
        # TCN (B, T, C)
        ctx = self.enc(x)
        
        # GRU (B, T, H)
        out, _ = self.gru(ctx)
        
        # Last step
        last_out = out[:, -1, :]
        
        feat = self.head_base(last_out)
        out = self.head_out(feat)
        
        if self.horizon > 1: out = out.view(-1, self.horizon, self.output_dim)
        return out

# -------------------------------------------------------------------------------------------------
# Resource Calculation Helper
# -------------------------------------------------------------------------------------------------
def calculate_model_resources(model, input_dim, input_window, device):
    """
    Calculates parameters, model size, and estimates inference latency on the current device.
    """
    # 1. Parameter Count & Size
    param_count = sum(p.numel() for p in model.parameters())
    param_size_mb = param_count * 4 / (1024 * 1024) # Assuming FP32 (4 bytes)
    
    # 2. Inference Timing (Host)
    # Create dummy input based on model input shape (B=1, T, D)
    dummy_input = torch.randn(1, input_window, input_dim).to(device)
    
    model.eval()
    
    # Warmup
    with torch.no_grad():
        for _ in range(20):
            _ = model(dummy_input)
            
    # Timing Loop
    t0 = time.time()
    n_loops = 100
    with torch.no_grad():
        for _ in range(n_loops):
            _ = model(dummy_input)
    t1 = time.time()
    
    avg_latency_ms = (t1 - t0) / n_loops * 1000.0
    max_freq_hz = 1000.0 / avg_latency_ms if avg_latency_ms > 0 else 0.0
    
    return {
        "n_params": param_count,
        "model_size_mb": param_size_mb,
        "host_latency_ms": avg_latency_ms,
        "host_max_freq_hz": max_freq_hz
    }

def train_experiment(
    X_train, Y_train,
    X_val, Y_val,
    X_test, Y_test,
    config,
    seed=42,
    save_dir="experiments/test",
    live_plotter=None,
    scaler_mean=None,
    scaler_std=None,
    feature_names=None
):
    # Setup Logger
    save_path_dir = Path(save_dir)
    save_path_dir.mkdir(parents=True, exist_ok=True)
    
    logger = ExperimentLogger(save_path_dir)
    logger.save_env()
    logger.save_config(config)
    
    ckpt_path = save_path_dir / "model.pt"

    # Extract Hyperparams
    # [FIX] Load from config (YAML priority)
    # Check 02_train -> loader first, then flat config
    loader_cfg = config.get("02_train", {}).get("loader") or {}
    train_cfg  = config.get("02_train", {}).get("train") or {}
    
    # Model Config: Handle 'model: null' or missing
    model_cfg  = config.get("02_train", {}).get("model")
    if not model_cfg:
        # Check if model params are in 'data' (anchor case)
        data_cfg = config.get("02_train", {}).get("data")
        if data_cfg and "channels" in data_cfg:
             model_cfg = data_cfg
             
    if not model_cfg:
        model_cfg = config.get("model") or {}

    # [NEW] Complementary Filter Logic Check (Global or Data config)
    use_comp_filter = config.get("use_complementary_filter_euler", False)
    if not use_comp_filter and '02_train' in config and 'data' in config['02_train']:
        use_comp_filter = config['02_train']['data'].get('use_complementary_filter_euler', False)
    if not use_comp_filter and 'data' in config: # Root data config
        use_comp_filter = config['data'].get('use_complementary_filter_euler', False)
        
    print(f"[CONFIG] Complementary Filter (Euler Angle) Enabled: {use_comp_filter}")
             
    if not model_cfg:
        model_cfg = config.get("model") or {}

    batch_size = loader_cfg.get("batch_size") or config.get("batch_size")
    val_batch_size = loader_cfg.get("val_batch_size") or config.get("val_batch_size") or batch_size
    
    epochs = int(train_cfg.get("epochs") or config.get("epochs"))
    patience = int(train_cfg.get("early_stop_patience") or config.get("patience"))
    lr = float(train_cfg.get("lr") or config.get("lr"))
    wd_value = train_cfg.get("wd", None)
    if wd_value is None:
        wd_value = config.get("weight_decay", 0.0)
    weight_decay = float(wd_value if wd_value is not None else 0.0)
    
    # Dropout & Norm
    dropout_p = model_cfg.get("dropout")
    if dropout_p is None: 
        if "dropout" in config.get("data", {}): dropout_p = config["data"]["dropout"]
        else: dropout_p = config.get("dropout_p", 0.5)
    dropout_p = float(dropout_p)
    
    # Normalization Flags
    use_input_norm = config.get("data", {}).get("normalize", True) # YAML data.normalize
    if use_input_norm is None: 
        use_input_norm = config.get("use_input_norm", True)
        
    model_norm_type = model_cfg.get("model_norm", None)
    tcn_norm = model_norm_type
    mlp_norm = model_norm_type
    input_norm_type = model_cfg.get("input_norm_type", model_norm_type or "layer")
    
    # Model Architecture Params
    # Model Architecture Params
    tcn_channels = model_cfg.get("channels") or config.get("tcn_channels")
    kernel_size = model_cfg.get("kernel_size") or config.get("kernel_size")
    
    mlp_hidden  = model_cfg.get("head_hidden") or config.get("head_hidden") or config.get("mlp_hidden")
    head_dropout = model_cfg.get("head_dropout") # Optional, defaults to dropout_p if None in next step
    
    # Scheduler
    cos_T0 = config.get("cos_T0", 10)
    cos_Tmult = config.get("cos_Tmult", 1)
    eta_min = config.get("eta_min", 1e-5)
    
    # Loss
    train_cfg_inner = config.get("02_train", {}).get("train", {})
    huber_delta = float(train_cfg_inner.get("huber_delta") or config.get("huber_delta", 0.5))
    
    # Reproducibility
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    
    # Dataset
    target_mode = "sequence"
    # Lazy Windowing (Stride & Windows passed here)
    train_cfg = config.get("02_train", {})
    data_cfg = train_cfg.get("data", {})
    if not data_cfg: data_cfg = config.get("data", {}) # Fallback to root data if legacy
    
    print(f"[DEBUG-R] data_cfg keys: {list(data_cfg.keys())}")
    
    # Data Parameters (Standardize on YAML keys: window_size, window_output, stride, y_delay)
    window_size = data_cfg.get("window_size") or config.get("window_size", 200)
    window_output = data_cfg.get("window_output") or data_cfg.get("time_window_output") or config.get("window_output", 1)
    stride = data_cfg.get("stride") or config.get("stride", 5)
    
    # Priority: data_cfg["est_tick_ranges"] > config["est_tick_ranges"] > None
    est_tick_ranges = data_cfg.get("est_tick_ranges") if data_cfg else config.get("est_tick_ranges")
    
    print(f"[DEBUG] win_in={window_size}, win_out={window_output}, ranges={est_tick_ranges}, stride={stride}")
    
    # Augmentation Params
    actual_train_params = train_cfg.get("train", {})
    aug_std = actual_train_params.get("augment_noise_std", 0.0)
    if aug_std > 0:
        print(f"[INFO] Training Data Augmentation Enabled: Gaussian Noise (std={aug_std})")

    # Standing-aware loss weighting
    standing_loss_weight = float(data_cfg.get("standing_loss_weight", 1.0))
    standing_std_threshold = float(data_cfg.get("standing_std_threshold", 2.0))
    if standing_loss_weight > 1.0:
        print(f"[INFO] Standing-Aware Loss Weight: {standing_loss_weight}x for windows with Y std < {standing_std_threshold}")

    train_ds = LazyWindowDataset(X_train, Y_train, window_size, window_output, stride, target_mode, est_tick_ranges=est_tick_ranges, augment=True, noise_std=aug_std,
                                 standing_loss_weight=standing_loss_weight, standing_std_threshold=standing_std_threshold)
    val_ds   = LazyWindowDataset(X_val,   Y_val,   window_size, window_output, stride, target_mode, est_tick_ranges=est_tick_ranges, augment=False)
    test_ds  = LazyWindowDataset(X_test,  Y_test,  window_size, window_output, stride, target_mode, est_tick_ranges=est_tick_ranges, augment=False)
    
    num_workers = 2
    pin_memory = torch.cuda.is_available()

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=num_workers, pin_memory=pin_memory, persistent_workers=True)
    val_loader   = DataLoader(val_ds, batch_size=val_batch_size, shuffle=False, num_workers=num_workers, pin_memory=pin_memory, persistent_workers=True)
    test_loader  = DataLoader(test_ds, batch_size=val_batch_size, shuffle=False, num_workers=num_workers, pin_memory=pin_memory, persistent_workers=True)
    
    # input_dim from first series
    input_dim = X_train[0].shape[1]
    
    if est_tick_ranges:
        horizon = len(est_tick_ranges)
    else:
        horizon = window_output
    output_dim = Y_train[0].shape[1]
    
    # Model Instantiation
    model_type = model_cfg.get("type", "TCN")
    print(f"[INFO] Initializing Model: {model_type}")
    
    common_args = dict(
        input_dim=input_dim, 
        output_dim=output_dim, 
        horizon=horizon,
        channels=tcn_channels,
        kernel_size=kernel_size,
        dropout=dropout_p,
        head_dropout=head_dropout,
        mlp_hidden=mlp_hidden,
        use_input_norm=use_input_norm,
        input_norm_type=input_norm_type,
        tcn_norm=tcn_norm,
        mlp_norm=mlp_norm
    )
    
    if model_type == "StanceGatedTCN":
        # Extract specific args
        gating_dim = model_cfg.get("gating_dim", 1) # Not used?
        gating_signal = model_cfg.get("gating_signal", "contact")
        # We pass extra args via kwargs if supported, or explicit
        model = StanceGatedTCN(**common_args, gating_dim=gating_dim)

    elif model_type == "GroupedAdditiveLinear":
        branch_patterns = model_cfg.get("branch_feature_patterns", {})
        branch_indices = {
            name: resolve_feature_indices(feature_names, patterns)
            for name, patterns in branch_patterns.items()
        }
        print(f"[INFO] GroupedAdditiveLinear branch indices: {branch_indices}")
        model = GroupedAdditiveLinear(
            input_dim=input_dim,
            output_dim=output_dim,
            horizon=horizon,
            branch_feature_indices=branch_indices,
        )

    elif model_type == "FactorizedBranchTCN":
        branch_patterns = model_cfg.get("branch_feature_patterns", {})
        branch_indices = {
            name: resolve_feature_indices(feature_names, patterns)
            for name, patterns in branch_patterns.items()
        }
        branch_channels = model_cfg.get("branch_channels") or model_cfg.get("channels")
        print(f"[INFO] FactorizedBranchTCN branch indices: {branch_indices}")
        model = FactorizedBranchTCN(
            **common_args,
            branch_feature_indices=branch_indices,
            branch_channels=branch_channels,
        )

    elif model_type == "LoadGatedTCN":
        gate_patterns = model_cfg.get("gate_feature_patterns", [])
        gate_indices = resolve_feature_indices(feature_names, gate_patterns)
        gate_hidden = int(model_cfg.get("gate_hidden", 16))
        gate_scale = float(model_cfg.get("gate_scale", 0.5))
        print(f"[INFO] LoadGatedTCN gate indices: {gate_indices}")
        model = LoadGatedTCN(
            **common_args,
            gate_feature_indices=gate_indices,
            gate_hidden=gate_hidden,
            gate_scale=gate_scale,
        )
        
    elif model_type == "AttentionTCN":
        attn_type = model_cfg.get("attention_type", "temporal")
        heads = model_cfg.get("attention_heads", 4)
        model = AttentionTCN(**common_args, attention_type=attn_type, attention_heads=heads)

    elif model_type == "TCN_GRU":
        gru_hidden = model_cfg.get("gru_hidden", 64)
        gru_layers = model_cfg.get("gru_layers", 1)
        bidirectional = model_cfg.get("bidirectional", False)
        model = TCN_GRU(**common_args, gru_hidden=gru_hidden, gru_layers=gru_layers, bidirectional=bidirectional)
        
    else:
        # Default TCN_MLP
        model = TCN_MLP(**common_args)
    
    # Check if we should resume (logic can be added here, for now overwrite)
    # If resuming, load ckpt first.
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    scheduler = None
    if cos_T0 > 0:
        scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            optimizer, T_0=cos_T0, T_mult=cos_Tmult, eta_min=eta_min
        )
        
    # Cost Function
    # [FIX] Remote uses "loss", Local uses "cost_function"
    cost_fn_name = config.get("cost_function", config.get("loss", "huber")).lower()
    
    # Weighted Loss Config
    use_weighted_loss = config.get("use_weighted_loss", False)
    loss_decay_factor = config.get("loss_decay_factor", 0.8)
    
    # If weighting is ON, we need 'none' to apply weights manually.
    reduction_val = 'none' if use_weighted_loss else 'mean'

    if cost_fn_name == "huber":
        criterion = nn.HuberLoss(delta=huber_delta, reduction=reduction_val)
    elif cost_fn_name == "mse":
        criterion = nn.MSELoss(reduction=reduction_val)
    elif cost_fn_name in ["mae", "l1"]:
        criterion = nn.L1Loss(reduction=reduction_val)
    else:
        print(f"[WARN] Unknown cost function '{cost_fn_name}', defaulting to Huber.")
        criterion = nn.HuberLoss(delta=huber_delta, reduction=reduction_val)
        
    # Pre-calculate Weights if needed
    loss_weights = None
    if use_weighted_loss:
        # W shape: (1, Horizon, 1) or (1, Horizon, OutputDim)
        # We want to weight by Time Step.
        # w_t = decay^t for t=0..Horizon-1
        w_t = np.array([loss_decay_factor**t for t in range(horizon)])
        
        # Normalize weights? Or keep them <= 1.
        # Let's keep them as decay factors.
        loss_weights = torch.from_numpy(w_t).float().to(device)
        loss_weights = loss_weights.view(1, horizon, 1) # Broadcast across batch and out_dim
        
    # Init Generic Losses from Config
    custom_losses = get_custom_losses(config, device, feature_names, scaler_mean, scaler_std)
    if custom_losses:
        print(f"[Loss] Active Custom Losses: {list(custom_losses.keys())}")

    best_val = float("inf")
    val_loss = float("inf")
    patience_cnt = 0
    
    # [FIX] Better Early Stopping Logic
    min_delta = float(train_cfg.get("early_stop_min_delta") or config.get("early_stop_min_delta", 1e-4))
    train_loss_target = float(train_cfg.get("train_loss_target") or config.get("train_loss_target", 0.0))
    
    enable_progress = sys.stdout.isatty()

    for epoch in range(1, epochs + 1):
        t0 = time.time()
        model.train()
        running = 0.0
        n_batches = 0
        
        # Inner Loop: Batches
        # leave=False keeps the log clean by clearing completed epochs
        train_iter = enumerate(train_loader, start=1)
        if enable_progress:
            train_iter = tqdm(
                train_iter,
                total=len(train_loader),
                desc=f"Epoch {epoch}",
                leave=False,
                file=sys.stdout,
            )
        for bi, batch in train_iter:
            # Support both (xb, yb) and (xb, yb, sample_weight) from dataset
            if len(batch) == 3:
                xb, yb, sw = batch
                sw = sw.to(device, non_blocking=True)
            else:
                xb, yb = batch
                sw = None
            xb, yb = xb.to(device, non_blocking=True), yb.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)

            # [FIX] OOM Handling
            try:
                pred = model(xb)

                # [FIX] Robust Shape Alignment
                # yb might be (B, 1, D) if horizon=1, pred is (B, D)
                if pred.dim() == 2 and yb.dim() == 3 and yb.shape[1] == 1:
                    yb = yb.squeeze(1)
                elif pred.dim() == 3 and yb.dim() == 2 and pred.shape[1] == 1:
                    pred = pred.squeeze(1)

                # Loss Calculation
                if use_weighted_loss:
                    # Loss is (B, H, D) because reduction='none'
                    raw_loss = criterion(pred, yb)
                    # Apply weights
                    weighted_loss = raw_loss * loss_weights
                    loss = weighted_loss.mean()
                elif sw is not None:
                    # Standing-aware per-sample weighting
                    raw_loss = nn.functional.huber_loss(pred, yb, reduction='none', delta=huber_delta)
                    # sw shape: (B,), raw_loss shape: (B, D) or (B, H, D)
                    sw_expanded = sw.view(-1, *([1] * (raw_loss.dim() - 1)))
                    loss = (raw_loss * sw_expanded).mean()
                else:
                    loss = criterion(pred, yb)
                    
                # Apply Custom Losses
                if custom_losses:
                    for name, loss_item in custom_losses.items():
                        fn = loss_item['fn']
                        weight = loss_item['weight']
                        
                        if name == 'smoothness':
                            loss += weight * fn(pred)
                        elif name == 'kinematic':
                            loss += weight * fn(xb, pred)
                        elif name == 'freq_penalty':
                            loss += weight * fn(pred, yb)
                
                loss.backward()
                optimizer.step()
                
            except RuntimeError as e:
                if "out of memory" in str(e):
                    raise RuntimeError(
                        f"Memory Insufficient (OOM): Batch size {batch_size} is too large. "
                        "Please reduce batch_size in config."
                    ) from e
                raise e
            running += loss.item()
            n_batches += 1
            
            # Update pbar description with current loss
            avg = running / max(1, n_batches)
            if enable_progress:
                train_iter.set_postfix({
                    'loss': f'{avg:.4f}',
                    'val': f'{val_loss:.4f}' if val_loss != float('inf') else 'N/A'
                })
        
        train_loss = running / max(1, n_batches)
        
        model.eval()
        val_running = 0.0
        val_iter = val_loader
        if enable_progress:
            val_iter = tqdm(val_loader, desc=f"  [VAL]", leave=False, file=sys.stdout)
        with torch.no_grad():
            for xb, yb in val_iter:
                xb, yb = xb.to(device, non_blocking=True), yb.to(device, non_blocking=True)
                pred = model(xb)
                
                if use_weighted_loss:
                    raw_loss = criterion(pred, yb)
                    weighted_loss = raw_loss * loss_weights
                    loss = weighted_loss.mean()
                else:
                    loss = criterion(pred, yb)
                    
                val_running += loss.item()
                if enable_progress:
                    val_iter.set_postfix({'v_loss': f'{val_running/max(1, len(val_loader)):.4f}'})
        val_loss = val_running / max(1, len(val_loader))
        
        if scheduler:
            scheduler.step(epoch - 1)
            
        cur_lr = optimizer.param_groups[0]["lr"]
        epoch_time = time.time() - t0
        print(f"[Epoch {epoch:03d}/{epochs:03d}] train={train_loss:.6f} val={val_loss:.6f} lr={cur_lr:.2e} time={epoch_time:.1f}s")
        
        # Log to CSV
        logger.log_epoch(epoch, train_loss, val_loss, cur_lr, epoch_time)
        
        if live_plotter:
            live_plotter.update_epoch(epoch, train_loss, val_loss)
            
        # [FIX] Early Stopping with min_delta
        if val_loss < (best_val - min_delta):
            best_val = val_loss
            patience_cnt = 0
            ckpt_obj = {
                "state_dict": model.state_dict(),
                "config": config,
                "metrics": {"best_val": best_val},
                "epoch": epoch
            }
            torch.save(ckpt_obj, ckpt_path)
            print(f"  --> Saved Best: {best_val:.6f} (Imp > {min_delta})")
        else:
            patience_cnt += 1
            # Check if strictly better (even if small) to save "latest best" anyway? 
            # Usually we only save meaningful improvements.
            if val_loss < best_val:
                 # It improved, but not enough to reset patience. 
                 # We still might want to save it? No, keep semantics consistent.
                 # Actually, usually getting *any* better is worth saving, 
                 # but patience should only reset on *significant* improvement.
                 pass
                 
            if patience_cnt >= patience:
                print("  --> Early Stopping (No improvement)")
                break
        
        # [NEW] Memory Cleanup after Epoch
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        
        # [NEW] Train Loss Target Stop (Prevent Overfitting)
        if train_loss_target > 0 and train_loss < train_loss_target:
             print(f"  --> Train Loss Target Reached ({train_loss:.6f} < {train_loss_target}). Stopping to prevent overfitting.")
             break
    logger.close()
    
    ckpt = torch.load(ckpt_path, map_location=device)
    model.load_state_dict(ckpt["state_dict"], strict=False) # strict=False to avoid minor mismatch crashes
    model.eval()
    
    test_running = 0.0
    with torch.no_grad():
        for xb, yb in test_loader:
            xb, yb = xb.to(device), yb.to(device)
            pred = model(xb)
            
            if use_weighted_loss:
                # For reporting consistency, report weighted loss
                raw_loss = criterion(pred, yb)
                weighted_loss = raw_loss * loss_weights
                l = weighted_loss.mean()
            else:
                l = criterion(pred, yb)
                
            test_running += l.item()
    test_loss = test_running / max(1, len(test_loader))
    
    # Calculate MAE & RMSE
    preds_all, trues_all = [], []
    with torch.no_grad():
        for xb, yb in test_loader:
            xb = xb.to(device)
            pred = model(xb).cpu().numpy()
            
            # Align shapes before appending
            target = yb.numpy()
            if pred.ndim == 2 and target.ndim == 3 and target.shape[1] == 1:
                target = target.squeeze(1)
            elif pred.ndim == 3 and target.ndim == 2 and pred.shape[1] == 1:
                pred = np.squeeze(pred, axis=1)
                
            preds_all.append(pred)
            trues_all.append(target)
            
    P = np.concatenate(preds_all, axis=0) 
    T = np.concatenate(trues_all, axis=0) 
    err = P - T
    
    test_mae = np.mean(np.abs(err))
    test_rmse = np.sqrt(np.mean(err**2))
    
    test_mae = np.mean(np.abs(err))
    test_rmse = np.sqrt(np.mean(err**2))
    
    # Calculate Resources
    input_window = config.get("time_window_input", 100) # Fixed: X_train is list
    res_metrics = calculate_model_resources(model, input_dim, input_window, device)
    
    # Metrics Dictionary
    metrics_result = {
        "test_huber": test_loss,
        "test_mae": float(test_mae),
        "test_rmse": float(test_rmse),
        
        # Resource Metrics
        "n_params": res_metrics["n_params"],
        "model_size_mb": float(f"{res_metrics['model_size_mb']:.4f}"),
        "host_latency_ms": float(f"{res_metrics['host_latency_ms']:.4f}"),
        "host_max_freq_hz": float(f"{res_metrics['host_max_freq_hz']:.2f}"),
        
        # Original Config
        "config": config
    }
    
    logger.save_metrics(metrics_result)
    
    # Save Confusion Matrix if needed (but this is regression)
    # np.save(save_path_dir / "predictions.npy", P)
    # np.save(save_path_dir / "truths.npy", T)
    
    return metrics_result, ckpt_path



# -------------------------------------------------------------------------------------------------
# Distribution Analysis (User Request)
# -------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------
# H5 Inspection Tool (Integrated)
# -------------------------------------------------------------------------------------------------
def inspect_h5_structure(file_path):
    if not os.path.exists(file_path):
        print(f"[ERROR] File not found: {file_path}")
        return

    print(f"\n[INFO] Inspecting file: {file_path}")
    with h5py.File(file_path, 'r') as f:
        subjects = list(f.keys())
        if not subjects:
            print("  No subjects found.")
            return
        
        # Take the first subject
        sub_key = subjects[0]
        sub_group = f[sub_key]
        print(f"  Subject: {sub_key}")
        
        conditions = list(sub_group.keys())
        if not conditions:
            print("    No conditions found.")
            return
            
        cond_key = conditions[0]
        cond_item = sub_group[cond_key]
        print(f"    Condition: {cond_key} (Type: {type(cond_item)})")
        
        if not isinstance(cond_item, h5py.Group):
            print(f"    Item {cond_key} is not a group.")
            return

        levels = list(cond_item.keys())
        if not levels:
            print("      No levels found.")
            return
            
        lv_key = levels[0]
        lv_item = cond_item[lv_key]
        print(f"      Level: {lv_key} (Type: {type(lv_item)})")
        
        if not isinstance(lv_item, h5py.Group):
            print(f"      Item {lv_key} is not a group.")
            return
            
        trials = list(lv_item.keys())
        if not trials:
            print("        No trials found.")
            return
            
        trial_key = trials[0]
        trial_group = lv_item[trial_key]
        print(f"        Trial: {trial_key}")
        
        def print_tree(name, obj):
            if isinstance(obj, h5py.Group):
                print("  " * (name.count('/') + 4) + f"Group: {name.split('/')[-1]}")
            else:
                print("  " * (name.count('/') + 4) + f"Dataset: {name.split('/')[-1]} (shape: {obj.shape})")

        print("        [Sample Trial Structure]")
        trial_group.visititems(print_tree)

# -------------------------------------------------------------------------------------------------
# Distribution Analysis (User Request)
# -------------------------------------------------------------------------------------------------

def load_all_subject_data(config):
    """
    Load data for ALL subjects across ALL data sources defined in config.
    Returns a dictionary: { subject_name: { feature_name: data_array } }
    """
    # ... (rest of the function remains same, just inserting above) ...
    data_sources = {}
    if 'shared' in config and 'data_sources' in config['shared']:
        for ds_name, ds_config in config['shared']['data_sources'].items():
            prefix = ds_config.get('prefix', '')
            path = ds_config.get('path', '')
            exclude = ds_config.get('exclude_subjects', [])
            if path:
                 data_sources[prefix] = {'path': path, 'exclude_subjects': exclude}
    
    if not data_sources:
        data_path = config.get('data_path', './combined_data.h5')
        data_sources = {'': {'path': data_path, 'exclude_subjects': []}}

    # ...

    input_vars = []
    if 'shared' in config and 'input_vars' in config['shared']:
        input_vars = config['shared']['input_vars']
    elif '01_construction' in config and 'inputs' in config['01_construction']:
        input_vars = config['01_construction']['inputs']
    
    # Also include output vars for check? (Optional, user asked for inputs)
    # output_vars = config['shared']['output_vars']
    
    # Parse input vars into a list of (group, var) tuples for easier checking
    # But wait, we need to handle _dot and _ddot logic. 
    # Let's map: group -> list of var_names
    target_map = {}
    for grp, vars in input_vars:
        if grp not in target_map: target_map[grp] = []
        target_map[grp].extend(vars)
        
    all_data = {} 
    
    total_feats = sum(len(v) for v in target_map.values())
    print(f"[DIST-ANALYSIS] Loading data from {len(data_sources)} sources for {total_feats} features across {len(target_map)} groups...")
    
    for prefix, src_cfg in data_sources.items():
        h5_path = src_cfg.get('path')
        exclude_subs = src_cfg.get('exclude_subjects', [])
        
        if not os.path.exists(h5_path):
            print(f"[WARN] Data file not found: {h5_path}")
            continue
            
        with h5py.File(h5_path, 'r') as f:
            for sub_key in f.keys():
                if sub_key in exclude_subs: continue
                
                full_sub_name = f"{prefix}{sub_key}"
                
                conditions = [k for k in f[sub_key].keys() if isinstance(f[sub_key][k], h5py.Group)]
                sub_feat_data = {} # key: "group/var" -> list of arrays
                
                for cond in conditions:
                    if cond in ['subject_info', 'derived']: continue
                    cond_group = f[sub_key][cond]
                    
                    # Iterate Levels
                    for lv_name in cond_group.keys():
                        lv_group = cond_group[lv_name]
                        if not isinstance(lv_group, h5py.Group): continue
                        
                        # Iterate Trials
                        for trial_name in lv_group.keys():
                            trial_group = lv_group[trial_name]
                            if not isinstance(trial_group, h5py.Group): continue
                            
                            for grp_name, target_vars in target_map.items():
                                # Navigate to group inside trial
                                curr = trial_group
                                for p in grp_name.split('/'):
                                    if p in curr: curr = curr[p]
                                    else: curr = None; break
                                    
                                if curr:
                                    data_grp = curr
                                    for feat in target_vars:
                                        val = None
                                        
                                        # 1. Direct Load
                                        if feat in data_grp:
                                            val = data_grp[feat][:]
                                        
                                        # [NEW] Fallback for Milestone 1: hip_angle -> motor_angle
                                        elif 'hip_angle' in feat:
                                            alt_name = feat.replace('hip_angle', 'motor_angle')
                                            if alt_name in data_grp:
                                                val = data_grp[alt_name][:]
                                            
                                        # 2. Derived (_dot / _ddot)
                                        if val is None and (feat.endswith('_dot') or feat.endswith('_ddot')):
                                            if feat.endswith('_ddot'):
                                                base = feat[:-5]
                                                is_accel = True
                                            else:
                                                base = feat[:-4]
                                                is_accel = False
                                            
                                            if base in data_grp:
                                                base_val = data_grp[base][:]
                                                # 1st deriv
                                                val = np.gradient(base_val, axis=0) * 100 # fs=100 assume
                                                if feat.endswith('_ddot'):
                                                    val = np.gradient(val, axis=0) * 100
                                                    
                                        if val is not None:
                                            full_key = f"{grp_name}/{feat}"
                                            if full_key not in sub_feat_data: sub_feat_data[full_key] = []
                                            sub_feat_data[full_key].append(val)
                
                # Concatenate
                if sub_feat_data:
                    all_data[full_sub_name] = {}
                    for key, val_list in sub_feat_data.items():
                        if val_list:
                            all_data[full_sub_name][key] = np.concatenate(val_list)

    return all_data

def analyze_data_distribution(config, output_dir):
    print("\n" + "="*60)
    print("  Running Data Distribution Analysis (Outlier Detection)")
    print("="*60)
    
    all_data = load_all_subject_data(config)
    if not all_data:
        print("[WARN] No data loaded for distribution analysis.")
        return

    os.makedirs(output_dir, exist_ok=True)
    features = sorted(list(set(k for sub_data in all_data.values() for k in sub_data.keys())))
    stats_summary = []
    
    for feature in features:
        plot_data = []
        for sub, data in all_data.items():
            if feature in data:
                vals = data[feature]
                # Downsample for plotting
                if len(vals) > 5000:
                    vals_plot = np.random.choice(vals, 5000, replace=False)
                else:
                    vals_plot = vals
                
                for v in vals_plot:
                    plot_data.append({'Subject': sub, 'Value': v})
                
                stats_summary.append({
                    'Feature': feature, 'Subject': sub,
                    'Mean': np.mean(vals), 'Std': np.std(vals)
                })
        
        if not plot_data: continue
            
        df_feat = pd.DataFrame(plot_data)
        
        # Violin Plot
        plt.figure(figsize=(12, 6))
        sns.violinplot(data=df_feat, x='Subject', y='Value', hue='Subject', legend=False)
        plt.xticks(rotation=45, ha='right')
        plt.title(f'Distribution: {feature}')
        plt.tight_layout()
        safe_fname = feature.replace('/', '_')
        plt.savefig(os.path.join(output_dir, f'dist_violin_{safe_fname}.png'))
        plt.close()

    # Save Stats & Check Outliers
    df_stats = pd.DataFrame(stats_summary)
    df_stats.to_csv(os.path.join(output_dir, 'subject_stats.csv'), index=False)
    
    print(f"[INFO] Distribution plots saved to {output_dir}")
    print("[INFO] Checking for outliers (Mean Shift > 2-Sigma)...")
    
    for feature in features:
        feat_stats = df_stats[df_stats['Feature'] == feature]
        overall_mean = feat_stats['Mean'].mean()
        overall_std = feat_stats['Mean'].std()
        
        threshold = 2 * overall_std
        outliers = feat_stats[np.abs(feat_stats['Mean'] - overall_mean) > threshold]
        
        if not outliers.empty:
            print(f"  [ALARM] {feature}: Detect {len(outliers)} outliers")
            for _, row in outliers.iterrows():
                z = (row['Mean'] - overall_mean) / (overall_std + 1e-9)
                print(f"    - {row['Subject']}: Z={z:.2f} (Mean={row['Mean']:.4f})")
                
    # [MEMORY] Explicit Cleanup
    del all_data
    del df_stats
    gc.collect()
    print("="*60 + "\n")

# -------------------------------------------------------------------------------------------------
# Main Execution
# -------------------------------------------------------------------------------------------------

if __name__ == "__main__":
    
    # Arg Parse
    parser = argparse.ArgumentParser()
    parser.add_argument("--rank", type=int, default=0, help="Rank of the current process")
    parser.add_argument("--total_nodes", type=int, default=1, help="Total number of nodes/GPUs")
    parser.add_argument("--config", type=str, default=None, help="Specific config file to run")
    parser.add_argument("--inspect", type=str, default=None, help="Path to H5 file to inspect structure")
    parser.add_argument("--run_distribution_analysis", action="store_true",
                        help="Run expensive subject-level distribution analysis before training")
    parser.add_argument("--run_feature_visualization", action="store_true",
                        help="Run optional baseline feature visualization hook")
    parser.add_argument("--run_feature_importance", action="store_true",
                        help="Run expensive permutation feature importance after training")
    args = parser.parse_args()

    # [NEW] Inspect Mode
    if args.inspect:
        inspect_h5_structure(args.inspect)
        sys.exit(0)

    # Load Configs
    config_dir = Path("configs")
    
    if args.config:
        yaml_files = [Path(args.config)]
    else:
        yaml_files = list(config_dir.rglob("*.yaml")) # rglob for recursive search
    
    # 1. Load Base Config (Must exist)
    # 1.5 Load BASE CONFIG if 'base_config.yaml' exists and merge
    # (Typically base_config is default, args.config overrides it)
    # Check if 'exp_name' is missing, implying it might be a partial config
    base_config_path_str = "configs/baseline.yaml"
    base_config = {} # Initialize an empty base_config
    
    # Check if base_config.yaml exists and if the current config is not base_config itself
    if os.path.exists(base_config_path_str) and (args.config is None or Path(args.config).name != "baseline.yaml"):
        print(f"Loading base config from {base_config_path_str}...")
        with open(base_config_path_str, 'r', encoding='utf-8') as bf:
            base_config = yaml.safe_load(bf)
        print(f"[INFO] Loaded base defaults from {base_config_path_str}")
    else:
        print("No base_config.yaml found or explicitly provided as the main config. Proceeding with provided config only.")
        
    # 2. Prepare Experiments List
    experiments_to_run = []
    
    if not yaml_files:
        pass # Should not happen if base_config exists
    else:
        print(f"Found {len(yaml_files)} configs: {[f.name for f in yaml_files]}")
        
        for yf in yaml_files:
            # Skip base_config.yaml if we want to run it only once
            # But the logic below merges cfg onto base. 
            # If yf IS base_config.yaml, merged will be identical to base_config.
            # This is fine, it means we run the base experiment.
            
            with open(yf, 'r', encoding='utf-8') as f:
                cfg = yaml.safe_load(f)
                
            exp_name = cfg.get("exp_name", yf.stem)
            merged = normalize_experiment_config(cfg, base_config=base_config, exp_name=exp_name)
            try:
                merged["_config_relpath"] = str(yf.relative_to(config_dir))
            except ValueError:
                merged["_config_relpath"] = str(yf)
            experiments_to_run.append((exp_name, merged))
            
    # --- Sharding for Parallel Execution ---
    # Sort to ensure consistent order across processes
    experiments_to_run.sort(key=lambda x: x[0])
    
    # Filter based on rank
    total_exps = len(experiments_to_run)
    experiments_to_run = [e for i, e in enumerate(experiments_to_run) if i % args.total_nodes == args.rank]
    
    print(f"\n[PARALLEL] Rank {args.rank}/{args.total_nodes} - Process {len(experiments_to_run)}/{total_exps} experiments.")
    
    # [USER REQUEST] Run Distribution Analysis at the very beginning
    # Use the first valid config (or base_config) to find data sources
    if args.run_distribution_analysis and args.rank == 0:
        analysis_config = base_config
        if not analysis_config and experiments_to_run:
            analysis_config = experiments_to_run[0][1]
            
        if analysis_config:
            # We assume output dir based on first config or generic
            dist_output_dir = "compare_result/input_feat_check"
            analyze_data_distribution(analysis_config, dist_output_dir)
            
    # Remove Global Dataset Load - Move to Experiment Loop
    # We need to rebuild dataset for EACH experiment because input_vars/output_vars might change!
    
    # [FIX] Disable Live Plotter in Headless/Cluster Env to save memory/avoid backend issues
    # live_plotter = LiveTrainingPlotter()
    live_plotter = None
    
    results = [] # Reset results list

    # Progress bar for Experiments (Total Progress)
    # Use position=0 for the outer bar.
    exp_iter = experiments_to_run
    if sys.stdout.isatty():
        exp_iter = tqdm(experiments_to_run, desc=f"GPU-{args.rank} Total", position=0)
    for exp_name, cfg in exp_iter:
        # [USER REQUEST] Visualize Input Features for Baseline
        if args.run_feature_visualization and exp_name == "baseline":
            try:
                visualize_features(cfg)
            except Exception as e:
                print(f"[WARN] Feature Visualization Failed: {e}")

        seeds = cfg.get("seeds") or cfg.get("02_train", {}).get("train", {}).get("seeds") or [42]
        seeds = [int(s) for s in seeds]

        for sd in seeds:
            full_name = f"{exp_name}_seed{sd}"
            print(f"\n>>> Start Experiment: {full_name}")
            # live_plotter.start_session(exp_name, sd)
            
            # Directory Setup
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            exp_root = derive_experiment_root(cfg.get("_config_relpath", ""))
            save_dir = str(exp_root / full_name)
            
            # --- Dynamic Data Loading ---
            # Extract vars from config or use default global if not present (backward compatibility)
            # But we moved global vars to base_config, so cfg SHOULD have them.
            
            
            # [FIX] Handle Nested Config Mapping (New Format -> Root Keys for compatibility)
            if '01_construction' in cfg:
                # Data Path
                if 'data_path' not in cfg:
                    cfg['data_path'] = cfg['01_construction'].get('src_h5') or cfg['shared'].get('src_h5')
                    
                # Subjects & Conditions
                if 'subjects' not in cfg:
                    cfg['subjects'] = cfg['01_construction'].get('include_subjects', [])
                    
                if 'conditions' not in cfg:
                    cfg['conditions'] = cfg['01_construction'].get('include_conditions', [])
                    
            # CV Mode Default
            if 'cv_mode' not in cfg:
                # Check 02_train
                if '02_train' in cfg:
                    cfg['cv_mode'] = cfg['02_train'].get('split', {}).get('mode', 'loso')
                else:
                    cfg['cv_mode'] = 'loso'

            # Retrieve data_path safely
            # [FIX] Handle Nested Config Mapping (Pre-computation)
            if 'data_path' not in cfg:
                src = None
                if '01_construction' in cfg: src = cfg['01_construction'].get('src_h5')
                if not src and 'shared' in cfg: src = cfg['shared'].get('src_h5')
                if not src: src = "./combined_data.h5" # Default fallback
                cfg['data_path'] = src

            if '01_construction' in cfg:
                # Subjects & Conditions
                if 'subjects' not in cfg:
                    cfg['subjects'] = cfg['01_construction'].get('include_subjects', [])
                if 'conditions' not in cfg:
                    cfg['conditions'] = cfg['01_construction'].get('include_conditions', [])
                    
            if 'subjects' not in cfg: cfg['subjects'] = [] # Or handle dynamic loading
            if 'conditions' not in cfg: cfg['conditions'] = []
                    
            if 'cv_mode' not in cfg and '02_train' in cfg:
                cfg['cv_mode'] = cfg['02_train'].get('split', {}).get('mode', 'loso')
            elif 'cv_mode' not in cfg:
                cfg['cv_mode'] = 'loso'

            # Retrieve data_path safely
            current_data_path = get_primary_data_path(cfg)
            if not current_data_path:
                raise ValueError("data_path not found in config")
                
            # print(f"Data Path: {current_data_path}")

            curr_input_vars = get_config_input_vars(cfg)
            curr_output_vars = get_config_output_vars(cfg)
            cfg['subjects'] = get_config_subjects(cfg)
            cfg['conditions'] = get_config_conditions(cfg)

            # Subj / Window
            curr_window = get_window_size(cfg)
            curr_est_tick_ranges = get_est_tick_ranges(cfg)
                
            # [FIX] Inject back into cfg so train_experiment sees it
            if curr_est_tick_ranges:
                cfg["est_tick_ranges"] = curr_est_tick_ranges
                    
            # [NEW] Input LPF
            curr_input_lpf_cutoff = get_input_lpf_cutoff(cfg)
            
            curr_input_lpf_order = get_input_lpf_order(cfg, default=4)
                    
            # Dataset Universe (Full list of subs/conds available to read)
            curr_sub_names = get_config_subjects(cfg)
            curr_cond_names = get_config_conditions(cfg)

            # Level Selection (Explicit include list)
            curr_level_selection = get_config_level_selection(cfg)
                    
            # --- TCN Dynamic Config ---
            fallback_layers = base_config.get("tcn_layers", 3) if base_config else 3
            fallback_hidden = base_config.get("tcn_hidden", 64) if base_config else 64
            curr_tcn_channels = get_tcn_channels(cfg, fallback_layers=fallback_layers, fallback_hidden=fallback_hidden)
            
            cfg["tcn_channels"] = curr_tcn_channels
            
            # CV Logic: Forced LOSO
            sub_runs = []
            all_subs = sorted(list(set(curr_sub_names))) if curr_sub_names else []
            loso_filter = cfg.get("03_eval", {}).get("split", {}).get("loso_subjects")
            if not loso_filter: loso_filter = cfg.get("loso_subjects")
                
            for i in range(len(all_subs)):
                test_sub = all_subs[i]
                if loso_filter and test_sub not in loso_filter: continue
                val_sub = all_subs[i-1] 
                train_subs = [s for s in all_subs if s != test_sub and s != val_sub]
                sub_runs.append({
                    "name": f"{exp_name}_Test-{test_sub}",
                    "train": train_subs, "val": [val_sub], "test": [test_sub]
                })

            c_in_vars = parse_vars(curr_input_vars)
            c_out_vars = parse_vars(curr_output_vars)
            
            print(f"\n[INFO] Starting Cross-Validation Loops: {len(sub_runs)} folds (Config: {exp_name})")
            
            for run_meta in sub_runs:
                final_exp_name = run_meta["name"]
                full_name_seed = f"{final_exp_name}_seed{sd}"
                print(f"\n>>> Start Experiment: {full_name_seed}")
                
                # Load Datasets
                data_cfg_now = cfg.get("02_train", {}).get("data", {})
                use_phys_vel = data_cfg_now.get("use_physical_velocity_model", False)
                use_gait_ph  = data_cfg_now.get("use_gait_phase", False)
                
                # [NEW] Complementary Filter Logic Check (Global or Data config)
                use_comp_filter = cfg.get("use_complementary_filter_euler", False)
                if not use_comp_filter and '02_train' in cfg and 'data' in cfg['02_train']:
                    use_comp_filter = cfg['02_train']['data'].get('use_complementary_filter_euler', False)
                if not use_comp_filter and 'data' in cfg: # Root data config
                    use_comp_filter = cfg['data'].get("use_complementary_filter_euler", False)
                
                print(f"[INFO] Comp Filter for {final_exp_name}: {use_comp_filter}")

                # [NEW] Residual Learning Mode
                use_residual = data_cfg_now.get("residual_target", False)
                use_calib_thigh = data_cfg_now.get("calibrate_robot_thigh", False)
                if use_residual:
                    print(f"[INFO] Residual target mode ENABLED for {final_exp_name}")

                X_train, Y_train = build_nn_dataset_multi(
                    cfg, curr_sub_names, curr_cond_names, c_in_vars, c_out_vars,
                    curr_window, time_window_output, stride,
                    subject_selection=make_subject_selection(run_meta["train"]),
                    condition_selection=CONDITION_SELECTION,
                    level_selection=curr_level_selection,
                    est_tick_ranges=cfg.get("est_tick_ranges"),
                    use_physical_velocity_model=use_phys_vel, use_gait_phase=use_gait_ph,
                    input_lpf_cutoff=curr_input_lpf_cutoff, input_lpf_order=curr_input_lpf_order,
                    use_complementary_filter_euler=use_comp_filter,
                    residual_target=use_residual, calibrate_robot_thigh=use_calib_thigh
                )
                X_val, Y_val = build_nn_dataset_multi(
                    cfg, curr_sub_names, curr_cond_names, c_in_vars, c_out_vars,
                    curr_window, time_window_output, stride,
                    subject_selection=make_subject_selection(run_meta["val"]),
                    condition_selection=CONDITION_SELECTION,
                    level_selection=curr_level_selection,
                    est_tick_ranges=cfg.get("est_tick_ranges"),
                    use_physical_velocity_model=use_phys_vel, use_gait_phase=use_gait_ph,
                    input_lpf_cutoff=curr_input_lpf_cutoff, input_lpf_order=curr_input_lpf_order,
                    use_complementary_filter_euler=use_comp_filter,
                    residual_target=use_residual, calibrate_robot_thigh=use_calib_thigh
                )
                X_test, Y_test = build_nn_dataset_multi(
                    cfg, curr_sub_names, curr_cond_names, c_in_vars, c_out_vars,
                    curr_window, time_window_output, stride,
                    subject_selection=make_subject_selection(run_meta["test"]),
                    condition_selection=CONDITION_SELECTION,
                    level_selection=curr_level_selection,
                    est_tick_ranges=cfg.get("est_tick_ranges"),
                    use_physical_velocity_model=use_phys_vel, use_gait_phase=use_gait_ph,
                    input_lpf_cutoff=curr_input_lpf_cutoff, input_lpf_order=curr_input_lpf_order,
                    use_complementary_filter_euler=use_comp_filter,
                    residual_target=use_residual, calibrate_robot_thigh=use_calib_thigh
                )

                if len(X_train) == 0:
                    print(f"[ERROR] No training data for {full_name_seed}.")
                    continue
                    
                local_save_dir = str(exp_root / full_name_seed)
                os.makedirs(local_save_dir, exist_ok=True)
                    
                # Normalization
                use_norm = cfg.get("use_input_norm", True)
                if not use_norm and '02_train' in cfg:
                     use_norm = cfg['02_train'].get('model',{}).get('use_norm', True)
                     
                if use_norm:
                    print("[INFO] Computing GLOBAL mean/std for Input Normalization...")
                    all_train = np.concatenate(X_train, axis=0)
                    mean = np.mean(all_train, axis=0)
                    std = np.std(all_train, axis=0)
                    scale = std
                    scale[scale < 1e-8] = 1.0
                    np.savez(os.path.join(local_save_dir, "scaler.npz"), mean=mean, scale=scale)
                    
                    # [MEMORY] Clear all_train immediately
                    del all_train
                    gc.collect()

                    for i in range(len(X_train)): X_train[i] = (X_train[i] - mean) / scale
                    for i in range(len(X_val)): X_val[i] = (X_val[i] - mean) / scale
                    for i in range(len(X_test)): X_test[i] = (X_test[i] - mean) / scale
                else:
                    normalize_type = cfg.get("02_train", {}).get("data", {}).get("normalize_type", "global")
                    if normalize_type == "subject":
                        print("[INFO] Applying SUBJECT-WISE Normalization...")
                        for data_list in [X_train, X_val, X_test]:
                            for i in range(len(data_list)):
                                m, s = np.mean(data_list[i], axis=0), np.std(data_list[i], axis=0) + 1e-8
                                data_list[i] = (data_list[i] - m) / s

                feat_names_simple = [f"{gp}/{v}" for gp, vs in c_in_vars for v in vs]
                
                metrics, ckpt_path = train_experiment(
                    X_train, Y_train, X_val, Y_val, X_test, Y_test,
                    cfg, seed=sd, save_dir=local_save_dir, live_plotter=None,
                    scaler_mean=mean if use_norm else None, scaler_std=scale if use_norm else None,
                    feature_names=feat_names_simple
                )
                
                # [MEMORY] Clear big lists and collect garbage after fold
                del X_train, Y_train, X_val, Y_val, X_test, Y_test
                gc.collect()
                if torch.cuda.is_available(): torch.cuda.empty_cache()

                print(f"[RESULT] {full_name_seed} | test_mae={metrics.get('test_mae', 0):.6f}")
                results.append((final_exp_name, sd, metrics, ckpt_path, cfg, c_in_vars))
    
    # Summary Plot
    if results:
        summary_fig = plot_model_summary(results)
        summary_fig.savefig("experiments/summary_plot.png")
    
    if not results:
        print("No results to analyze.")
        exit()
        
    if not args.run_feature_importance:
        print("\n[INFO] Skipping feature importance (disabled).")
        sys.exit(0)

    print("\n>>> Calculating Feature Importance for Best Model...")
    
    # 1. Find Best Model (lowest test_mae)
    best_res = sorted(results, key=lambda x: x[2]['test_mae'])[0]
    best_name, best_seed, best_metrics, best_ckpt, best_cfg, best_in_vars = best_res
    print(f"Best Model: {best_name} (MAE={best_metrics['test_mae']:.6f})")
    
    # 2. Re-load Best Model
    # Re-instantiate
    # Need to reload dataset if we want to re-calc importance on TEST set safely?
    # We have X_test in memory BUT it might be from the LAST iteration.
    # CRITICAL: If experiments use DIFFERENT inputs, X_test currently holds the LAST one.
    # So we MUST re-load the dataset for the best model to ensure X_test matches best_cfg.
    
    print("Re-loading Test Data for Best Model Feature Importance...")
    c_in_vars = best_in_vars
    
    # Retrieve Output Vars
    if "output_vars" in best_cfg:
        raw_out = best_cfg["output_vars"]
    elif "shared" in best_cfg and "output_vars" in best_cfg["shared"]:
        raw_out = best_cfg["shared"]["output_vars"]
    elif "01_construction" in best_cfg:
        raw_out = best_cfg["01_construction"].get("outputs")
    else:
        raw_out = base_config.get("output_vars") if base_config else None
        
    c_out_vars = parse_vars(raw_out)
    
    # Retrieve Data Path
    best_data_path = get_primary_data_path(best_cfg)

    # Retrieve Other params
    best_sub_names = get_config_subjects(best_cfg)
    best_cond_names = get_config_conditions(best_cfg)
    # best_lpf variables removed
    
    # Window
    best_window = get_window_size(best_cfg)

    best_data_cfg = get_train_data_config(best_cfg)
    best_residual = best_data_cfg.get("residual_target", False)
    best_calib = best_data_cfg.get("calibrate_robot_thigh", False)
    best_level_selection = get_config_level_selection(best_cfg)

    X_test_best, Y_test_best = build_nn_dataset_multi(
        best_cfg, best_sub_names, best_cond_names, c_in_vars, c_out_vars,
        best_window, best_cfg.get("time_window_output", 1), best_cfg.get("stride", 5),
        subject_selection=make_subject_selection(best_sub_names),
        condition_selection=CONDITION_SELECTION,
        level_selection=best_level_selection,
        est_tick_ranges=best_cfg.get("est_tick_ranges", None),
        use_complementary_filter_euler=use_comp_filter,
        residual_target=best_residual, calibrate_robot_thigh=best_calib
    )
    
    best_horizon = len(best_cfg.get("est_tick_ranges")) if best_cfg.get("est_tick_ranges") else best_cfg.get("time_window_output", 10)
    
    # [FIX] Extract Model Config correctly (Nested priority)
    # Priority: 02_train.model > shared.model > root
    model_cfg = best_cfg.get("02_train", {}).get("model", {})
    if not model_cfg:
        model_cfg = best_cfg.get("shared", {}).get("model", {})
    if not model_cfg:
        model_cfg = best_cfg.get("model", {})

    tcn_channels = model_cfg.get("channels") or best_cfg.get("tcn_channels") or best_cfg.get("channels")
    kernel_size = model_cfg.get("kernel_size") or best_cfg.get("kernel_size")
    mlp_hidden = model_cfg.get("head_hidden") or best_cfg.get("head_hidden") or best_cfg.get("mlp_hidden")
    head_dropout = model_cfg.get("head_dropout") or best_cfg.get("head_dropout")
    dropout_p = float(model_cfg.get("dropout") or best_cfg.get("dropout", 0.1))
    
    # Norm types
    model_norm = model_cfg.get("model_norm")
    
    if not X_test_best:
        print("[WARN] No data found for Feature Importance Re-loading. Skipping.")
    else:
        best_model = TCN_MLP(
            input_dim=X_test_best[0].shape[1],
            output_dim=Y_test_best[0].shape[1],
            horizon=best_horizon, 
            channels=tcn_channels,
            kernel_size=kernel_size,
            dropout=dropout_p,
            head_dropout=head_dropout,
            mlp_hidden=mlp_hidden,
            use_input_norm=best_cfg.get("use_input_norm", True), 
            tcn_norm=model_norm,
            mlp_norm=model_norm
        )
        
        # Load Weights
        ckpt = torch.load(best_ckpt, map_location='cpu')
        best_model.load_state_dict(ckpt['state_dict'])
        
        device = "cuda" if torch.cuda.is_available() else "cpu"
        best_model.to(device)
        best_model.eval()
        
        # 3. Construct Feature Names
        feature_names = []
        for gpath, vars in c_in_vars:
            if 'Back_imu' in gpath or 'back_imu' in gpath:
                prefix = "IMU"
            elif 'Robot' in gpath or 'robot' in gpath:
                prefix = "Robot_L" if 'left' in gpath else ("Robot_R" if 'right' in gpath else "Robot")
            elif 'grf' in gpath:
                prefix = f"GRF_{'L' if 'left' in gpath else 'R'}"
            elif 'kin_q' in gpath:
                prefix = "Deg"
            else:
                prefix = gpath.split('/')[-1]
                
            for v in vars:
                v_clean = v.replace('ankle_angle', 'Ankle').replace('knee_angle', 'Knee').replace('hip_', 'Hip_')
                v_clean = v_clean.replace('flexion', 'Flex').replace('adduction', 'Add').replace('rotation', 'Rot')
                v_clean = v_clean.replace('_l', '_L').replace('_r', '_R')
                feature_names.append(f"{prefix}_{v_clean}")
                
        # 4. Compute Importance (Permutation)
        print(f"  Calculating Importances for {len(feature_names)} features...")
        
        def calculate_permutation_importance(model, dataloader, feature_names, device):
            model.eval()
            N_feats = len(feature_names)
            total_samples = 0
            
            # Accumulators
            total_base_loss = 0.0
            feat_loss_sums = torch.zeros(N_feats, device=device)
            
            print(f"  Calculating Importances (Batch-wise, {N_feats} features)...")
            
            with torch.no_grad():
                for xb, yb in dataloader:
                    xb, yb = xb.to(device), yb.to(device)
                    B = xb.size(0)
                    total_samples += B
                    
                    # 1. Base Prediction
                    pred_base = model(xb)
                    
                    # Shape Alignment
                    if pred_base.dim() == 2 and yb.dim() == 3 and yb.shape[1] == 1: 
                        yb_s = yb.squeeze(1)
                    elif pred_base.dim() == 3 and yb.dim() == 2 and pred_base.shape[1] == 1: 
                        pred_base = pred_base.squeeze(1)
                        yb_s = yb
                    else:
                        yb_s = yb

                    # Base Loss (Sum)
                    base_loss = torch.sum(torch.abs(pred_base - yb_s)).item()
                    total_base_loss += base_loss
                    
                    # 2. Permutation (Intra-batch)
                    for i in range(N_feats):
                        original_col = xb[:, :, i].clone()
                        
                        # Shuffle indices within batch
                        idx = torch.randperm(B, device=device)
                        xb[:, :, i] = xb[idx, :, i]
                        
                        pred_p = model(xb)
                        # Shape Alignment for Permuted (assume same as base)
                        if pred_p.dim() == 3 and pred_p.shape[1] == 1: pred_p = pred_p.squeeze(1)
                        
                        # Permuted Loss sum
                        p_loss = torch.sum(torch.abs(pred_p - yb_s))
                        feat_loss_sums[i] += p_loss
                        
                        # Restore
                        xb[:, :, i] = original_col
            
            # Compute Averages
            base_mae = total_base_loss / (total_samples + 1e-9)
            print(f"  Baseline MAE: {base_mae:.6f}")
            
            feat_maes = feat_loss_sums.cpu().numpy() / (total_samples + 1e-9)
            importances = feat_maes - base_mae
            
            for i, imp in enumerate(importances):
                print(f"    Feat {i}: +{imp:.6f}", end='\r')
            print("")
            return importances

        # [MEMORY-FIX] Restore original stride but use Batch Processing for safety
        fi_stride = best_cfg.get("stride", 5)
        
        imp_test_ds = LazyWindowDataset(
            X_test_best, Y_test_best, 
            best_window, best_cfg.get("time_window_output", 1), fi_stride, 
            target_mode="sequence", est_tick_ranges=best_cfg.get("est_tick_ranges", None)
        )
        
        # [MEMORY-FIX] Explicit GC & Shuffle=True for intra-batch permutation
        import gc
        gc.collect()
        torch.cuda.empty_cache()
        
        imp_loader = DataLoader(imp_test_ds, batch_size=512, shuffle=True, num_workers=0)
        importances = calculate_permutation_importance(best_model, imp_loader, feature_names, device)
        
        # 5. Plot
        n_feats = len(importances)
        sorted_idx = np.argsort(importances)[::-1]
        fig_h = max(8, n_feats * 0.25)
        plt.figure(figsize=(10, fig_h))
        plt.barh(np.arange(n_feats), importances[sorted_idx][::-1], color='skyblue')
        plt.yticks(np.arange(n_feats), np.array(feature_names)[sorted_idx][::-1] if len(feature_names)==n_feats else np.arange(n_feats))
        plt.xlabel("Permutation Importance (MAE Increase)")
        plt.title(f"Feature Importance: {best_name}")
        plt.tight_layout()
        plt.savefig("experiments/feature_importance_best.png")
        print(">>> Feature Importance Saved: experiments/feature_importance_best.png")
